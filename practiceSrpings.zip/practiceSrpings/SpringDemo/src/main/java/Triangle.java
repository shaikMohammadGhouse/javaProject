
public class Triangle 
{
	public void draw() {
		
		
		System.out.println("...triangle is drawn..");
	}
}

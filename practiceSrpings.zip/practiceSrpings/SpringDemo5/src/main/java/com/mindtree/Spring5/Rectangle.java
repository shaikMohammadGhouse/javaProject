package com.mindtree.Spring5;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Rectangle implements ApplicationContextAware, BeanNameAware
{

	private Point pointAA;
	private Point pointBB;
	private Point pointCC;
	private ApplicationContext context=null;
	
	public Point getPointAA() {
		return pointAA;
	}

	public void setPointAA(Point pointAA) {
		this.pointAA = pointAA;
	}

	public Point getPointBB() {
		return pointBB;
	}

	public void setPointBB(Point pointBB) {
		this.pointBB = pointBB;
	}

	public Point getPointCC() {
		return pointCC;
	}

	public void setPointCC(Point pointCC) {
		this.pointCC = pointCC;
	}

	public void draw()
	{
		
		

		System.out.println(getPointBB().getX()+" "+getPointBB().getY());
		System.out.println(getPointCC().getX()+" "+getPointCC().getY());
		//System.out.println(type);
	}

	public void setApplicationContext(ApplicationContext context) throws BeansException 
	{
		this.context=context;
		
	}

	public void setBeanName(String beanName) 
	{
		System.out.println("bean name........."+beanName);
	}

}

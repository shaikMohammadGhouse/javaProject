package com.mindtree.Spring1;


public class Triangle 
{
	private String type="";
	public void draw() {
		
		
		System.out.println("...triangle is drawn..");
		//System.out.println(type);
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}

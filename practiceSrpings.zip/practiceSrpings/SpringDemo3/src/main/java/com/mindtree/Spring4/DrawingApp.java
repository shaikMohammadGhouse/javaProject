package com.mindtree.Spring4;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class DrawingApp {

	public static void main(String[] args) 
	{
		
		
		//using application Context instead of BeanFacory
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle=(Triangle)context.getBean("triangle");
		
		//using the triangle alias.... the copy of the triangle made in spring.xml
		Triangle triangle1=(Triangle)context.getBean("triangle-alias");
		triangle.draw();
		triangle1.draw();
	}

}

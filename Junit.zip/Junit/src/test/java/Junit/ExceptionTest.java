package Junit;


import java.util.Arrays;

import org.junit.Test;

public class ExceptionTest {

	
	
		/*@Test
		public void doArrayExceptionTest() 		//testing for exception
		{
			
		//normal exception handling..
			int numbers[]=null;
			//int expected[]={10,23,50,60,78}; 
			try
			{
			Arrays.sort(numbers);
			}
			catch(NullPointerException e)						//way1
			{												//without using TestException
				
			}
			
			
			//..............or/////
			
			
			
			
			System.out.println("doArrayExceptionTest");
		}
		*/
		
		
		
		@Test(expected=NullPointerException.class)
		public void doNullArrayExceptionTestImp() 		//testing for exception
		{
			
		
			int numbers[]=null;
			
			Arrays.sort(numbers);		
			
			//..............or/////
		}

		
		
		//@Test(expected=NullPointerException.class)
		@Test()		//using normal Test because it doesn't give any exception
		public void doEmptyArrayExceptionTest() 		//testing for exception
		{
			
		
			int numbers[]={};
			
			Arrays.sort(numbers);		
			
			//..............or/////
		}

		
}

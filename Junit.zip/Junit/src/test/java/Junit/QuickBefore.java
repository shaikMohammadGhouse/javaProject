package Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class QuickBefore {

	
	
	StringHelper helper;
	
	@Before
	public void beforeTest()
	{
		helper=new StringHelper();
		System.out.println("running before test..");
		//means.... eveery time befoore a test case is executed the helper instance is created
			
	}
	
	
	
	@Test
	public void testTruncateAInFirst2Positions()
	{		
		
		System.out.println("running testTruncate");
		assertEquals("CD",helper.truncateAInFirst2Positions("AACD"));
		//assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		
		assertEquals("CDAA",helper.truncateAInFirst2Positions("CDAA"));
		//assertEquals("CDc",helper.truncateAInFirst2Positions("AACD"));
	
		
		//AACD=>CD 	ACD=>CD 	CDEF=>CDEF   CDAA=>CDAA)
	
	}
	
	@Test
	public void test2()
	{
		
		System.out.println("running test2");
		assertEquals("CDEF",helper.truncateAInFirst2Positions("CDEF"));
		assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
	}

	
	
	@After
	public void tearDown()
	{
		
		System.out.println("running ... tearDown..closing the connection to test case...");
		//usually used to close the connection once we are done with the test
	}
	
}
 
package Junit;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class ArrayCompareTest {

	
	//to import array class and to check wether the sorting technique is working fine or not.
	
	@Test
	public void testArraySort() 
	{
		
	
		int numbers[]={10,50,60,78,23};
		int expected[]={10,23,50,60,78}; 
		Arrays.sort(numbers);

		//assertEquals(expected, numbers);	//compaers the object of the array... so returns false..
		
		//to check the array values we need to use funvction
		//assertArrayEquals()
		assertArrayEquals(expected, numbers);
		
		assertArrayEquals(�message�, A, B);
		
		//System.out.println(numbers);
		System.out.println("running the test");
	}

}

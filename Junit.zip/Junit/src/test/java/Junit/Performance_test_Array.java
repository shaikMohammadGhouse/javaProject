package Junit;



import static org.junit.Assert.assertArrayEquals;

import java.util.Arrays;

import org.junit.Test;

public class Performance_test_Array 
{
	@Test
	public void testArraySort() 
	{
		int numbers[]={10,50,60,78,23};
		int expected[]={10,23,50,60,78}; 
		Arrays.sort(numbers);
		assertArrayEquals(expected, numbers);
		System.out.println("running the test");
	}
	
	
	
	@Test(expected=NullPointerException.class)
	public void doNullArrayExceptionTestImp() 		//testing for exception
	{
		int numbers[]=null;
		Arrays.sort(numbers);		
	}

	
	@Test
	public void doEmptyArrayExceptionTest() 		//testing for exception
	{
		int numbers[]={};
		Arrays.sort(numbers);		
	}
	
	
	
	
	
	//Performance........of array.sort.... testing..
	//sorting of able to run 1 million sorts of array 3 element each in less than 10 mili sec.
	
	
	@Test(timeout=100)		//100milliseconds
	public void testSort_Performance()
	{
		int array[]={12,23,4};
		for(int i=1;i<=100000;i++)
		{
			array[0]=i;
			Arrays.sort(array);
		}
	}
	
	

}

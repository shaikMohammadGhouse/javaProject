package Junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringHelperTest {

	
	
	StringHelper helper =new StringHelper();
	@Test
	public void testTruncateAInFirst2Positions()
	{		
		
		assertEquals("CD",helper.truncateAInFirst2Positions("AACD"));
		//assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		
		assertEquals("CDAA",helper.truncateAInFirst2Positions("CDAA"));
		//assertEquals("CDc",helper.truncateAInFirst2Positions("AACD"));
	
		
		//AACD=>CD 	ACD=>CD 	CDEF=>CDEF   CDAA=>CDAA)
	
	}
	
	
	
	
	@Test
	public void test2()
	{

		assertEquals("CDEF",helper.truncateAInFirst2Positions("CDEF"));
		assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
	}

	
	
	
	
	
	
	
	
	//ABCD => false  AB=> true  ABAB=> true  A=> false
	@Test
	public void testAreFirstAndLastTwoCharactersTheSame()
	{
		//Expected........Actual..
		
		boolean actual1=helper.areFirstAndLastTwoCharactersTheSame("ABCD");
		assertEquals(false,actual1);
		
		boolean actual2=helper.areFirstAndLastTwoCharactersTheSame("ABAB");
		assertEquals(true,actual2);
		
		assertEquals(true,helper.areFirstAndLastTwoCharactersTheSame("AB"));
		
		assertEquals(false,helper.areFirstAndLastTwoCharactersTheSame("A"));
		
		
		
		//so as output is boolean 
		// we can also use... assertFalse() assertTrue methodes directly,..
		
		assertFalse(helper.areFirstAndLastTwoCharactersTheSame("A"));
		
		assertTrue(helper.areFirstAndLastTwoCharactersTheSame("AB"));
		//assertFalse() is used to write own message to print if any condition fails....
		//assertFalse("yes its true so dont be worry your test is passed...",true);
		//assertFalse("sorry its false here so your test case is fail.. check your code..",false);
		
	}
	
	
	
	
	
	
	
	
	
}
 
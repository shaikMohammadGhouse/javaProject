before after class for junit are used to to make some change which can be used before entire class.. or after entire class....






TEST Suite..... they are used to test for a particular test classes out of all test classes..
by grouping them. and forming a suite of them.


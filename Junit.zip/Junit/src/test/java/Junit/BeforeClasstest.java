package Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BeforeClasstest {

	
	
	
		@BeforeClass
		public static void beforeClass()				//always static
		{
			System.out.println("before class......");
		}
	
		
		@AfterClass
		public static void afterClass()				//always static
		{
			System.out.println("after class......");
		}
		
		@Before
		public void beforeTest()
		{
			System.out.println("running before test..");
			//means.... eveery time befoore a test case is executed the helper instance is created
				
		}
		
		
		
		@Test
		public void testTruncateAInFirst2Positions()
		{		
			
			System.out.println("running testTruncate");
			
		}
		
		@Test
		public void test2()
		{
			
			System.out.println("running test2");
			
		}

		
		
		@After
		public void tearDown()
		{
			
			System.out.println("running ... tearDown..closing the connection to test case...");
		
		}
		
	 
}

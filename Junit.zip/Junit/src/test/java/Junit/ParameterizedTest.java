package Junit;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;



@RunWith(Parameterized.class)		//to define the class has a parameterized test that is this class is not a normal test class
									//should also define the parameters... which are need to be used..
public class ParameterizedTest 
{
	
	StringHelper helper=new StringHelper();
	private String input;
	private String expectedOutput;
	
	
	
	
	public ParameterizedTest( String input, String expectedOutput) {
		super();
		this.input = input;
		this.expectedOutput = expectedOutput;
	}


	@Parameters
	public static Collection<String[]> testConditions()
	{
		String expectedOutputs[][]={{"AACD","CD"},{"ACD","CD"}};
		
		return Arrays.asList(expectedOutputs);
	}
	
	
	//AACD=>CD 	ACD=>CD 	CDEF=>CDEF   CDAA=>CDAA)
	
	@Test
	public void testTruncateAInFirst2Positions()
	{		
		
		assertEquals(expectedOutput,helper.truncateAInFirst2Positions(input));
		//assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		
		assertEquals(expectedOutput,helper.truncateAInFirst2Positions(input));
		//assertEquals("CDc",helper.truncateAInFirst2Positions("AACD"));
	
	
	}
	
	
	
	
	
	
	
}
 
// $(window).load(function()
// {
//     console.log("iam working");
//     var c=confirm('Are you sure tou want to leave.....?');
//     if(c)
//     {
//         return true;
//     }
//     else{
//         return false;
//     }
     
// });

$(window).on('beforeunload', function(){
             alert("beforeUnload event!");
         }); 
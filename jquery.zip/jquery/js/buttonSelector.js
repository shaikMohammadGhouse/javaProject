$(':submit').click(function(){
    $(this).attr('value','please wait.......');
});


$(document).ready(function(){
$('#message').fadeIn('slow');


})
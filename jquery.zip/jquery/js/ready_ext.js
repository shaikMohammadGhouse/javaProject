$(document).ready(function(){
    //here
    alert('Document is ready to load...');
});

alert('he he iam allso getting loaded...');
$('iframe').load(function(){
alert('iframe loaded');

});
// alert('going to load image...');

// $(document).ready(function(){

//    // $('#image').fadeIn('slow');
// });

 
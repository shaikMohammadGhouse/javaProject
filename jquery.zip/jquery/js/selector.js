$('p').click();
//('p')............... selector for <p> tag 
///$("#para").click();................for ID
$('#paragraph').click(function(){
    $('#paragraph').hide();
});
// var count = $('*').length;           ...........for all
// alert(count);



// var count = $('#').length;              ....for  id's
// alert(count);


    // var count = $('#area').length;              ... for particular id/
    // alert(count);


    var count = $('#area').find('*').length;
    alert(count);
$(':button').click(function()
{
   $('p').css('background-color','yellow').css('color','blue');
});


$(':text').focusin(function(){
    $(this).css('background-color', 'yellow');
    });
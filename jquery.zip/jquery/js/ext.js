// $(iframe).load(function()
// {
// alert("loaded")
// });



$(document).load(function()
{

})
var name1=$('#name').val();
console.log(name1);
var text=$('#text').text();
console.log(text);
$('#click').click(function()
{
alert('Hello man');

});
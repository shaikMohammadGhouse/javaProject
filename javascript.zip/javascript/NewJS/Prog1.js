myName="shaik";

var state="karnantaka";

console.log("my name is"+ myName);

state="andhra";


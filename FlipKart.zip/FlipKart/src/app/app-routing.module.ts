import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { ContentComponent } from './content/content.component';
import { Content1Component } from './content1/content1.component';
import { CartComponent } from './cart/cart.component';

const routes: Routes = [

   /* {path: '', redirectTo: 'content', pathMatch: 'full'},

    {
      path: 'content',
     component: ContentComponent
    },*/
    {path: '', component: ContentComponent},

    {
      path: 'content1',
     component: Content1Component
    },
    {
      path: 'cart',
      component: CartComponent

    },
       // path: 'employee',
       //  {
     // path: 'songs',
    // component: SongsComponent
    //},
        {path: '**', redirectTo: 'content1', pathMatch: 'full'}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {

  constructor()
  {

  }
}

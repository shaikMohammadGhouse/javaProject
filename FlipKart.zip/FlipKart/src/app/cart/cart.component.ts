import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartProducts: any =[]
  constructor(private http: HttpClient) {
    this.http.get('https://api.myjson.com/bins/117183')
      .subscribe(res => {
        this.cartProducts = res;
        console.log(this.cartProducts);
       });
   }
     
  ngOnInit() 
  {
      console.log(this.cartProducts);
  }


}

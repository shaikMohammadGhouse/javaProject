import { Injectable } from '@angular/core';

@Injectable()
export class MyDataService {

  constructor() { }

 obj={
   id :"1",
   name:"shaik",
   rollno:"2345"
 }

  success()
  {
    return "successfull"; 
  }

}

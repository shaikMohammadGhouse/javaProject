import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-content1',
  templateUrl: './content1.component.html',
  styleUrls: ['./content1.component.css']
})
export class Content1Component implements OnInit {

  products: any = [];

  selectedProduct: any= '';
   constructor(private http: HttpClient ,private router: Router)
   {

      this.http.get('https://api.myjson.com/bins/indqb')
      .subscribe(res => {
        this.products = res;
        console.log(this.products);
       });



    }

      onDivert=()=>
      {
        this.router.navigate(['/cart']);
      };

        addOn=(i)=>
      {
        this.selectedProduct=this.products[i];
        console.log(this.selectedProduct);
        this.router.navigate(['/cart']);
      };
         
  ngOnInit() 
  {
      console.log(this.products);
  }


}

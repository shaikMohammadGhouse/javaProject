import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpClientModule} from '@angular/common/http';
// import {MdCardModule} from '@';
// import {MdButtonModuele} from '';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ContentComponent } from './content/content.component';
import { MyDataService } from '../app/my-data.service';
import { Content1Component } from './content1/content1.component';
import { AppRoutingModule } from './app-routing.module';
import { CartComponent } from './cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ContentComponent,
    Content1Component,
    CartComponent
  ],
  imports: [
    // MdCardModule,
    BrowserModule,
  AppRoutingModule,
  HttpClientModule
  ],
  providers: [MyDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }

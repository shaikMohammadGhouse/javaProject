import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
// import { ViewModule } from "../view/view.module";
import { ModalModule } from "ngx-bootstrap";
import { AdminSideBarComponent } from './admin-side-bar/admin-side-bar.component';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { AppRoutingModule } from "../app-routing.module";
import { HotelAdminSidebarComponent } from './hotel-admin-sidebar/hotel-admin-sidebar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatFormField, MatCardModule, MatMenuModule, MatToolbarModule, MatIconModule, MatInputModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MybookingComponent } from "../view/mybooking/mybooking.component";
import {MatSnackBarModule} from '@angular/material/snack-bar';



@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
     MatButtonModule,
     MatButtonModule,
    MatMenuModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSnackBarModule,
    // ViewModule,
    ModalModule.forRoot()
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    AdminSideBarComponent,
    AdminHeaderComponent,
    HotelAdminSidebarComponent,
   
    
    ],
  exports: [
        HeaderComponent,
        FooterComponent,
        AdminSideBarComponent,
        AdminHeaderComponent,
        HotelAdminSidebarComponent,
        // ViewModule
    ],
    providers: [
        
    ],
})
export class CoreModule { }

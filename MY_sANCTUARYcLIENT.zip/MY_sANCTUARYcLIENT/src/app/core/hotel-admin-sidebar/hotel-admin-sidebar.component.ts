import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotel-admin-sidebar',
  templateUrl: './hotel-admin-sidebar.component.html',
  styleUrls: ['./hotel-admin-sidebar.component.css']
})
export class HotelAdminSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
  }
  
}

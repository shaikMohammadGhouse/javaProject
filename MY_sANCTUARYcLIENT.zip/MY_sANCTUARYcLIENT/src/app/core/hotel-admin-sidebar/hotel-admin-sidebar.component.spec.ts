import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelAdminSidebarComponent } from './hotel-admin-sidebar.component';

describe('HotelAdminSidebarComponent', () => {
  let component: HotelAdminSidebarComponent;
  let fixture: ComponentFixture<HotelAdminSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HotelAdminSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelAdminSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService,BsModalRef } from "ngx-bootstrap";
import { FormGroup, FormBuilder, Validators,ReactiveFormsModule } from "@angular/forms";
import { Router } from "@angular/router";
import { AppRoutingModule } from "../../app-routing.module";
import { Http } from "@angular/http";
import {MatSnackBar} from '@angular/material';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  modalRef: BsModalRef;
  hide = true;
   rForm: FormGroup;      
   data:any[];              // A property for our submitted form
  password:string = '';
  email:string = '';
  customers:any;
  status:boolean=false;
  constructor(private modalService: BsModalService, private fb:FormBuilder, private router:Router, private http:Http,public snackBar: MatSnackBar) {
     this.rForm = fb.group({
      'email': [null, Validators.compose([Validators.required, Validators.email])],
      'password': [null, Validators.required],
    });

    this.http.get("https://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/getallcustomers").subscribe(
      res => {
        this.data=res.json();
      }
    );
   }

  ngOnInit() {
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  onSubmit(){
    this.data.forEach(element => {
      if (this.rForm.get('email').value == element.email) {
        if (this.rForm.get('password').value == element.password) {
          this.status=true;
        }
      }
    });
    if (this.status==true) {
    this.router.navigate(['mybooking']);
  }
  else {
    this.status=false;
  }
}
test(){
  console.log("test");
}


}

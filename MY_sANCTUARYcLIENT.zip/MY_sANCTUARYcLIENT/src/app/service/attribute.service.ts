import { Injectable } from '@angular/core';


import { findIndex } from 'lodash';
import { ATTRIBUTE_ITEMS } from "./attributes-data";
import { Attribute } from "./attributes";

@Injectable()
export class AttributeService {

private pItems = ATTRIBUTE_ITEMS;

  getProductsFromData(): Attribute[] {
    console.log(this.pItems);
    return this.pItems
  }

  addProduct(product: Attribute) {
    this.pItems.push(product);
    console.log(this.pItems);
  }

  updateProduct(product: Attribute) {
    let index = findIndex(this.pItems, (p: Attribute) => {
      return p.id === product.id;
    });
    this.pItems[index] = product;
  }

  deleteProduct(product: Attribute) {
    this.pItems.splice(this.pItems.indexOf(product), 1);
    console.log(this.pItems);
  }
  constructor() { }

}

import { Attribute } from './attributes';

export const ATTRIBUTE_ITEMS: Attribute[] = [{
    id: 1,
    name: 'Board Room',
    price: 4.99,
    currentActiveBooking: 5,
    hotelName: 'The Sanctuary- Sydney'
  }, {
    id: 2,
    name: 'Sound Box',
    price: 10.99,
    currentActiveBooking: 12,
    hotelName: 'The Sanctuary- Sydney'
  }, {
    id: 3,
    name: 'Projector',
    price: 5.99,
    currentActiveBooking: 15,
    hotelName: 'The Sanctuary- Melbourne'
  }]
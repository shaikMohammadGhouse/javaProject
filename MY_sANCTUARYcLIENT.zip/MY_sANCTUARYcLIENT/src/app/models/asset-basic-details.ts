export class AssetBasicDetails{
    hotelMaster: any;
    assetName: any;
    assetType: any;
    locationInHotel: any;
    dimensionsLength: any;
    dimensionsWidth: any;
    dimensionsHeight: any;
    maxGuests: any;
    unitOfMeasure: any;
    basePrice: any
    
};
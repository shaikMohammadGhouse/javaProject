import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoreModule } from "./core/core.module";

import { HomeviewComponent } from './view/homeview/homeview.component';
import { AboutviewComponent } from './view/aboutview/aboutview.component';
import { SearchviewComponent } from "./view/searchview/searchview.component";
import { AdminViewComponent } from "./view/admin-view/admin-view.component";
import { AddAssetViewComponent } from "./view/add-asset-view/add-asset-view.component";
import { MasterDataViewComponent } from "./view/master-data-view/master-data-view.component";
import { DeleteAssetViewComponent} from "./view/delete-asset-view/delete-asset-view.component";
import { ViewAssetViewComponent } from "./view/view-asset-view/view-asset-view.component";
import { HotelAdminViewComponent } from "./view/hotel-admin-view/hotel-admin-view.component";
import { ViewAssetHotelAdminComponent } from "./view/view-asset-hotel-admin/view-asset-hotel-admin.component";
import { ViewBookingsHotelAdminComponent } from "./view/view-bookings-hotel-admin/view-bookings-hotel-admin.component";
import { ItAdminLoginComponent } from "./view/it-admin-login/it-admin-login.component";
import { HotelAdminLoginComponent } from "./view/hotel-admin-login/hotel-admin-login.component";
import { MybookingComponent } from "./view/mybooking/mybooking.component";


import { ChooseAmenitiesViewComponent } from "./view/choose-amenities-view/choose-amenities-view.component";
import { HotelAmenitiesFormComponent } from "./view/hotel-amenities-form/hotel-amenities-form.component";
import { AssetAmenitiesFormComponent } from "./view/asset-amenities-form/asset-amenities-form.component";


const routes: Routes = [
    {path:'',redirectTo:'home',pathMatch:'full'},
    {
      path:'home',
      component:HomeviewComponent
    },
    {
      path:'mybooking',
      component:MybookingComponent
    },
      {
      path:'it-admin-login',
      component:ItAdminLoginComponent
     },
      {
      path:'hotel-admin-login',
      component:HotelAdminLoginComponent
     },
     {
      path:'hoteladmin',
      component:HotelAdminViewComponent,
      children:[
        {
          path:'viewAssets',
          component:ViewAssetHotelAdminComponent,
        },
        {
          path:'viewBookings',
          component:ViewBookingsHotelAdminComponent,
        },
      ]
    },
    {path:'admin',redirectTo:'it-admin-login',pathMatch:'full'},
    {
      path:'itadmin',
      component:AdminViewComponent,
      children:[
        {
          path:'deleteAsset',
          component:DeleteAssetViewComponent,
        },
        {
          path:'viewAssets',
          component:ViewAssetViewComponent,
        },
        {
          path:'addAsset',
          component:AddAssetViewComponent,
          children:[
            {
              path:'hotelAmenities',
          component:HotelAmenitiesFormComponent,
            },
            {
              path:'assetAmenities',
            component: AssetAmenitiesFormComponent,
            },
          ]
        },
      ]
    },
    {
      path:'about',
      component:AboutviewComponent
    },
    {
      path:'search',
      component:SearchviewComponent
    },
    {
      path:'chooseamenities',
      component:ChooseAmenitiesViewComponent
    },
    {
      path:'hotelamenities',
      component:HotelAmenitiesFormComponent
    },
    { 
      path:'**',
      redirectTo:'home',
      pathMatch:'full'
    }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes, {useHash:true}) ],
  exports: [RouterModule]
  
})
export class AppRoutingModule { }
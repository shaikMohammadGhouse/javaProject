import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotel-admin-view',
  templateUrl: './hotel-admin-view.component.html',
  styleUrls: ['./hotel-admin-view.component.css']
})
export class HotelAdminViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-searchview',
  templateUrl: './searchview.component.html',
  styleUrls: ['./searchview.component.css']
})

export class SearchviewComponent implements OnInit {

 divContent: any = [];

  details: any= '';

 minDate = new Date();



  selected: string;
  states: string[] = [
    'Adelaide',
    'Sydney',
    'Melbourne',
    'Brisbane',
    'Perth',
    'Darwin',
    'Canberra',
    'Howart',
    'Cairns',
    'Wagga Wagga',
    'Dubbo',
    'Mildura',
    'Auckland',
    'Wellington',
    'Christchurch',
    'Dunedin',
    'Hamilton',
    'Nelson',
    'Napier',
    'Maryland',
    'Massachusetts',
    'Michigan',
    'Minnesota',
    'Mississippi',
    'Missouri',
    'Montana',
    'Nebraska',
    'Nevada',
    'New Hampshire',
    'New Jersey',
    'New Mexico',
    'New York',
    'North Dakota',
    'North Carolina',
    'Ohio',
    'Oklahoma',
    'Oregon',
    'Pennsylvania',
    'Rhode Island',
    'South Carolina',
    'South Dakota',
    'Tennessee',
    'Texas',
    'Utah',
    'Vermont',
    'Virginia',
    'Washington',
    'West Virginia',
    'Wisconsin',
    'Wyoming'
  ];

  constructor(private http: HttpClient , private router: Router)
  {

       this.http.get('https://api.myjson.com/bins/1257xn')
      .subscribe(res => {
        this.divContent = res;
  
       });

  }

routing()
{
  this.router.navigate(['/search']);
}
  ngOnInit() {
  

   }



   

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeview',
  templateUrl: './homeview.component.html',
  styleUrls: ['./homeview.component.css']
})
export class HomeviewComponent implements OnInit {

  minDate = new Date();

  selected: string;
  states: string[] = [
    'Adelaide',
    'Sydney',
    'Melbourne',
    'Brisbane',
    'Perth',
    'Darwin',
    'Canberra',
    'Howart',
    'Cairns',
    'Wagga Wagga',
    'Dubbo',
    'Mildura',
    'Auckland',
    'Wellington',
    'Christchurch',
    'Dunedin',
    'Hamilton',
    'Nelson',
    'Napier',
    'Maryland',
    'Massachusetts',
    'Michigan',
    'Minnesota',
    'Mississippi',
    'Missouri',
    'Montana',
    'Nebraska',
    'Nevada',
    'New Hampshire',
    'New Jersey',
    'New Mexico',
    'New York',
    'North Dakota',
    'North Carolina',
    'Ohio',
    'Oklahoma',
    'Oregon',
    'Pennsylvania',
    'Rhode Island',
    'South Carolina',
    'South Dakota',
    'Tennessee',
    'Texas',
    'Utah',
    'Vermont',
    'Virginia',
    'Washington',
    'West Virginia',
    'Wisconsin',
    'Wyoming'
  ];

  constructor() { }

  ngOnInit() {
  }

}

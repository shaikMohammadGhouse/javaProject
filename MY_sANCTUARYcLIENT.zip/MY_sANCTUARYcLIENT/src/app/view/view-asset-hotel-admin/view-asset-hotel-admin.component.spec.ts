import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAssetHotelAdminComponent } from './view-asset-hotel-admin.component';

describe('ViewAssetHotelAdminComponent', () => {
  let component: ViewAssetHotelAdminComponent;
  let fixture: ComponentFixture<ViewAssetHotelAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAssetHotelAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAssetHotelAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAmenitiesFormComponent } from './asset-amenities-form.component';

describe('AssetAmenitiesFormComponent', () => {
  let component: AssetAmenitiesFormComponent;
  let fixture: ComponentFixture<AssetAmenitiesFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetAmenitiesFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetAmenitiesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AssetBasicDetails } from '../../models/asset-basic-details';
import { Http } from '@angular/http';
import { AssetAmenityDetails } from '../../models/asset-amenity-details';

@Component({
  selector: 'app-asset-amenities-form',
  templateUrl: './asset-amenities-form.component.html',
  styleUrls: ['./asset-amenities-form.component.css']
})
export class AssetAmenitiesFormComponent implements OnInit {

  form = new FormGroup({
    assetName: new FormControl('', [Validators.required]),
    assetType: new FormControl('', []),
    locationInHotel: new FormControl('', [Validators.required]),
    length: new FormControl('', [Validators.required]),
    width: new FormControl('', [Validators.required]),
    height: new FormControl('', [Validators.required]),
    noOfGuest: new FormControl('', [Validators.required]),
    unitOfMeasure: new FormControl('', []),
    unitPrice: new FormControl('', [Validators.required])
  });

  get assetName() {
    return this.form.get('assetName');
  }

  get assetType() {
    return this.form.get('assetType');
  }

  get locationInHotel() {
    return this.form.get('locationInHotel');
  }

  get length() {
    return this.form.get('length');
  }

  get width() {
    return this.form.get('width');
  }

  get height() {
    return this.form.get('height');
  }

  get noOfGuest() {
    return this.form.get('noOfGuest');
  }

  get unitOfMeasure() {
    return this.form.get('unitOfMeasure');
  }

  get unitPrice() {
    return this.form.get('unitPrice');
  }


  room =new FormGroup({
    acRadio: new FormControl('', []),
    airConditionerUnitOfMeasure: new FormControl('', []),
    airConditionerUnitPrice: new FormControl('', [Validators.required]),
    lecternRadio: new FormControl('', []),
    lecternUnitOfMeasure: new FormControl('', []),
    lecternUnitPrice: new FormControl('', [Validators.required]),
    lecternQuantifcication: new FormControl('', []),
    roomControlRadio: new FormControl('', []),
    roomControlUnitOfMeasure: new FormControl('', []),
    roomControlUnitPrice: new FormControl('', [Validators.required]),
    stagingRadio: new FormControl('', []),
    stagingUnitOfMeasure: new FormControl('', []),
    stagingUnitPrice: new FormControl('', [Validators.required]),
    underFloorHeatingRadio: new FormControl('', []),
    underFloorHeatingUnitOfMeasure: new FormControl('', []),
    underFloorHeatingUnitPrice: new FormControl('', [Validators.required]),
  });

  get acRadio() {
    return this.room.get('acRadio');
  }

  get airConditionerUnitOfMeasure() {
    return this.room.get('airConditionerUnitOfMeasure');
  }

  get airConditionerUnitPrice() {
    return this.room.get('airConditionerUnitPrice');
  }

  get lecternRadio() {
    return this.room.get('lecternRadio');
  }

  get lecternUnitOfMeasure() {
    return this.room.get('lecternUnitOfMeasure');
  }

  get lecternUnitPrice() {
    return this.room.get('lecternUnitPrice');
  }

  get lecternQuantifcication() {
    return this.room.get('lecternQuantifcication');
  }

  get roomControlRadio() {
    return this.room.get('roomControlRadio');
  }

  get roomControlUnitOfMeasure() {
    return this.room.get('roomControlUnitOfMeasure');
  }

  get roomControlUnitPrice() {
    return this.room.get('roomControlUnitPrice');
  }

  get stagingRadio() {
    return this.room.get('stagingRadio');
  }

  get stagingUnitOfMeasure() {
    return this.room.get('stagingUnitOfMeasure');
  }

  get stagingUnitPrice() {
    return this.room.get('stagingUnitPrice');
  }

  get underFloorHeatingRadio() {
    return this.room.get('underFloorHeatingRadio');
  }

  get underFloorHeatingUnitOfMeasure() {
    return this.room.get('underFloorHeatingUnitOfMeasure');
  }

  get underFloorHeatingUnitPrice() {
    return this.room.get('underFloorHeatingUnitPrice');
  }

  sound=new FormGroup({
    amplifierRadio: new FormControl('', []),
    amplifierUnitOfMeasure: new FormControl('', []),
    amplifierUnitPrice: new FormControl('', [Validators.required]),
    autoCueRadio: new FormControl('', []),
    autoCueUnitOfMeasure: new FormControl('', []),
    autoCueUnitPrice: new FormControl('', [Validators.required]),
    karaokeRadio: new FormControl('', []),
    karaokeUnitOfMeasure: new FormControl('', []),
    karaokeUnitPrice: new FormControl('', [Validators.required]),
    microPhoneRadio: new FormControl('', []),
    microPhoneUnitOfMeasure: new FormControl('', []),
    microPhoneUnitPrice: new FormControl('', [Validators.required]),
    microPhoneQuantification: new FormControl('', []),
    paSystemRadio: new FormControl('', []),
    paSystemUnitOfMeasure: new FormControl('', []),
    paSystemUnitPrice: new FormControl('', [Validators.required]),
  })

   get amplifierRadio() {
    return this.sound.get('amplifierRadio');
  }

   get amplifierUnitOfMeasure() {
    return this.sound.get('amplifierUnitOfMeasure');
  }

   get amplifierUnitPrice() {
    return this.sound.get('amplifierUnitPrice');
  }

   get autoCueRadio() {
    return this.sound.get('autoCueRadio');
  }

   get autoCueUnitOfMeasure() {
    return this.sound.get('autoCueUnitOfMeasure');
  }

   get autoCueUnitPrice() {
    return this.sound.get('autoCueUnitPrice');
  }

   get karaokeRadio() {
    return this.sound.get('karaokeRadio');
  }

   get karaokeUnitOfMeasure() {
    return this.sound.get('karaokeUnitOfMeasure');
  }

   get karaokeUnitPrice() {
    return this.sound.get('karaokeUnitPrice');
  }

   get microPhoneRadio() {
    return this.sound.get('microPhoneRadio');
  }

   get microPhoneUnitOfMeasure() {
    return this.sound.get('microPhoneUnitOfMeasure');
  }

   get microPhoneUnitPrice() {
    return this.sound.get('microPhoneUnitPrice');
  }

  get microPhoneQuantification() {
    return this.sound.get('microPhoneQuantification');
  }

  get paSystemRadio() {
    return this.sound.get('paSystemRadio');
  }

  get paSystemUnitOfMeasure() {
    return this.sound.get('paSystemUnitOfMeasure');
  }

  get paSystemUnitPrice() {
    return this.sound.get('paSystemUnitPrice');
  }

  electrical=new FormGroup({
    socketsRadio: new FormControl('', []),
    socketsUnitOfMeasure: new FormControl('', []),
    socketsUnitPrice: new FormControl('', [Validators.required]),
  });

  get socketsRadio() {
    return this.electrical.get('socketsRadio');
  }

  get socketsUnitOfMeasure() {
    return this.electrical.get('socketsUnitOfMeasure');
  }

  get socketsUnitPrice() {
    return this.electrical.get('socketsUnitPrice');
  }

  lighting=new FormGroup({
    blackOutControlRadio: new FormControl('', []),
    blackOutControlUnitOfMeasure: new FormControl('', []),
    blackOutControlUnitPrice: new FormControl('', [Validators.required]),
    dimmersRadio:  new FormControl('', []),
    dimmersUnitOfMeasure: new FormControl('', []),
    dimmersUnitPrice: new FormControl('', [Validators.required]),
    naturalDayLightRadio: new FormControl('', []),
    naturalDayLightUnitOfMeasure: new FormControl('', []),
    naturalDayLightUnitPrice: new FormControl('', [Validators.required]),
    soundSystemRadio: new FormControl('', []),
    soundSystemUnitOfMeasure: new FormControl('', []),
    soundSystemUnitPrice: new FormControl('', [Validators.required]),
    warmLightRadio: new FormControl('', []),
    warmLightUnitOfMeasure: new FormControl('', []),
    warmLightUnitPrice: new FormControl('', [Validators.required]),
    coolLightRadio: new FormControl('', []),
    coolLigtUnitOfMeasure: new FormControl('', []),
    coolLightUnitPrice: new FormControl('', [Validators.required]),
  });

  get blackOutControlRadio() {
    return this.lighting.get('blackOutControlRadio');
  }

  get blackOutControlUnitOfMeasure() {
    return this.lighting.get('blackOutControlUnitOfMeasure');
  }

  get blackOutControlUnitPrice() {
    return this.lighting.get('blackOutControlUnitPrice');
  }

  get dimmersRadio() {
    return this.lighting.get('dimmersRadio');
  }

  get dimmersUnitOfMeasure() {
    return this.lighting.get('dimmersUnitOfMeasure');
  }

  get dimmersUnitPrice() {
    return this.lighting.get('dimmersUnitPrice');
  }

  get naturalDayLightRadio() {
    return this.lighting.get('naturalDayLightRadio');
  }

  get naturalDayLightUnitOfMeasure() {
    return this.lighting.get('naturalDayLightUnitOfMeasure');
  }

  get naturalDayLightUnitPrice() {
    return this.lighting.get('naturalDayLightUnitPrice');
  }

  get soundSystemRadio() {
    return this.lighting.get('soundSystemRadio');
  }

  get soundSystemUnitOfMeasure() {
    return this.lighting.get('soundSystemUnitOfMeasure');
  }

  get soundSystemUnitPrice() {
    return this.lighting.get('soundSystemUnitPrice');
  }

  get warmLightRadio() {
    return this.lighting.get('warmLightRadio');
  }

  get warmLightUnitOfMeasure() {
    return this.lighting.get('warmLightUnitOfMeasure');
  }

  get warmLightUnitPrice() {
    return this.lighting.get('warmLightUnitPrice');
  }

  get coolLightRadio() {
    return this.lighting.get('coolLightRadio');
  }

  get coolLigtUnitOfMeasure() {
    return this.lighting.get('coolLigtUnitOfMeasure');
  }

  get coolLightUnitPrice() {
    return this.lighting.get('coolLightUnitPrice');
  }

  computing=new FormGroup({
    computerRadio: new FormControl('', []),
    computerUnitOfMeasure: new FormControl('', []),
    computerUnitPrice: new FormControl('', [Validators.required]),
    dvdRadio: new FormControl('', []),
    dvdUnitOfMeasure: new FormControl('', []),
    dvdUnitPrice: new FormControl('', [Validators.required]),
    gameConsoleRadio: new FormControl('', []),
    gameConsoleUnitOfMeasure: new FormControl('', []),
    gameConsoleUnitPrice: new FormControl('', [Validators.required]),
    lcdScreenRadio: new FormControl('', []),
    lcdScreenUnitOfMeasure: new FormControl('', []),
    lcdScreenUnitPrice: new FormControl('', [Validators.required]),
    lcdQuantification: new FormControl('', []),
    printerRadio: new FormControl('', []),
    printerUnitOfMeasure: new FormControl('', []),
    printerUnitPrice: new FormControl('', [Validators.required]),
    printerQuantification: new FormControl('', []),
    projectorRadio: new FormControl('', []),
    projectorUnitOfMeasure: new FormControl('', []),
    projectorUnitPrice: new FormControl('', [Validators.required]),
    projectorQuantification: new FormControl('', []),
    videoConferencingRadio: new FormControl('', []),
    videoConferencingUnitOfMeasure: new FormControl('', []),
    videoConferencingUnitPrice: new FormControl('', [Validators.required]),
    whiteScreenRadio: new FormControl('', []),
    whiteScreenUnitOfMeasure: new FormControl('', []),
    whiteScreenUnitPrice: new FormControl('', [Validators.required]),
    whiteScreenQuantification: new FormControl('', []),
    wifiRadio: new FormControl('', []),
    wifiUnitOfMeasure: new FormControl('', []),
    wifiUnitPrice: new FormControl('', [Validators.required]),
    lanCableRadio: new FormControl('', []),
    lanCableUnitOfMeasure: new FormControl('', []),
    lanCableUnitPrice: new FormControl('', [Validators.required]),
    photoCopierRadio: new FormControl('', []),
    photoCopierUnitOfMeasure: new FormControl('', []),
    photoCopierUnitPrice: new FormControl('', [Validators.required]),
    photoCopierQuantification: new FormControl('', []),
  });

  get computerRadio() {
    return this.computing.get('computerRadio');
  }

  get computerUnitOfMeasure() {
    return this.computing.get('computerUnitOfMeasure');
  }

  get computerUnitPrice() {
    return this.computing.get('computerUnitPrice');
  }

  get dvdRadio() {
    return this.computing.get('dvdRadio');
  }

  get dvdUnitOfMeasure() {
    return this.computing.get('dvdUnitOfMeasure');
  }

  get dvdUnitPrice() {
    return this.computing.get('dvdUnitPrice');
  }

  get gameConsoleRadio() {
    return this.computing.get('gameConsoleRadio');
  }

  get gameConsoleUnitOfMeasure() {
    return this.computing.get('gameConsoleUnitOfMeasure');
  }

  get gameConsoleUnitPrice() {
    return this.computing.get('tennis');
  }

  get lcdScreenRadio() {
    return this.computing.get('lcdScreenRadio');
  }

  get lcdScreenUnitOfMeasure() {
    return this.computing.get('lcdScreenUnitOfMeasure');
  }

  get lcdScreenUnitPrice() {
    return this.computing.get('lcdScreenUnitPrice');
  }

  get (lcdQuantification) {
    return this.computing.get('lcdQuantification');
  }

  get printerRadio() {
    return this.computing.get('printerRadio');
  }

  get printerUnitOfMeasure() {
    return this.computing.get('printerUnitOfMeasure');
  }

  get printerUnitPrice() {
    return this.computing.get('printerUnitPrice');
  }

  get printerQuantification() {
    return this.computing.get('printerQuantification');
  }

  get projectorRadio() {
    return this.computing.get('projectorRadio');
  }

  get projectorUnitOfMeasure() {
    return this.computing.get('projectorUnitOfMeasure');
  }

  get projectorUnitPrice() {
    return this.computing.get('projectorUnitPrice');
  }

  get projectorQuantification() {
    return this.computing.get('projectorQuantification');
  }

  get videoConferencingRadio() {
    return this.computing.get('videoConferencingRadio');
  }

  get videoConferencingUnitOfMeasure() {
    return this.computing.get('videoConferencingUnitOfMeasure');
  }

  get videoConferencingUnitPrice() {
    return this.computing.get('videoConferencingUnitPrice');
  }

  get whiteScreenRadio() {
    return this.computing.get('whiteScreenRadio');
  }

  get whiteScreenUnitOfMeasure() {
    return this.computing.get('whiteScreenUnitOfMeasure');
  }

  get whiteScreenUnitPrice() {
    return this.computing.get('whiteScreenUnitPrice');
  }

  get whiteScreenQuantification() {
    return this.computing.get('whiteScreenQuantification');
  }

  get wifiRadio() {
    return this.computing.get('wifiRadio');
  }

  get wifiUnitOfMeasure() {
    return this.computing.get('wifiUnitOfMeasure');
  }

  get wifiUnitPrice() {
    return this.computing.get('wifiUnitPrice');
  }

  get lanCableRadio() {
    return this.computing.get('lanCableRadio');
  }

  get lanCableUnitOfMeasure() {
    return this.computing.get('lanCableUnitOfMeasure');
  }

  get lanCableUnitPrice() {
    return this.computing.get('lanCableUnitPrice');
  }

  get photoCopierRadio() {
    return this.computing.get('photoCopierRadio');
  }

  get photoCopierUnitOfMeasure() {
    return this.computing.get('photoCopierUnitOfMeasure');
  }

  get photoCopierUnitPrice() {
    return this.computing.get('photoCopierUnitPrice');
  }

  get photoCopierQuantification() {
    return this.computing.get('photoCopierQuantification');
  }

  stationary=new FormGroup({
    flipChartRadio: new FormControl('', []),
    flipChartQuantification: new FormControl('', []),
    paperAndPensRadio: new FormControl('', []),
    paperAndPensQuantification: new FormControl('', []),
    whiteBoardRadio: new FormControl('', []),
    whiteBoardQuantification: new FormControl('', []),
  });

  get flipChartRadio() {
    return this.stationary.get('flipChartRadio');
  }

  get flipChartQuantification() {
    return this.stationary.get('flipChartQuantification');
  }

  get paperAndPensRadio() {
    return this.stationary.get('paperAndPensRadio');
  }

  get paperAndPensQuantification() {
    return this.stationary.get('paperAndPensQuantification');
  }

  get whiteBoardRadio() {
    return this.stationary.get('whiteBoardRadio');
  }

  get whiteBoardQuantification() {
    return this.stationary.get('whiteBoardQuantification');
  }

  services=new FormGroup({
    interpretationRadio: new FormControl('', []),
    interpretationUnitOfMeasure: new FormControl('', []),
    interpretationUnitPrice: new FormControl('', [Validators.required]),
    typingServiceRadio: new FormControl('', []),
    typingServiceUnitOfMeasure: new FormControl('', []),
    typingServiceUnitPrice: new FormControl('', [Validators.required]), 
  });

  get interpretationRadio() {
    return this.services.get('interpretationRadio');
  }

  get interpretationUnitOfMeasure() {
    return this.services.get('interpretationUnitOfMeasure');
  }

  get interpretationUnitPrice() {
    return this.services.get('interpretationUnitPrice');
  }

  get typingServiceRadio() {
    return this.services.get('typingServiceRadio');
  }

  get typingServiceUnitOfMeasure() {
    return this.services.get('typingServiceUnitOfMeasure');
  }

  get typingServiceUnitPrice() {
    return this.services.get('typingServiceUnitPrice');
  }

  assettypes : any=[];
  constructor(private http: Http) { }

  ngOnInit() {
    this.http.get("http://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/itadmin/assettype")
    .subscribe(
      res => {
      console.log(res);
      this.assettypes=res.json();
    });
  }

  
     assetAmenityDetails = new AssetAmenityDetails();
     assetBasicDetails = new AssetBasicDetails();
  onSubmit() {
    
    this.assetBasicDetails.hotelMaster = "The Sanctuary-Sydney";
    this.assetBasicDetails.assetName = this.form.get('assetName').value;
    this.assetBasicDetails.assetType = this.form.get('assetType').value;
    this.assetBasicDetails.locationInHotel = this.form.get('locationInHotel').value;
    this.assetBasicDetails.dimensionsLength = this.form.get('length').value;
    this.assetBasicDetails.dimensionsWidth = this.form.get('width').value;
    this.assetBasicDetails.dimensionsHeight = this.form.get('height').value;
    this.assetBasicDetails.maxGuests = this.form.get('noOfGuest').value;
    this.assetBasicDetails.unitOfMeasure = this.form.get('unitOfMeasure').value;
    this.assetBasicDetails.basePrice = this.form.get('unitPrice').value;

    
    this.http.post("http://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/itadmin/addassetmaster/",this.assetBasicDetails)
    .subscribe(
      res => {
      console.log(res);
    })

    this.assetAmenityDetails.assetName = this.form.get('assetName').value;
    this.assetAmenityDetails.assetType = this.form.get('assetType').value;
    this.assetAmenityDetails.locationInHotel = this.form.get('locationInHotel').value;
    this.assetAmenityDetails.length = this.form.get('length').value;
    this.assetAmenityDetails.width = this.form.get('width').value;
    this.assetAmenityDetails.height = this.form.get('height').value;
    this.assetAmenityDetails.noOfGuest = this.form.get('noOfGuest').value;
    this.assetAmenityDetails.unitOfMeasure = this.form.get('unitOfMeasure').value;
    this.assetAmenityDetails.unitPrice = this.form.get('unitPrice').value;

    this.assetAmenityDetails.acRadio = this.room.get('acRadio').value;
    this.assetAmenityDetails.airConditionerUnitOfMeasure = this.room.get('airConditionerUnitOfMeasure').value;
    this.assetAmenityDetails.airConditionerUnitPrice = this.room.get('airConditionerUnitPrice').value;
    this.assetAmenityDetails.lecternRadio = this.room.get('lecternRadio').value;
    this.assetAmenityDetails.lecternUnitOfMeasure = this.room.get('lecternUnitOfMeasure').value;
    this.assetAmenityDetails.lecternUnitPrice = this.room.get('lecternUnitPrice').value;
    this.assetAmenityDetails.lecternQuantifcication = this.room.get('lecternQuantifcication').value;
    this.assetAmenityDetails.roomControlRadio = this.room.get('roomControlRadio').value;
    this.assetAmenityDetails.roomControlUnitOfMeasure = this.room.get('roomControlUnitOfMeasure').value;
    this.assetAmenityDetails.roomControlUnitPrice = this.room.get('roomControlUnitPrice').value;
    this.assetAmenityDetails.stagingRadio = this.room.get('stagingRadio').value;
    this.assetAmenityDetails.stagingUnitOfMeasure = this.room.get('stagingUnitOfMeasure').value;
    this.assetAmenityDetails.stagingUnitPrice = this.room.get('stagingUnitPrice').value;
    this.assetAmenityDetails.underFloorHeatingRadio = this.room.get('underFloorHeatingRadio').value;
    this.assetAmenityDetails.underFloorHeatingUnitOfMeasure = this.room.get('underFloorHeatingUnitOfMeasure').value;
    this.assetAmenityDetails.underFloorHeatingUnitPrice = this.room.get('underFloorHeatingUnitPrice').value;

    
    this.assetAmenityDetails.amplifierRadio = this.sound.get('amplifierRadio').value;
    this.assetAmenityDetails.amplifierUnitOfMeasure = this.sound.get('amplifierUnitOfMeasure').value;
    this.assetAmenityDetails.amplifierUnitPrice = this.sound.get('amplifierUnitPrice').value;
    this.assetAmenityDetails.autoCueRadio = this.sound.get('autoCueRadio').value;
    this.assetAmenityDetails.autoCueUnitOfMeasure = this.sound.get('autoCueUnitOfMeasure').value;
    this.assetAmenityDetails.autoCueUnitPrice = this.sound.get('autoCueUnitPrice').value;
    this.assetAmenityDetails.karaokeRadio = this.sound.get('karaokeRadio').value;
    this.assetAmenityDetails.karaokeUnitOfMeasure = this.sound.get('karaokeUnitOfMeasure').value;
    this.assetAmenityDetails.karaokeUnitPrice = this.sound.get('karaokeUnitPrice').value;
    this.assetAmenityDetails.microPhoneRadio = this.sound.get('microPhoneRadio').value;
    this.assetAmenityDetails.microPhoneUnitOfMeasure = this.sound.get('microPhoneUnitOfMeasure').value;
    this.assetAmenityDetails.microPhoneUnitPrice = this.sound.get('microPhoneUnitPrice').value;
    this.assetAmenityDetails.microPhoneQuantification = this.sound.get('microPhoneQuantification').value;
    this.assetAmenityDetails.paSystemRadio = this.sound.get('paSystemRadio').value;
    this.assetAmenityDetails.paSystemUnitOfMeasure = this.sound.get('paSystemUnitOfMeasure').value;
    this.assetAmenityDetails.paSystemUnitPrice = this.sound.get('paSystemUnitPrice').value;


    this.assetAmenityDetails.socketsRadio = this.electrical.get('socketsRadio').value;
    this.assetAmenityDetails.socketsUnitOfMeasure = this.electrical.get('socketsUnitOfMeasure').value;
    this.assetAmenityDetails.socketsUnitPrice = this.electrical.get('socketsUnitPrice').value;


    this.assetAmenityDetails.blackOutControlRadio = this.lighting.get('blackOutControlRadio').value;
    this.assetAmenityDetails.blackOutControlUnitOfMeasure = this.lighting.get('blackOutControlUnitOfMeasure').value;
    this.assetAmenityDetails.blackOutControlUnitPrice = this.lighting.get('blackOutControlUnitPrice').value;
    this.assetAmenityDetails.dimmersRadio = this.lighting.get('dimmersRadio').value;
    this.assetAmenityDetails.dimmersUnitOfMeasure = this.lighting.get('dimmersUnitOfMeasure').value;
    this.assetAmenityDetails.dimmersUnitPrice = this.lighting.get('dimmersUnitPrice').value;
    this.assetAmenityDetails.naturalDayLightRadio = this.lighting.get('naturalDayLightRadio').value;
    this.assetAmenityDetails.naturalDayLightUnitOfMeasure = this.lighting.get('naturalDayLightUnitOfMeasure').value;
    this.assetAmenityDetails.naturalDayLightUnitPrice = this.lighting.get('naturalDayLightUnitPrice').value;
    this.assetAmenityDetails.soundSystemRadio = this.lighting.get('soundSystemRadio').value;
    this.assetAmenityDetails.soundSystemUnitOfMeasure = this.lighting.get('soundSystemUnitOfMeasure').value;
    this.assetAmenityDetails.soundSystemUnitPrice = this.lighting.get('soundSystemUnitPrice').value;
    this.assetAmenityDetails.warmLightRadio = this.lighting.get('warmLightRadio').value;
    this.assetAmenityDetails.warmLightUnitOfMeasure = this.lighting.get('warmLightUnitOfMeasure').value;
    this.assetAmenityDetails.warmLightUnitPrice = this.lighting.get('warmLightUnitPrice').value;
    this.assetAmenityDetails.coolLightRadio = this.lighting.get('coolLightRadio').value;
    this.assetAmenityDetails.coolLigtUnitOfMeasure = this.lighting.get('coolLigtUnitOfMeasure').value;
    this.assetAmenityDetails.coolLightUnitPrice = this.lighting.get('coolLightUnitPrice').value;


    this.assetAmenityDetails.computerRadio = this.computing.get('computerRadio').value;
    this.assetAmenityDetails.computerUnitOfMeasure = this.computing.get('computerUnitOfMeasure').value;
    this.assetAmenityDetails.computerUnitPrice = this.computing.get('computerUnitPrice').value;
    this.assetAmenityDetails.dvdRadio = this.computing.get('dvdRadio').value;
    this.assetAmenityDetails.dvdUnitOfMeasure = this.computing.get('dvdUnitOfMeasure').value;
    this.assetAmenityDetails.dvdUnitPrice = this.computing.get('dvdUnitPrice').value;
    this.assetAmenityDetails.gameConsoleRadio = this.computing.get('gameConsoleRadio').value;
    this.assetAmenityDetails.gameConsoleUnitOfMeasure = this.computing.get('gameConsoleUnitOfMeasure').value;
    this.assetAmenityDetails.gameConsoleUnitPrice = this.computing.get('gameConsoleUnitPrice').value;
    this.assetAmenityDetails.lcdScreenRadio = this.computing.get('lcdScreenRadio').value;
    this.assetAmenityDetails.lcdScreenUnitOfMeasure = this.computing.get('lcdScreenUnitOfMeasure').value;
    this.assetAmenityDetails.lcdScreenUnitPrice = this.computing.get('lcdScreenUnitPrice').value;
    this.assetAmenityDetails.lcdQuantification = this.computing.get('lcdQuantification').value;
    this.assetAmenityDetails.printerRadio = this.computing.get('printerRadio').value;
    this.assetAmenityDetails.printerUnitOfMeasure = this.computing.get('printerUnitOfMeasure').value;
    this.assetAmenityDetails.printerUnitPrice = this.computing.get('printerUnitPrice').value;
    this.assetAmenityDetails.printerQuantification = this.computing.get('printerQuantification').value;
    this.assetAmenityDetails.projectorRadio = this.computing.get('projectorRadio').value;
    this.assetAmenityDetails.projectorUnitOfMeasure = this.computing.get('projectorUnitOfMeasure').value;
    this.assetAmenityDetails.projectorUnitPrice = this.computing.get('projectorUnitPrice').value;
    this.assetAmenityDetails.projectorQuantification = this.computing.get('projectorQuantification').value;
    this.assetAmenityDetails.videoConferencingRadio = this.computing.get('videoConferencingRadio').value;
    this.assetAmenityDetails.videoConferencingUnitOfMeasure = this.computing.get('videoConferencingUnitOfMeasure').value;
    this.assetAmenityDetails.videoConferencingUnitPrice = this.computing.get('videoConferencingUnitPrice').value;
    this.assetAmenityDetails.whiteScreenRadio = this.computing.get('whiteScreenRadio').value;
    this.assetAmenityDetails.whiteScreenUnitOfMeasure = this.computing.get('whiteScreenUnitOfMeasure').value;
    this.assetAmenityDetails.whiteScreenUnitPrice = this.computing.get('whiteScreenUnitPrice').value;
    this.assetAmenityDetails.whiteScreenQuantification = this.computing.get('whiteScreenQuantification').value;
    this.assetAmenityDetails.wifiRadio = this.computing.get('wifiRadio').value;
    this.assetAmenityDetails.wifiUnitOfMeasure = this.computing.get('wifiUnitOfMeasure').value;
    this.assetAmenityDetails.wifiUnitPrice = this.computing.get('wifiUnitPrice').value;
    this.assetAmenityDetails.lanCableRadio = this.computing.get('lanCableRadio').value;
    this.assetAmenityDetails.lanCableUnitOfMeasure = this.computing.get('lanCableUnitOfMeasure').value;
    this.assetAmenityDetails.lanCableUnitPrice = this.computing.get('lanCableUnitPrice').value;
    this.assetAmenityDetails.photoCopierRadio = this.computing.get('photoCopierRadio').value;
    this.assetAmenityDetails.photoCopierUnitOfMeasure = this.computing.get('photoCopierUnitOfMeasure').value;
    this.assetAmenityDetails.photoCopierUnitPrice = this.computing.get('photoCopierUnitPrice').value;
    this.assetAmenityDetails.photoCopierQuantification = this.computing.get('photoCopierQuantification').value;


    this.assetAmenityDetails.flipChartRadio = this.stationary.get('flipChartRadio').value;
    this.assetAmenityDetails.flipChartQuantification = this.stationary.get('flipChartQuantification').value;
    this.assetAmenityDetails.paperAndPensRadio = this.stationary.get('paperAndPensRadio').value;
    this.assetAmenityDetails.paperAndPensQuantification = this.stationary.get('paperAndPensQuantification').value;
    this.assetAmenityDetails.whiteBoardRadio = this.stationary.get('whiteBoardRadio').value;
    this.assetAmenityDetails.whiteBoardQuantification = this.stationary.get('whiteBoardQuantification').value;

    
    this.assetAmenityDetails.interpretationRadio = this.services.get('interpretationRadio').value;
    this.assetAmenityDetails.interpretationUnitOfMeasure = this.services.get('interpretationUnitOfMeasure').value;
    this.assetAmenityDetails.interpretationUnitPrice = this.services.get('interpretationUnitPrice').value;
    this.assetAmenityDetails.typingServiceRadio = this.services.get('typingServiceRadio').value;
    this.assetAmenityDetails.typingServiceUnitOfMeasure = this.services.get('flipChartRadio').value;
    this.assetAmenityDetails.typingServiceUnitPrice = this.services.get('typingServiceUnitPrice').value;

  }
}

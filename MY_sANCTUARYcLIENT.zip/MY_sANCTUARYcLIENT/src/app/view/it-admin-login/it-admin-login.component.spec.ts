import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItAdminLoginComponent } from './it-admin-login.component';

describe('ItAdminLoginComponent', () => {
  let component: ItAdminLoginComponent;
  let fixture: ComponentFixture<ItAdminLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItAdminLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItAdminLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

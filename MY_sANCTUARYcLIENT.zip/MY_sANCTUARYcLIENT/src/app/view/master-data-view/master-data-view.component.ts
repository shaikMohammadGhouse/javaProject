import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-data-view',
  templateUrl: './master-data-view.component.html',
  styleUrls: ['./master-data-view.component.css']
})
export class MasterDataViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

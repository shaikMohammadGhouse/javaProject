import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterDataViewComponent } from './master-data-view.component';

describe('MasterDataViewComponent', () => {
  let component: MasterDataViewComponent;
  let fixture: ComponentFixture<MasterDataViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterDataViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterDataViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

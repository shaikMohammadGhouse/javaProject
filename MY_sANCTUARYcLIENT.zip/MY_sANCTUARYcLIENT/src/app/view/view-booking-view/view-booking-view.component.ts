import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-booking-view',
  templateUrl: './view-booking-view.component.html',
  styleUrls: ['./view-booking-view.component.css']
})
export class ViewBookingViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

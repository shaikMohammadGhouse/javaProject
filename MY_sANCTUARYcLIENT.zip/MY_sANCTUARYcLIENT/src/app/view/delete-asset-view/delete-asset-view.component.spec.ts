import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAssetViewComponent } from './delete-asset-view.component';

describe('DeleteAssetViewComponent', () => {
  let component: DeleteAssetViewComponent;
  let fixture: ComponentFixture<DeleteAssetViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteAssetViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteAssetViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

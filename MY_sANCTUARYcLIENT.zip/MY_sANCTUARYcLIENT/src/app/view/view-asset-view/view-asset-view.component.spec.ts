import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAssetViewComponent } from './view-asset-view.component';

describe('ViewAssetViewComponent', () => {
  let component: ViewAssetViewComponent;
  let fixture: ComponentFixture<ViewAssetViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAssetViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAssetViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelAmenitiesFormComponent } from './hotel-amenities-form.component';

describe('HotelAmenitiesFormComponent', () => {
  let component: HotelAmenitiesFormComponent;
  let fixture: ComponentFixture<HotelAmenitiesFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HotelAmenitiesFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelAmenitiesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

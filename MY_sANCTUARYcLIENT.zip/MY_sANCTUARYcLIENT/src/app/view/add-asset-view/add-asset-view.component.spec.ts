import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAssetViewComponent } from './add-asset-view.component';

describe('AddAssetViewComponent', () => {
  let component: AddAssetViewComponent;
  let fixture: ComponentFixture<AddAssetViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAssetViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAssetViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

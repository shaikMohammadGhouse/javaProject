import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutview',
  templateUrl: './aboutview.component.html',
  styleUrls: ['./aboutview.component.css']
})
export class AboutviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

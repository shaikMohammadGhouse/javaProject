import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-amenities-view',
  templateUrl: './choose-amenities-view.component.html',
  styleUrls: ['./choose-amenities-view.component.css']
})
export class ChooseAmenitiesViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

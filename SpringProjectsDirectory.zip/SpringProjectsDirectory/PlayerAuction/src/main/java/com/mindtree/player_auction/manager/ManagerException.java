package com.mindtree.player_auction.manager;

public class ManagerException {

}

package com.mindtree.player_auction.utilities;

public class UtilityException {

}

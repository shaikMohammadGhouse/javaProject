package com.mindtree.player_auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mindtree.player_auction.entity.Player;
import com.mindtree.player_auction.entity.Team;
import com.mindtree.player_auction.utilities.DBUtil;

public class PlayerDaoImpl implements PlayerDao
{
	
	DBUtil ut=new DBUtil();
	public ArrayList<Player> diplayDetails(String tname)
	{
		ArrayList<Player> list=new ArrayList<Player>();
		
		Connection conn=DBUtil.getConnection();
		
		System.out.println("entered team name"+tname);
		
		String query="select p.Player_Name,p.Category from Player p,Team_Player t where p.Player_No=t.Player_No && team_id in(select Team_Id from Team where Team_Name='"+tname+"')";
		try
		{
			
			Statement stmt=conn.createStatement();
			ResultSet rs1=stmt.executeQuery(query);
			while(rs1.next())
			{
				Player p=new Player();
				String name=rs1.getString(1);
				String category=rs1.getString(2);
				p.setPlayer_name(name);
				p.setCategory(category);
				list.add(p);
			}
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return list;
	}

	
	public boolean playerName(String name)
	{
		Connection conn=DBUtil.getConnection();
		String query="select Player_Name from Player where Player_Name='"+name+"'";
		
			
			try
			{
				Statement stat;
				stat = conn.createStatement();
				ResultSet rs;
				rs = stat.executeQuery(query);
				if(rs.next())
				{
					return false;
				}
				else
				{	
					return true;
				}
				
			} 
			catch (SQLException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ut.closeConnection();
			return false;
	}		
	
	public boolean teamName(String name)
	{
		Connection conn=DBUtil.getConnection();
		String query="select Team_Name from Team where Team_Name='"+name+"'";
		
			
			try
			{
				Statement stat= conn.createStatement();
				ResultSet rs= stat.executeQuery(query);
				if(rs.next())
				{
					return true;
				}
				else
					return false;
				
			} 
			catch (SQLException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ut.closeConnection();
			return false;
	}
	
	public void insertData(Player p, Team t) 
	{
		int no=0,id=0;
		Connection conn=DBUtil.getConnection();
		String query="insert into Player(Player_Name,Category,HighestScore,BestFigure) values(?,?,?,?)";
		String query1="select max(Player_No) from Player";
		String query2="select Team_Id from Team where Team_Name=?";
		String query3="insert into team_player(Player_No,Team_Id) values(?,?)";
		
		
		
			
			try 
			{
				PreparedStatement stmt;
				stmt = conn.prepareStatement(query);
				stmt.setString(1,p.getPlayer_name());
				stmt.setString(2,p.getCategory());
				stmt.setInt(3,p.getHighest_score());
				stmt.setString(4,p.getBest_figures());
				stmt.execute();
			
				
				PreparedStatement stmt1;
				stmt1=conn.prepareStatement(query1);
				ResultSet rs1=stmt1.executeQuery();
				if(rs1.next())
				{
					no=rs1.getInt(1);
				}
				
				
				PreparedStatement stmt2;
				stmt2=conn.prepareStatement(query2);
				stmt2.setString(1, t.getTeam_name());
				ResultSet rs2=stmt2.executeQuery();
				if(rs2.next())
				{
					id=rs2.getInt(1);
				}
				
				
				PreparedStatement stmt3;
				stmt3=conn.prepareStatement(query3);
				stmt3.setInt(1, no);
				stmt3.setInt(2, id);
				stmt3.execute();
				
				//stmt1.setSt;
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try
			{
				conn.close();
			}
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		// TODO Auto-generated method stub
			System.out.println("Player details....added");
		
	}

	

}

package com.mindtree.player_auction.service;

import java.util.ArrayList;

import com.mindtree.player_auction.entity.Player;

public interface Player_service 
{
		public ArrayList<Player> display(String name);

}

package com.mindtree.player_auction.entity;

public class PlayerEntityException 
{

}

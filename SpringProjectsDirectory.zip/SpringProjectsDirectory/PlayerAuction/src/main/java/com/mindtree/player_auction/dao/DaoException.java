package com.mindtree.player_auction.dao;

public class DaoException {

}

package com.mindtree.player_auction.exception;

public class ExceptionException {

}

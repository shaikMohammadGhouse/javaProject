package com.mindtree.player_auction.exception;

public class NotABowlerException extends Exception
{
	public NotABowlerException (String string)
	  {
		  super(string);
	  }

}

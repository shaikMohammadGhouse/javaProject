package com.mindtree.TravelApp.entity;

public class Vehicle 
{
	private int id;
	private String type;
	private String name;
	private String colour;
	public Vehicle(int Vid, String Vtype, String Vname, String Vcolour) 
	{
		super();
		this.id = Vid;
		this.type = Vtype;
		this.name = Vname;
		this.colour = Vcolour;
	}
	public int getVid() 
	{
		return id;
	}

	public void setVid(int id)
	{
		this.id = id;
	}

	public String getVtype() 
	{
		return type;
	}

	public void setVtype(String type) 
	{
		this.type = type;
	}

	public String getVname() 
	{
		return name;
	}

	public void setVname(String name) 
	{
		this.name = name;
	}

	public String getVcolour() 
	{
		return colour;
	}

	public void setVcolour(String colour)
	{
		this.colour = colour;
	}

	public Vehicle()
	{
		
	}

	@Override
	public String toString()
	{
		return "Vehicle [Vid=" + id + ", Vtype=" + type + ", Vname=" + name + ", Vcolour=" + colour + "]";
	}
	
	
	
}

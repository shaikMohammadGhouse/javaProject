package com.mindtree.TravelApp.entity;

public class City 
{
	//private int id;
	private String name;
	
	public City()
	{
		
	}
	City(String name)
	{
		this.name=name;
		//this.id=id;
	}
	//public int getId() 
///	{
	//	return id;
//	}
//	public void setId(int id) 
	//{
		//this.id = id;
	//}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String toString() {
		return "City [id="  + ", name=" + name + "]";
	}
	
	
	
	
}

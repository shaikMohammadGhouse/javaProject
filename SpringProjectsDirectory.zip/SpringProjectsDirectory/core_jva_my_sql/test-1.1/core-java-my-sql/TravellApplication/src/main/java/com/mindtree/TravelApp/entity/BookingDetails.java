package com.mindtree.TravelApp.entity;

public class BookingDetails 
{
	private int bookid;
	private City source;
	private City destination;
	private Vehicle vehicle;
	private long phno;
	public BookingDetails(int bookid, City source, City destination, Vehicle vehicle, long phno)
	{
		super();
		this.bookid = bookid;
		this.source = source;
		this.destination = destination;
		this.vehicle = vehicle;
		this.phno = phno;
	}
	public BookingDetails()
	{
		
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public City getSource() {
		return source;
	}
	public void setSource(City source) {
		this.source = source;
	}
	public City getDestination() {
		return destination;
	}
	public void setDestination(City destination) {
		this.destination = destination;
	}
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "BookingDetails [bookid=" + bookid + ", source=" + source + ", destination=" + destination + ", vehicle="
				+ vehicle + ", phno=" + phno + "]";
	}
	
	
	
}

package multiThread_Sync;

public class ProducerThread extends Thread
{
	private Data d1;
	public ProducerThread(Data d1)
	{
		this.d1=d1;
	}
	public void run()
	{
		d1.ProducerX(20);
	}
}

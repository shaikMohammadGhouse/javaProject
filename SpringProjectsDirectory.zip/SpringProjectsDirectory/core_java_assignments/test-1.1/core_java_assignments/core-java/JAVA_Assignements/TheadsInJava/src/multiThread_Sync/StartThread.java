package multiThread_Sync;

public class StartThread 
{
	public static void main(String[] args)
	{
		System.out.println("----------------------------");
		
		Data dobj=new Data();
		
		
		ConsumerThread t1=new ConsumerThread(dobj);
		ConsumerThread t2=new ConsumerThread(dobj);
		ConsumerThread t3=new ConsumerThread(dobj);
		
		
		
		ProducerThread t4=new ProducerThread(dobj);
		
		t1.setName("Thread 1");
		t2.setName("Thread 2");
		t3.setName("Thread 3");
		t4.setName("Thread 4");
		
		System.out.println(" x val.....is..."+dobj.getX());
		t1.start();t2.start();t3.start();

		try {
			
			Thread.sleep(125);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		t4.start();
	
		System.out.println(" main................");

	}
}

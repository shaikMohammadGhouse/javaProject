package java_core_assig;
import java.util.Scanner;
public class Matrix_Arrangment
{
	static void sorting(int x[])
	{
		int n = x.length;
	        for (int i = 0; i < n-1; i++)
	            for (int j = 0; j < n-i-1; j++)
	                if (x[j] > x[j+1])
	                {
	                    int temp = x[j];							//bubblesort
	                    x[j] = x[j+1];
	                    x[j+1] = temp;
	                }

	}
	public static int[] arrangeElements(int[][] inputArray)
	{
		int h[][]=new int[5][6];
		System.out.println(h.length);
		int p=inputArray.length;
		System.out.println(p);
		System.out.println(h[0].length);
		int n=9,z=0,k=0,l=0;
		int a[]=new int[n];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				a[z]=inputArray[i][j];
				z++;
			}
		}
		Matrix_Arrangment.sorting(a);
		
		int size=(n/2)+1;
		int x[]=new int[size];
		int y[]=new int[size-1];
		
		for(int i=0;i<n;i=i+2)
		{
			x[k]=a[i];						//alternative indexes
			k++;
		}
		for(int i=1;i<n;i=i+2)
		{
			y[l]=a[i];							//alternative indexes....
			l++;
		}
		
		z=0;
		for(int i=x.length-1;i>=0;i--)
		{
			a[z]=x[i];
			z++;								//merge in array
		}
		
		for(int i=0;i<y.length;i++)
		{
			a[z]=y[i];
			z++;
		}
		
		return a;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int arr[][]=new int[3][3];
		
		System.out.println("It is a 3*3 matrix ");
		System.out.println("Please enter 9 elements to matrix:: ");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		int x[]=Matrix_Arrangment.arrangeElements(arr);
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i]+" ");
		}
		sc.close();
	}
}

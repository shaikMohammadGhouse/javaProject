package outstanding_person;

public class Professor extends Person 
{
	int booksPublished=0;
	public Professor()
	{
		// TODO Auto-generated constructor stub
	}

	public Professor(String name,int booksPublished)
	{

		this.booksPublished=booksPublished;
		super.name=name;
	}

	public void print()
	{
		System.out.println(this.name+"   "+this.booksPublished);
	}
	public boolean isOutstanding()
	{
		if(booksPublished>4)
		return true;
		else
			return false;
	}
}

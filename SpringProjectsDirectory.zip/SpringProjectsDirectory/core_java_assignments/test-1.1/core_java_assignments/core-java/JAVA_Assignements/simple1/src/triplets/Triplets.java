package triplets;
import java.util.Scanner;

public class Triplets 
{
	public static void main(String[] args) 
	{
		/*Scanner sc=new Scanner(System.in);
		int  n=0;
		System.out.println("enter the size of th array....");
		n=sc.nextInt();
		
		*/
		
		int a[]={1,2,3,4,5,7,9};
		printTriplets(a);
	}
	public static void printTriplets(int[ ] data)
	{
		int a=0,b=0,sum=0; 
		for(int i=0;i<data.length;i++)
		{
			for(int j=i+1;j<data.length;j++)
			{
				for(int k=j;k<data.length;k++)
				{
					a=data[i];
					b=data[j];
					sum=data[k];
					
					if(a+b==sum)
					{
						System.out.println("<"+a+","+b+","+sum+">");
					}
				}
			}
		}
		
	}

	
}


package com.mindtree.fetchDetails.dao.daoimp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.fetchDetails.dao.FetchDao;
import com.mindtree.fetchDetails.entity.City;
import com.mindtree.fetchDetails.entity.Details;
import com.mindtree.fetchDetails.entity.EmpSalary;
import com.mindtree.fetchDetails.utilities.DBUtil;

public class FetchDaoImp implements FetchDao
{
	Statement stat=null;
	String query;
	Connection conn=DBUtil.getConnection();
	
	public List<Details> getDetails(EmpSalary sal) 
	{
		List<Details> details=new ArrayList<Details>();
		
		try {
			stat=conn.createStatement();
			query="select empId,empName,empSalary,city from employee where empSalary="+"'"+sal.getSalary()+"'";
			ResultSet res1=stat.executeQuery(query);
			
			while(res1.next())
			{
				Details detail=new Details();
			
				int id=res1.getInt("empId");
				String name=res1.getString("empName");
				int salary=res1.getInt("empSalary");
				String city=res1.getString("city");
				
				detail.setCity(city);
				detail.setId(id);
				detail.setName(name);
				detail.setSalary(salary);
				
				details.add(detail);
				
			}
			
			res1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DBUtil.closeConnection();
		// TODO Auto-generated method stub
		return details;
	}
	
}

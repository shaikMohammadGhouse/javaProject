package com.mindtree.fetchDetails.utilities;

public class DbUtilException {

}

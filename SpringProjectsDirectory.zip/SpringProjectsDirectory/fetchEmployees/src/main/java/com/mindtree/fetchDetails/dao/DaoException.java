package com.mindtree.fetchDetails.dao;

import com.mindtree.fetchDetails.ApplicationException;

public class DaoException extends ApplicationException{

}

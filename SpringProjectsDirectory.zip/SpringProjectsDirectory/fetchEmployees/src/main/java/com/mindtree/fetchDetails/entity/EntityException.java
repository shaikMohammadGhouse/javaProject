package com.mindtree.fetchDetails.entity;

import com.mindtree.fetchDetails.ApplicationException;

public class EntityException extends ApplicationException{

}

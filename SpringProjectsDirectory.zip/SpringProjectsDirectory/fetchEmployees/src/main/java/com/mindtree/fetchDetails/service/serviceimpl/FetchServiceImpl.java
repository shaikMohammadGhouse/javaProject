package com.mindtree.fetchDetails.service.serviceimpl;

import java.util.List;

import com.mindtree.fetchDetails.dao.FetchDao;
import com.mindtree.fetchDetails.dao.daoimp.FetchDaoImp;
import com.mindtree.fetchDetails.entity.Details;
import com.mindtree.fetchDetails.entity.EmpSalary;
import com.mindtree.fetchDetails.service.FetchService;

public class FetchServiceImpl implements FetchService
{
	private FetchDao fetch=new FetchDaoImp();
	
	public List<Details> getDetails(EmpSalary sal) {
		// TODO Auto-generated method stub
		return fetch.getDetails(sal);
	}

}

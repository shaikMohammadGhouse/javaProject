package com.mindtree.fetchDetails;

public class ApplicationException extends Exception{
	

}

package com.mindtree.Kmart.dao;

public interface UserDao {

}

package com.mindtree.Kmart.service.serviceimpl;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.Kmart.dao.daoimpl.*;
import com.mindtree.Kmart.entity.Product;

@Service
@Transactional
public class ProductServiceImpl {
	
	@Autowired
	ProductDaoImpl productDaoImpl;
	
	public List<Product> getAllProducts()
	{
		return productDaoImpl.getAllProducts();
	}

	public Product getProduct(int productId)
	{
		return productDaoImpl.getProduct(productId);
		
	}

	public void addProduct(Product product)
	{
		productDaoImpl.addProduct(product);
	}

	public void updateProduct(Product product)
	{
		productDaoImpl.updateProduct(product);
	}

	@Transactional
	public void deleteProduct(int productId)
	{
		productDaoImpl.deleteProduct(productId);
	}

	public ProductDaoImpl getProductDaoImpl() {
		return productDaoImpl;
	}

	public void setProductDaoImpl(ProductDaoImpl productDaoImpl) {
		this.productDaoImpl = productDaoImpl;
	}

	
}

package com.mindtree.Kmart.dao;

import java.util.List;

import com.mindtree.Kmart.entity.Product;


public interface ProductDao {


	List<Product> getAllProducts();

	Product getProduct(int id);

	public void addProduct(Product product);

	void updateProduct(Product product);

	void deleteProduct(int id);

}

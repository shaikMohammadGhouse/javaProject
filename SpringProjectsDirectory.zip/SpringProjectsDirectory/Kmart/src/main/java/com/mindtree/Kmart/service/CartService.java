package com.mindtree.Kmart.service;

public interface CartService {

}

package com.mindtree.Kmart.dao.daoimpl;

public class UserDaoImpl {

}

package com.mindtree.Kmart.dao;

public interface CartDao {

}

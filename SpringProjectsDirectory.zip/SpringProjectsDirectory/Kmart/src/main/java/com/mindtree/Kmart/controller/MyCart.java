package com.mindtree.Kmart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Kmart.entity.Product;

@RestController
@RequestMapping(value="/dukaan")
public class MyCart 
{
	private static List<Product> products=new ArrayList<Product>();
		static{
			products.add(new Product(1,"Sony Bravia","LEDTV",1578.0));
			products.add(new Product(2,"HTC ","MOBILE",6567.0));
			products.add(new Product(3,"APPLE","Iphone",9879.0));
			products.add(new Product(4,"Dell","Laptop",9868.0));
			products.add(new Product(5,"Hp","Laptop",09709.0));
			products.add(new Product(6,"HP","Laptop",9898.09));
			products.add(new Product(7,"Lenovo","Mobile",9834.0));
		}
		
		@RequestMapping(value="/products",method=RequestMethod.GET)
		public List<Product> getProducts()
		{
		
			return products;
		}

}

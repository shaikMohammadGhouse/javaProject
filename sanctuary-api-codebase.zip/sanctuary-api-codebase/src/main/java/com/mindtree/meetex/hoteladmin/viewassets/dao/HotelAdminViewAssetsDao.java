package com.mindtree.meetex.hoteladmin.viewassets.dao;

public interface HotelAdminViewAssetsDao {

}

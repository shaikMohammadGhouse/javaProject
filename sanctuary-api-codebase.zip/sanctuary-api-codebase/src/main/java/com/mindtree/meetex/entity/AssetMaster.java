package com.mindtree.meetex.entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table (name="assetmaster")
public class AssetMaster
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="asset_id")
	private int assetId;
	
	@Column(name="hotel_id")
	private int hotelMaster;
	
	@Column(name="asset_name")
	private String assetName;
	
	@Column(name="asset_type_id")
	private int assetType;
	
	@Column(name="location_in_hotel")
	private String locationInHotel;
	
	@Column(name="dimensions_length")
	private int dimensionsLength ;
	
	@Column(name="dimensions_width")
	private int dimensionsWidth ;
	
	@Column(name="dimensions_height")
	private int dimensionsHeight ;
	
	@Column(name="max_guests")
	private int maxGuests ;
	
	@Column(name="unit_of_measure")
	private int unitOfMeasure ;
	
	@Column(name="base_price")
	private int basePrice;

	public AssetMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetMaster(int assetId, String assetName, int assetType, Set<AssetAmenity> assetAmenity,
			String locationInHotel, int dimensionsLength, int dimensionsWidth, int dimensionsHeight, int maxGuests,
			int unitOfMeasure, int basePrice, int hotelMaster) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetType = assetType;
		this.locationInHotel = locationInHotel;
		this.dimensionsLength = dimensionsLength;
		this.dimensionsWidth = dimensionsWidth;
		this.dimensionsHeight = dimensionsHeight;
		this.maxGuests = maxGuests;
		this.unitOfMeasure = unitOfMeasure;
		this.basePrice = basePrice;
		this.hotelMaster = hotelMaster;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public int getAssetType() {
		return assetType;
	}

	public void setAssetType(int assetTypeId) {
		this.assetType = assetTypeId;
	}

	public String getLocationInHotel() {
		return locationInHotel;
	}

	public void setLocationInHotel(String locationInHotel) {
		this.locationInHotel = locationInHotel;
	}

	public int getDimensionsLength() {
		return dimensionsLength;
	}

	public void setDimensionsLength(int dimensionsLength) {
		this.dimensionsLength = dimensionsLength;
	}

	public int getDimensionsWidth() {
		return dimensionsWidth;
	}

	public void setDimensionsWidth(int dimensionsWidth) {
		this.dimensionsWidth = dimensionsWidth;
	}

	public int getDimensionsHeight() {
		return dimensionsHeight;
	}

	public void setDimensionsHeight(int dimensionsHeight) {
		this.dimensionsHeight = dimensionsHeight;
	}

	public int getMaxGuests() {
		return maxGuests;
	}

	public void setMaxGuests(int maxGuests) {
		this.maxGuests = maxGuests;
	}

	public int getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(int unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public int getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(int basePrice) {
		this.basePrice = basePrice;
	}

	public int getHotelMaster() {
		return hotelMaster;
	}

	public void setHotelMaster(int hotelId) {
		this.hotelMaster = hotelId;
	}

	@Override
	public String toString() {
		return "AssetMaster [assetId=" + assetId + ", hotelMaster=" + hotelMaster + ", assetName=" + assetName
				+ ", assetType=" + assetType + ", locationInHotel=" + locationInHotel + ", dimensionsLength="
				+ dimensionsLength + ", dimensionsWidth=" + dimensionsWidth + ", dimensionsHeight=" + dimensionsHeight
				+ ", maxGuests=" + maxGuests + ", unitOfMeasure=" + unitOfMeasure + ", basePrice=" + basePrice + "]";
	}
	
	
	
}

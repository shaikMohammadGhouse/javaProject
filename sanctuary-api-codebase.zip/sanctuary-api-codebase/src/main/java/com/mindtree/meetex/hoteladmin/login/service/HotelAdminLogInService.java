package com.mindtree.meetex.hoteladmin.login.service;

public interface HotelAdminLogInService {

}

package com.mindtree.meetex.itadmin.addasset.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.meetex.entity.AssetMaster;
import com.mindtree.meetex.entity.AssetType;
import com.mindtree.meetex.itadmin.addasset.dao.AddAssetDao;
import com.mindtree.meetex.itadmin.addasset.service.AddAssetService;


@Service
public class AddAssetServiceImpl implements AddAssetService{

	public AddAssetDao getAddAssetDao() {
		return addAssetDao;
	}

	public void setAddAssetDao(AddAssetDao addAssetDao) {
		this.addAssetDao = addAssetDao;
	}

	@Autowired
	private AddAssetDao addAssetDao;
	

	@Transactional
	public List<AssetType> getALLAssetTypes()
	{
		return addAssetDao.getALLAssetTypes(); 
	}
	
	
	@Transactional
	public int getAssetTypeId(String assetType){
		return addAssetDao.getAssetTypeId(assetType);
	}
	
	
	@Transactional
	public int getHotelId(String hotelMaster){
		return addAssetDao.getHotelId(hotelMaster);
	}
	
	
	@Transactional
	public int getUnitOfMeasure(String unitOfMeasure){
		return addAssetDao.getUnitOfMeasure(unitOfMeasure);	
	}
	
	
	@Transactional
	public void addAssetAmenity(AssetMaster assetMasterData){
		this.addAssetDao.addAssetAmenity(assetMasterData);
		
	}
}

package com.mindtree.meetex.hoteladmin.exception.genericexception;

public class HotelAdminGenericException {

}

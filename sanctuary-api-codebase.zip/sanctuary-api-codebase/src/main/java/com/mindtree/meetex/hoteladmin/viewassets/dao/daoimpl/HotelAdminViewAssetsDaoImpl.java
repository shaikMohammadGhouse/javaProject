package com.mindtree.meetex.hoteladmin.viewassets.dao.daoimpl;

import com.mindtree.meetex.hoteladmin.viewassets.dao.HotelAdminViewAssetsDao;

public class HotelAdminViewAssetsDaoImpl implements HotelAdminViewAssetsDao {

}

package com.mindtree.meetex.hoteladmin.exception;

public class ApplicationException {

}

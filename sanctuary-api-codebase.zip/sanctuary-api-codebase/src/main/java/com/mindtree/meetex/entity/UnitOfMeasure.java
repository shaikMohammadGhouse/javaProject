package com.mindtree.meetex.entity;


import java.util.Set;

import javax.persistence.*;

@Entity
@Table (name="unitofmeasure")
public class UnitOfMeasure
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="unit_of_measure_id")
	private int unitOfMeasureId;
	
	@Column(name="unit_of_measure_name")
	private String unitOfMeasureName;
	
	public UnitOfMeasure() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnitOfMeasure(int unitOfMeasureId, String unitOfMeasureName, Set<AssetAmenity> assetAmenity) {
		super();
		this.unitOfMeasureId = unitOfMeasureId;
		this.unitOfMeasureName = unitOfMeasureName;
	}

	public int getUnitOfMeasureId() {
		return unitOfMeasureId;
	}

	public void setUnitOfMeasureId(int unitOfMeasureId) {
		this.unitOfMeasureId = unitOfMeasureId;
	}

	public String getUnitOfMeasureName() {
		return unitOfMeasureName;
	}

	public void setUnitOfMeasureName(String unitOfMeasureName) {
		this.unitOfMeasureName = unitOfMeasureName;
	}
	
}

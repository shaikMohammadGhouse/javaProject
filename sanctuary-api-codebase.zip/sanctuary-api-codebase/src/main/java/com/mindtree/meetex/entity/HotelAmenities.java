package com.mindtree.meetex.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotelamenities")
public class HotelAmenities {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="hotel_amenities_id")
	private int hotelAmenitiesId;
	
	@Column(name="hotel_id")	
	private int hotelId;
	
	@Column(name="hotel_amenity_name")
	private String hotelAmenityName;
	
	@Column(name="is_available")
	private String isAvailable;
	
	

	@Column(name="unit_of_measure")
	private String unitOfMeasure;
	
	@Column(name="price")
	private String price;
	
	@Column(name="selection_permitted")
	private String selectionPermitted;
	
	public HotelAmenities() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getHotelAmenitiesId() {
		return hotelAmenitiesId;
	}

	public void setHotelAmenitiesId(int hotelAmenitiesId) {
		this.hotelAmenitiesId = hotelAmenitiesId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelAmenityName() {
		return hotelAmenityName;
	}

	public void setHotelAmenityName(String hotelAmenityName) {
		this.hotelAmenityName = hotelAmenityName;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getSelectionPermitted() {
		return selectionPermitted;
	}

	public void setSelectionPermitted(String selectionPermitted) {
		this.selectionPermitted = selectionPermitted;
	}
	
	
	
	/*@Column(name="hasAccomodation")
	private String hasAccomodation;
	
	@Column(name="multiLinguaStaff")
	private String multiLinguaStaff;
	
	@Column(name="suppLanguages")
	private String suppLanguages;
	
	@Column(name="siteSecurity")
	private String siteSecurity;
	*/
	/*@Column(name="tennis")
	private String tennis;
	
	@Column(name="waterSports")
	private String waterSports;
	
	@Column(name="steamRoom")
	private String steamRoom;
	
	@Column(name="spa")
	private String spa;
	
	@Column(name="snooker")
	private String snooker;
	
	@Column(name="solarium")
	private String solarium;
	
	@Column(name="winterSports")
	private String winterSports;
	
	@Column(name="shooting")
	private String shooting;
	
	@Column(name="sauna")
	private String sauna;
	
	@Column(name="fishing")
	private String fishing;
	
	@Column(name="golf")
	private String golf;
	
	@Column(name="croquet")
	private String croquet;
	
	@Column(name="bowls")
	private String bowls;
	
	@Column(name="badminton")
	private String badminton;
	
	@Column(name="gym")
	private String gym;
	
	@Column(name="healthClub")
	private String healthClub;
	
	@Column(name="outdoorSwimmingPool")
	private String outdoorSwimmingPool;
	
	@Column(name="jacuzzi")
	private String jacuzzi;
	
	@Column(name="indoorSwimmingPool")
	private String indoorSwimmingPool;
	
	@Column(name="horseRiding")
	private String horseRiding;
	
	@Column(name="archery")
	private String archery;
	
	@Column(name="coachParking")
	private String coachParking;
	
	@Column(name="freeOffSiteParking")
	private String freeOffSiteParking;
	
	@Column(name="freeOnSiteParking")
	private String freeOnSiteParking;
	
	@Column(name="offSiteParkingWithFee")
	private String offSiteParkingWithFee;
	
	@Column(name="unitOfMeasureOffSiteParking")
	private String unitOfMeasureOffSiteParking;
	
	@Column(name="unitOfMeasureOffSiteParkingPrice")
	private String unitOfMeasureOffSiteParkingPrice;
	
	@Column(name="onSiteParkingWithFee")
	private String onSiteParkingWithFee;
	
	@Column(name="unitOfMeasureOnSiteParking")
	private String unitOfMeasureOnSiteParking;
	
	@Column(name="unitOfMeasureOnSiteParkingPrice")
	private String unitOfMeasureOnSiteParkingPrice;
	
	@Column(name="publicTransport")
	private String publicTransport;
	
	@Column(name="limuousineService")
	private String limuousineService;
	
	@Column(name="shuttleBus")
	private String shuttleBus;
	
	@Column(name="taxiService")
	private String taxiService;
	
	@Column(name="tailor")
	private String tailor;
	
	@Column(name="terrace")
	private String terrace;
	
	@Column(name="restaurant")
	private String restaurant;
	
	@Column(name="medicalFacility")
	private String medicalFacility;
	
	@Column(name="luggageStorage")
	private String luggageStorage;
	
	@Column(name="laundryService")
	private String laundryService;
	
	@Column(name="businessCentre")
	private String businessCentre;
	
	@Column(name="cloakroomService")
	private String cloakroomService;
	
	@Column(name="bedRooms")
	private String bedRooms;
	
	@Column(name="rampAccess")
	private String rampAccess;
	
	@Column(name="bar")
	private String bar;
	
	@Column(name="ballRoom")
	private String ballRoom;
	
	@Column(name="concierge")
	private String concierge;
	
	@Column(name="disabledFacilities")
	private String disabledFacilities;
	
	@Column(name="heating")
	private String heating;
	
	@Column(name="helipad")
	private String helipad;
	
	@Column(name="garden")
	private String garden;
	
	@Column(name="freeWifi")
	private String freeWifi;
	
	@Column(name="elevator")
	private String elevator;
	
	@Column(name="frontDesk")
	private String frontDesk;
	
	@Column(name="shoppingArea")
	private String shoppingArea;
	
	@Column(name="closeToNature")
	private String closeToNature;
	
	@Column(name="countrySide")
	private String countrySide;
	
	@Column(name="inTheAirport")
	private String inTheAirport;
	
	@Column(name="inTheCentre")
	private String inTheCentre;
	
	@Column(name="nearAirport")
	private String nearAirport;
	
	@Column(name="nearAttractions")
	private String nearAttractions;
	
	@Column(name="nearHarbor")
	private String nearHarbor;
	
	@Column(name="nearMotorway")
	private String nearMotorway;
	
	@Column(name="nearRailwayStation")
	private String nearRailwayStation;
	
	@Column(name="nearTheCentre")
	private String nearTheCentre;
	
	@Column(name="nearByWater")
	private String nearByWater;
	
	@Column(name="suburbs")
	private String suburbs;
	
	@Column(name="oneTeaBreak")
	private String oneTeaBreak;
	
	@Column(name="oneTeaBreakService")
	private String oneTeaBreakService;
	
	@Column(name="twoTeaBreak")
	private String twoTeaBreak;
	
	@Column(name="twoTeaBreakService")
	private String twoTeaBreakService;
	
	@Column(name="threeTeaBreak")
	private String threeTeaBreak;
	
	@Column(name="threeTeaBreakService")
	private String threeTeaBreakService;
	
	@Column(name="unlimitedTea")
	private String unlimitedTea;
	
	@Column(name="unlimitedTeaService")
	private String unlimitedTeaService;
	
	@Column(name="alcoholicBeverages")
	private String alcoholicBeverages;
	
	@Column(name="alcoholicBeveragesService")
	private String alcoholicBeveragesService;
	
	@Column(name="coldBeverages")
	private String coldBeverages;
	
	@Column(name="coldBeveragesService")
	private String coldBeveragesService;
	
	@Column(name="hotBeverages")
	private String hotBeverages;
	
	@Column(name="hotBeveragesService")
	private String hotBeveragesService;
	
	@Column(name="stillWater")
	private String stillWater;
	
	@Column(name="stillWaterService")
	private String stillWaterService;
	
	@Column(name="twoBreakfast")
	private String twoBreakfast;
	
	@Column(name="twoBreakfastService")
	private String twoBreakfastService;
	
	@Column(name="fullBreakfast")
	private String fullBreakfast;
	
	@Column(name="lunchBuffet")
	private String lunchBuffet;
	
	@Column(name="lunchBuffetService")
	private String lunchBuffetService;
	
	@Column(name="lunchAlaCarte")
	private String lunchAlaCarte;
	
	@Column(name="lunchAlaCarteService")
	private String lunchAlaCarteService;
	
	@Column(name="twoCourseMenu")
	private String twoCourseMenu;
	
	@Column(name="twoCourseMenuService")
	private String twoCourseMenuService;
	
	@Column(name="buffetLunch")
	private String buffetLunch;
	
	@Column(name="buffetLunchService")
	private String buffetLunchService;
	
	@Column(name="twoLunchAlaCarte")
	private String twoLunchAlaCarte;
	
	@Column(name="twoLunchAlaCarteService")
	private String twoLunchAlaCarteService;
	
	@Column(name="twoLunchBuffet")
	private String twoLunchBuffet;
	
	@Column(name="twoLunchBuffetService")
	private String twoLunchBuffetService;
	
	@Column(name="threeCourseLunch")
	private String threeCourseLunch;
	
	@Column(name="threeCourseLunchService")
	private String threeCourseLunchService;
	
	@Column(name="supper")
	private String supper;
	
	@Column(name="supperService")
	private String supperService;
	
	@Column(name="threeCourseDinner")
	private String threeCourseDinner;
	
	@Column(name="threeCourseDinnerService")
	private String threeCourseDinnerService;
	
	public HotelAmenities() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public String toString() {
		return "HotelAmenities [hotelAmenitiesId=" + hotelAmenitiesId + ", hotelId=" + hotelId + ", hasAccomodation="
				+ hasAccomodation + ", multiLinguaStaff=" + multiLinguaStaff + ", suppLanguages=" + suppLanguages
				+ ", siteSecurity=" + siteSecurity + ", tennis=" + tennis + ", waterSports=" + waterSports
				+ ", steamRoom=" + steamRoom + ", spa=" + spa + ", snooker=" + snooker + ", solarium=" + solarium
				+ ", winterSports=" + winterSports + ", shooting=" + shooting + ", sauna=" + sauna + ", fishing="
				+ fishing + ", golf=" + golf + ", croquet=" + croquet + ", bowls=" + bowls + ", badminton=" + badminton
				+ ", gym=" + gym + ", healthClub=" + healthClub + ", outdoorSwimmingPool=" + outdoorSwimmingPool
				+ ", jacuzzi=" + jacuzzi + ", indoorSwimmingPool=" + indoorSwimmingPool + ", horseRiding=" + horseRiding
				+ ", archery=" + archery + ", coachParking=" + coachParking + ", freeOffSiteParking="
				+ freeOffSiteParking + ", freeOnSiteParking=" + freeOnSiteParking + ", offSiteParkingWithFee="
				+ offSiteParkingWithFee + ", unitOfMeasureOffSiteParking=" + unitOfMeasureOffSiteParking
				+ ", unitOfMeasureOffSiteParkingPrice=" + unitOfMeasureOffSiteParkingPrice + ", onSiteParkingWithFee="
				+ onSiteParkingWithFee + ", unitOfMeasureOnSiteParking=" + unitOfMeasureOnSiteParking
				+ ", unitOfMeasureOnSiteParkingPrice=" + unitOfMeasureOnSiteParkingPrice + ", publicTransport="
				+ publicTransport + ", limuousineService=" + limuousineService + ", shuttleBus=" + shuttleBus
				+ ", taxiService=" + taxiService + ", tailor=" + tailor + ", terrace=" + terrace + ", restaurant="
				+ restaurant + ", medicalFacility=" + medicalFacility + ", luggageStorage=" + luggageStorage
				+ ", laundryService=" + laundryService + ", businessCentre=" + businessCentre + ", cloakroomService="
				+ cloakroomService + ", bedRooms=" + bedRooms + ", rampAccess=" + rampAccess + ", bar=" + bar
				+ ", ballRoom=" + ballRoom + ", concierge=" + concierge + ", disabledFacilities=" + disabledFacilities
				+ ", heating=" + heating + ", helipad=" + helipad + ", garden=" + garden + ", freeWifi=" + freeWifi
				+ ", elevator=" + elevator + ", frontDesk=" + frontDesk + ", shoppingArea=" + shoppingArea
				+ ", closeToNature=" + closeToNature + ", countrySide=" + countrySide + ", inTheAirport=" + inTheAirport
				+ ", inTheCentre=" + inTheCentre + ", nearAirport=" + nearAirport + ", nearAttractions="
				+ nearAttractions + ", nearHarbor=" + nearHarbor + ", nearMotorway=" + nearMotorway
				+ ", nearRailwayStation=" + nearRailwayStation + ", nearTheCentre=" + nearTheCentre + ", nearByWater="
				+ nearByWater + ", suburbs=" + suburbs + ", oneTeaBreak=" + oneTeaBreak + ", oneTeaBreakService="
				+ oneTeaBreakService + ", twoTeaBreak=" + twoTeaBreak + ", twoTeaBreakService=" + twoTeaBreakService
				+ ", threeTeaBreak=" + threeTeaBreak + ", threeTeaBreakService=" + threeTeaBreakService
				+ ", unlimitedTea=" + unlimitedTea + ", unlimitedTeaService=" + unlimitedTeaService
				+ ", alcoholicBeverages=" + alcoholicBeverages + ", alcoholicBeveragesService="
				+ alcoholicBeveragesService + ", coldBeverages=" + coldBeverages + ", coldBeveragesService="
				+ coldBeveragesService + ", hotBeverages=" + hotBeverages + ", hotBeveragesService="
				+ hotBeveragesService + ", stillWater=" + stillWater + ", stillWaterService=" + stillWaterService
				+ ", twoBreakfast=" + twoBreakfast + ", twoBreakfastService=" + twoBreakfastService + ", fullBreakfast="
				+ fullBreakfast + ", lunchBuffet=" + lunchBuffet + ", lunchBuffetService=" + lunchBuffetService
				+ ", lunchAlaCarte=" + lunchAlaCarte + ", lunchAlaCarteService=" + lunchAlaCarteService
				+ ", twoCourseMenu=" + twoCourseMenu + ", twoCourseMenuService=" + twoCourseMenuService
				+ ", buffetLunch=" + buffetLunch + ", buffetLunchService=" + buffetLunchService + ", twoLunchAlaCarte="
				+ twoLunchAlaCarte + ", twoLunchAlaCarteService=" + twoLunchAlaCarteService + ", twoLunchBuffet="
				+ twoLunchBuffet + ", twoLunchBuffetService=" + twoLunchBuffetService + ", threeCourseLunch="
				+ threeCourseLunch + ", threeCourseLunchService=" + threeCourseLunchService + ", supper=" + supper
				+ ", supperService=" + supperService + ", threeCourseDinner=" + threeCourseDinner
				+ ", threeCourseDinnerService=" + threeCourseDinnerService + ", snacks=" + snacks + ", freshFruits="
				+ freshFruits + "]";
	}

	public int getHotelAmenitiesId() {
		return hotelAmenitiesId;
	}

	public void setHotelAmenitiesId(int hotelAmenitiesId) {
		this.hotelAmenitiesId = hotelAmenitiesId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHasAccomodation() {
		return hasAccomodation;
	}

	public void setHasAccomodation(String hasAccomodation) {
		this.hasAccomodation = hasAccomodation;
	}

	public String getMultiLinguaStaff() {
		return multiLinguaStaff;
	}

	public void setMultiLinguaStaff(String multiLinguaStaff) {
		this.multiLinguaStaff = multiLinguaStaff;
	}

	public String getSuppLanguages() {
		return suppLanguages;
	}

	public void setSuppLanguages(String suppLanguages) {
		this.suppLanguages = suppLanguages;
	}

	public String getSiteSecurity() {
		return siteSecurity;
	}

	public void setSiteSecurity(String siteSecurity) {
		this.siteSecurity = siteSecurity;
	}

	public String getTennis() {
		return tennis;
	}

	public void setTennis(String tennis) {
		this.tennis = tennis;
	}

	public String getWaterSports() {
		return waterSports;
	}

	public void setWaterSports(String waterSports) {
		this.waterSports = waterSports;
	}

	public String getSteamRoom() {
		return steamRoom;
	}

	public void setSteamRoom(String steamRoom) {
		this.steamRoom = steamRoom;
	}

	public String getSpa() {
		return spa;
	}

	public void setSpa(String spa) {
		this.spa = spa;
	}

	public String getSnooker() {
		return snooker;
	}

	public void setSnooker(String snooker) {
		this.snooker = snooker;
	}

	public String getSolarium() {
		return solarium;
	}

	public void setSolarium(String solarium) {
		this.solarium = solarium;
	}

	public String getWinterSports() {
		return winterSports;
	}

	public void setWinterSports(String winterSports) {
		this.winterSports = winterSports;
	}

	public String getShooting() {
		return shooting;
	}

	public void setShooting(String shooting) {
		this.shooting = shooting;
	}

	public String getSauna() {
		return sauna;
	}

	public void setSauna(String sauna) {
		this.sauna = sauna;
	}

	public String getFishing() {
		return fishing;
	}

	public void setFishing(String fishing) {
		this.fishing = fishing;
	}

	public String getGolf() {
		return golf;
	}

	public void setGolf(String golf) {
		this.golf = golf;
	}

	public String getCroquet() {
		return croquet;
	}

	public void setCroquet(String croquet) {
		this.croquet = croquet;
	}

	public String getBowls() {
		return bowls;
	}

	public void setBowls(String bowls) {
		this.bowls = bowls;
	}

	public String getBadminton() {
		return badminton;
	}

	public void setBadminton(String badminton) {
		this.badminton = badminton;
	}

	public String getGym() {
		return gym;
	}

	public void setGym(String gym) {
		this.gym = gym;
	}

	public String getHealthClub() {
		return healthClub;
	}

	public void setHealthClub(String healthClub) {
		this.healthClub = healthClub;
	}

	public String getOutdoorSwimmingPool() {
		return outdoorSwimmingPool;
	}

	public void setOutdoorSwimmingPool(String outdoorSwimmingPool) {
		this.outdoorSwimmingPool = outdoorSwimmingPool;
	}

	public String getJacuzzi() {
		return jacuzzi;
	}

	public void setJacuzzi(String jacuzzi) {
		this.jacuzzi = jacuzzi;
	}

	public String getIndoorSwimmingPool() {
		return indoorSwimmingPool;
	}

	public void setIndoorSwimmingPool(String indoorSwimmingPool) {
		this.indoorSwimmingPool = indoorSwimmingPool;
	}

	public String getHorseRiding() {
		return horseRiding;
	}

	public void setHorseRiding(String horseRiding) {
		this.horseRiding = horseRiding;
	}

	public String getArchery() {
		return archery;
	}

	public void setArchery(String archery) {
		this.archery = archery;
	}

	public String getCoachParking() {
		return coachParking;
	}

	public void setCoachParking(String coachParking) {
		this.coachParking = coachParking;
	}

	public String getFreeOffSiteParking() {
		return freeOffSiteParking;
	}

	public void setFreeOffSiteParking(String freeOffSiteParking) {
		this.freeOffSiteParking = freeOffSiteParking;
	}

	public String getFreeOnSiteParking() {
		return freeOnSiteParking;
	}

	public void setFreeOnSiteParking(String freeOnSiteParking) {
		this.freeOnSiteParking = freeOnSiteParking;
	}

	public String getOffSiteParkingWithFee() {
		return offSiteParkingWithFee;
	}

	public void setOffSiteParkingWithFee(String offSiteParkingWithFee) {
		this.offSiteParkingWithFee = offSiteParkingWithFee;
	}

	public String getUnitOfMeasureOffSiteParking() {
		return unitOfMeasureOffSiteParking;
	}

	public void setUnitOfMeasureOffSiteParking(String unitOfMeasureOffSiteParking) {
		this.unitOfMeasureOffSiteParking = unitOfMeasureOffSiteParking;
	}

	public String getUnitOfMeasureOffSiteParkingPrice() {
		return unitOfMeasureOffSiteParkingPrice;
	}

	public void setUnitOfMeasureOffSiteParkingPrice(String unitOfMeasureOffSiteParkingPrice) {
		this.unitOfMeasureOffSiteParkingPrice = unitOfMeasureOffSiteParkingPrice;
	}

	public String getOnSiteParkingWithFee() {
		return onSiteParkingWithFee;
	}

	public void setOnSiteParkingWithFee(String onSiteParkingWithFee) {
		this.onSiteParkingWithFee = onSiteParkingWithFee;
	}

	public String getUnitOfMeasureOnSiteParking() {
		return unitOfMeasureOnSiteParking;
	}

	public void setUnitOfMeasureOnSiteParking(String unitOfMeasureOnSiteParking) {
		this.unitOfMeasureOnSiteParking = unitOfMeasureOnSiteParking;
	}

	public String getUnitOfMeasureOnSiteParkingPrice() {
		return unitOfMeasureOnSiteParkingPrice;
	}

	public void setUnitOfMeasureOnSiteParkingPrice(String unitOfMeasureOnSiteParkingPrice) {
		this.unitOfMeasureOnSiteParkingPrice = unitOfMeasureOnSiteParkingPrice;
	}

	public String getPublicTransport() {
		return publicTransport;
	}

	public void setPublicTransport(String publicTransport) {
		this.publicTransport = publicTransport;
	}

	public String getLimuousineService() {
		return limuousineService;
	}

	public void setLimuousineService(String limuousineService) {
		this.limuousineService = limuousineService;
	}

	public String getShuttleBus() {
		return shuttleBus;
	}

	public void setShuttleBus(String shuttleBus) {
		this.shuttleBus = shuttleBus;
	}

	public String getTaxiService() {
		return taxiService;
	}

	public void setTaxiService(String taxiService) {
		this.taxiService = taxiService;
	}

	public String getTailor() {
		return tailor;
	}

	public void setTailor(String tailor) {
		this.tailor = tailor;
	}

	public String getTerrace() {
		return terrace;
	}

	public void setTerrace(String terrace) {
		this.terrace = terrace;
	}

	public String getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(String restaurant) {
		this.restaurant = restaurant;
	}

	public String getMedicalFacility() {
		return medicalFacility;
	}

	public void setMedicalFacility(String medicalFacility) {
		this.medicalFacility = medicalFacility;
	}

	public String getLuggageStorage() {
		return luggageStorage;
	}

	public void setLuggageStorage(String luggageStorage) {
		this.luggageStorage = luggageStorage;
	}

	public String getLaundryService() {
		return laundryService;
	}

	public void setLaundryService(String laundryService) {
		this.laundryService = laundryService;
	}

	public String getBusinessCentre() {
		return businessCentre;
	}

	public void setBusinessCentre(String businessCentre) {
		this.businessCentre = businessCentre;
	}

	public String getCloakroomService() {
		return cloakroomService;
	}

	public void setCloakroomService(String cloakroomService) {
		this.cloakroomService = cloakroomService;
	}

	public String getBedRooms() {
		return bedRooms;
	}

	public void setBedRooms(String bedRooms) {
		this.bedRooms = bedRooms;
	}

	public String getRampAccess() {
		return rampAccess;
	}

	public void setRampAccess(String rampAccess) {
		this.rampAccess = rampAccess;
	}

	public String getBar() {
		return bar;
	}

	public void setBar(String bar) {
		this.bar = bar;
	}

	public String getBallRoom() {
		return ballRoom;
	}

	public void setBallRoom(String ballRoom) {
		this.ballRoom = ballRoom;
	}

	public String getConcierge() {
		return concierge;
	}

	public void setConcierge(String concierge) {
		this.concierge = concierge;
	}

	public String getDisabledFacilities() {
		return disabledFacilities;
	}

	public void setDisabledFacilities(String disabledFacilities) {
		this.disabledFacilities = disabledFacilities;
	}

	public String getHeating() {
		return heating;
	}

	public void setHeating(String heating) {
		this.heating = heating;
	}

	public String getHelipad() {
		return helipad;
	}

	public void setHelipad(String helipad) {
		this.helipad = helipad;
	}

	public String getGarden() {
		return garden;
	}

	public void setGarden(String garden) {
		this.garden = garden;
	}

	public String getFreeWifi() {
		return freeWifi;
	}

	public void setFreeWifi(String freeWifi) {
		this.freeWifi = freeWifi;
	}

	public String getElevator() {
		return elevator;
	}

	public void setElevator(String elevator) {
		this.elevator = elevator;
	}

	public String getFrontDesk() {
		return frontDesk;
	}

	public void setFrontDesk(String frontDesk) {
		this.frontDesk = frontDesk;
	}

	public String getShoppingArea() {
		return shoppingArea;
	}

	public void setShoppingArea(String shoppingArea) {
		this.shoppingArea = shoppingArea;
	}

	public String getCloseToNature() {
		return closeToNature;
	}

	public void setCloseToNature(String closeToNature) {
		this.closeToNature = closeToNature;
	}

	public String getCountrySide() {
		return countrySide;
	}

	public void setCountrySide(String countrySide) {
		this.countrySide = countrySide;
	}

	public String getInTheAirport() {
		return inTheAirport;
	}

	public void setInTheAirport(String inTheAirport) {
		this.inTheAirport = inTheAirport;
	}

	public String getInTheCentre() {
		return inTheCentre;
	}

	public void setInTheCentre(String inTheCentre) {
		this.inTheCentre = inTheCentre;
	}

	public String getNearAirport() {
		return nearAirport;
	}

	public void setNearAirport(String nearAirport) {
		this.nearAirport = nearAirport;
	}

	public String getNearAttractions() {
		return nearAttractions;
	}

	public void setNearAttractions(String nearAttractions) {
		this.nearAttractions = nearAttractions;
	}

	public String getNearHarbor() {
		return nearHarbor;
	}

	public void setNearHarbor(String nearHarbor) {
		this.nearHarbor = nearHarbor;
	}

	public String getNearMotorway() {
		return nearMotorway;
	}

	public void setNearMotorway(String nearMotorway) {
		this.nearMotorway = nearMotorway;
	}

	public String getNearRailwayStation() {
		return nearRailwayStation;
	}

	public void setNearRailwayStation(String nearRailwayStation) {
		this.nearRailwayStation = nearRailwayStation;
	}

	public String getNearTheCentre() {
		return nearTheCentre;
	}

	public void setNearTheCentre(String nearTheCentre) {
		this.nearTheCentre = nearTheCentre;
	}

	public String getNearByWater() {
		return nearByWater;
	}

	public void setNearByWater(String nearByWater) {
		this.nearByWater = nearByWater;
	}

	public String getSuburbs() {
		return suburbs;
	}

	public void setSuburbs(String suburbs) {
		this.suburbs = suburbs;
	}

	public String getOneTeaBreak() {
		return oneTeaBreak;
	}

	public void setOneTeaBreak(String oneTeaBreak) {
		this.oneTeaBreak = oneTeaBreak;
	}

	public String getOneTeaBreakService() {
		return oneTeaBreakService;
	}

	public void setOneTeaBreakService(String oneTeaBreakService) {
		this.oneTeaBreakService = oneTeaBreakService;
	}

	public String getTwoTeaBreak() {
		return twoTeaBreak;
	}

	public void setTwoTeaBreak(String twoTeaBreak) {
		this.twoTeaBreak = twoTeaBreak;
	}

	public String getTwoTeaBreakService() {
		return twoTeaBreakService;
	}

	public void setTwoTeaBreakService(String twoTeaBreakService) {
		this.twoTeaBreakService = twoTeaBreakService;
	}

	public String getThreeTeaBreak() {
		return threeTeaBreak;
	}

	public void setThreeTeaBreak(String threeTeaBreak) {
		this.threeTeaBreak = threeTeaBreak;
	}

	public String getThreeTeaBreakService() {
		return threeTeaBreakService;
	}

	public void setThreeTeaBreakService(String threeTeaBreakService) {
		this.threeTeaBreakService = threeTeaBreakService;
	}

	public String getUnlimitedTea() {
		return unlimitedTea;
	}

	public void setUnlimitedTea(String unlimitedTea) {
		this.unlimitedTea = unlimitedTea;
	}

	public String getUnlimitedTeaService() {
		return unlimitedTeaService;
	}

	public void setUnlimitedTeaService(String unlimitedTeaService) {
		this.unlimitedTeaService = unlimitedTeaService;
	}

	public String getAlcoholicBeverages() {
		return alcoholicBeverages;
	}

	public void setAlcoholicBeverages(String alcoholicBeverages) {
		this.alcoholicBeverages = alcoholicBeverages;
	}

	public String getAlcoholicBeveragesService() {
		return alcoholicBeveragesService;
	}

	public void setAlcoholicBeveragesService(String alcoholicBeveragesService) {
		this.alcoholicBeveragesService = alcoholicBeveragesService;
	}

	public String getColdBeverages() {
		return coldBeverages;
	}

	public void setColdBeverages(String coldBeverages) {
		this.coldBeverages = coldBeverages;
	}

	public String getColdBeveragesService() {
		return coldBeveragesService;
	}

	public void setColdBeveragesService(String coldBeveragesService) {
		this.coldBeveragesService = coldBeveragesService;
	}

	public String getHotBeverages() {
		return hotBeverages;
	}

	public void setHotBeverages(String hotBeverages) {
		this.hotBeverages = hotBeverages;
	}

	public String getHotBeveragesService() {
		return hotBeveragesService;
	}

	public void setHotBeveragesService(String hotBeveragesService) {
		this.hotBeveragesService = hotBeveragesService;
	}

	public String getStillWater() {
		return stillWater;
	}

	public void setStillWater(String stillWater) {
		this.stillWater = stillWater;
	}

	public String getStillWaterService() {
		return stillWaterService;
	}

	public void setStillWaterService(String stillWaterService) {
		this.stillWaterService = stillWaterService;
	}

	public String getTwoBreakfast() {
		return twoBreakfast;
	}

	public void setTwoBreakfast(String twoBreakfast) {
		this.twoBreakfast = twoBreakfast;
	}

	public String getTwoBreakfastService() {
		return twoBreakfastService;
	}

	public void setTwoBreakfastService(String twoBreakfastService) {
		this.twoBreakfastService = twoBreakfastService;
	}

	public String getFullBreakfast() {
		return fullBreakfast;
	}

	public void setFullBreakfast(String fullBreakfast) {
		this.fullBreakfast = fullBreakfast;
	}

	public String getLunchBuffet() {
		return lunchBuffet;
	}

	public void setLunchBuffet(String lunchBuffet) {
		this.lunchBuffet = lunchBuffet;
	}

	public String getLunchBuffetService() {
		return lunchBuffetService;
	}

	public void setLunchBuffetService(String lunchBuffetService) {
		this.lunchBuffetService = lunchBuffetService;
	}

	public String getLunchAlaCarte() {
		return lunchAlaCarte;
	}

	public void setLunchAlaCarte(String lunchAlaCarte) {
		this.lunchAlaCarte = lunchAlaCarte;
	}

	public String getLunchAlaCarteService() {
		return lunchAlaCarteService;
	}

	public void setLunchAlaCarteService(String lunchAlaCarteService) {
		this.lunchAlaCarteService = lunchAlaCarteService;
	}

	public String getTwoCourseMenu() {
		return twoCourseMenu;
	}

	public void setTwoCourseMenu(String twoCourseMenu) {
		this.twoCourseMenu = twoCourseMenu;
	}

	public String getTwoCourseMenuService() {
		return twoCourseMenuService;
	}

	public void setTwoCourseMenuService(String twoCourseMenuService) {
		this.twoCourseMenuService = twoCourseMenuService;
	}

	public String getBuffetLunch() {
		return buffetLunch;
	}

	public void setBuffetLunch(String buffetLunch) {
		this.buffetLunch = buffetLunch;
	}

	public String getBuffetLunchService() {
		return buffetLunchService;
	}

	public void setBuffetLunchService(String buffetLunchService) {
		this.buffetLunchService = buffetLunchService;
	}

	public String getTwoLunchAlaCarte() {
		return twoLunchAlaCarte;
	}

	public void setTwoLunchAlaCarte(String twoLunchAlaCarte) {
		this.twoLunchAlaCarte = twoLunchAlaCarte;
	}

	public String getTwoLunchAlaCarteService() {
		return twoLunchAlaCarteService;
	}

	public void setTwoLunchAlaCarteService(String twoLunchAlaCarteService) {
		this.twoLunchAlaCarteService = twoLunchAlaCarteService;
	}

	public String getTwoLunchBuffet() {
		return twoLunchBuffet;
	}

	public void setTwoLunchBuffet(String twoLunchBuffet) {
		this.twoLunchBuffet = twoLunchBuffet;
	}

	public String getTwoLunchBuffetService() {
		return twoLunchBuffetService;
	}

	public void setTwoLunchBuffetService(String twoLunchBuffetService) {
		this.twoLunchBuffetService = twoLunchBuffetService;
	}

	public String getThreeCourseLunch() {
		return threeCourseLunch;
	}

	public void setThreeCourseLunch(String threeCourseLunch) {
		this.threeCourseLunch = threeCourseLunch;
	}

	public String getThreeCourseLunchService() {
		return threeCourseLunchService;
	}

	public void setThreeCourseLunchService(String threeCourseLunchService) {
		this.threeCourseLunchService = threeCourseLunchService;
	}

	public String getSupper() {
		return supper;
	}

	public void setSupper(String supper) {
		this.supper = supper;
	}

	public String getSupperService() {
		return supperService;
	}

	public void setSupperService(String supperService) {
		this.supperService = supperService;
	}

	public String getThreeCourseDinner() {
		return threeCourseDinner;
	}

	public void setThreeCourseDinner(String threeCourseDinner) {
		this.threeCourseDinner = threeCourseDinner;
	}

	public String getThreeCourseDinnerService() {
		return threeCourseDinnerService;
	}

	public void setThreeCourseDinnerService(String threeCourseDinnerService) {
		this.threeCourseDinnerService = threeCourseDinnerService;
	}

	public String getSnacks() {
		return snacks;
	}

	public void setSnacks(String snacks) {
		this.snacks = snacks;
	}

	public String getFreshFruits() {
		return freshFruits;
	}

	public void setFreshFruits(String freshFruits) {
		this.freshFruits = freshFruits;
	}

	@Column(name="snacks")
	private String snacks;
	
	@Column(name="freshFruits")
	private String freshFruits;
*/
	
}

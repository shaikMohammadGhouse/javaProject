package com.mindtree.meetex.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.jmx.export.annotation.ManagedOperationParameter;

@Entity
@Table(name="amenitymasterdata")
public class AmenityMasterData {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="amenity_id")
	private int amenityId;
	
	@Column(name="is_billable")
	private String isBillable;
	
	@Column(name="is_selectable")
	private String isSelectable;

	@Column(name="is_quantifiable")
	private String isQuantifiable;
	
	@Column(name="amenity_name")
	private String amenityName;
	
	public AmenityMasterData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AmenityMasterData(int amenityId, String isBillable, String isSelectable, String isQuantifiable,
			String amenityName, AmenityGroup amenityGroup) {
		super();
		this.amenityId = amenityId;
		this.isBillable = isBillable;
		this.isSelectable = isSelectable;
		this.isQuantifiable = isQuantifiable;
		this.amenityName = amenityName;
		
	}

	public int getAmenityId() {
		return amenityId;
	}

	public void setAmenityId(int amenityId) {
		this.amenityId = amenityId;
	}

	public String getIsBillable() {
		return isBillable;
	}

	public void setIsBillable(String isBillable) {
		this.isBillable = isBillable;
	}

	public String getIsSelectable() {
		return isSelectable;
	}

	public void setIsSelectable(String isSelectable) {
		this.isSelectable = isSelectable;
	}

	public String getIsQuantifiable() {
		return isQuantifiable;
	}

	public void setIsQuantifiable(String isQuantifiable) {
		this.isQuantifiable = isQuantifiable;
	}

	public String getAmenityName() {
		return amenityName;
	}

	public void setAmenityName(String amenityName) {
		this.amenityName = amenityName;
	}	
	
}

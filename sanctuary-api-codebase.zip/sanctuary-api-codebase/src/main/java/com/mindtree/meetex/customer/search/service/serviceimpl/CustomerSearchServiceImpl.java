package com.mindtree.meetex.customer.search.service.serviceimpl;

import com.mindtree.meetex.customer.search.service.CustomerSearchService;

public class CustomerSearchServiceImpl implements CustomerSearchService{

}

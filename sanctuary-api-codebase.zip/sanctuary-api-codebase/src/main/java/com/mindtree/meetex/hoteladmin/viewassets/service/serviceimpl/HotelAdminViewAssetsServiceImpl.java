package com.mindtree.meetex.hoteladmin.viewassets.service.serviceimpl;

import com.mindtree.meetex.hoteladmin.viewassets.service.HotelAdminViewAssetsService;

public class HotelAdminViewAssetsServiceImpl implements HotelAdminViewAssetsService{

}

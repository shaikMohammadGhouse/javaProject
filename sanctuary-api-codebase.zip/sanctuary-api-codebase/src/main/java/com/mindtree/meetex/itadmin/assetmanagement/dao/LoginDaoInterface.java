package com.mindtree.meetex.itadmin.assetmanagement.dao;

import com.mindtree.meetex.entity.Customer;
import com.mindtree.meetex.entity.LogIn;

public interface LoginDaoInterface {

Customer authenticateCustomer(LogIn login );
}

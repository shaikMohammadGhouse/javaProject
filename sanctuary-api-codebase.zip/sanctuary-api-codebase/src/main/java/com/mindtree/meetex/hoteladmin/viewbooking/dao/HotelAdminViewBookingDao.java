package com.mindtree.meetex.hoteladmin.viewbooking.dao;

public interface HotelAdminViewBookingDao {

}

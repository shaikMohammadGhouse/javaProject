package com.mindtree.meetex.hoteladmin.login.service.serviceimpl;

import com.mindtree.meetex.hoteladmin.login.service.HotelAdminLogInService;

public class HotelAdminLogInServiceImpl implements HotelAdminLogInService {

}

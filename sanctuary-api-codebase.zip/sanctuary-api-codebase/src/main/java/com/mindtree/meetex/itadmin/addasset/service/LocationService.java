package com.mindtree.meetex.itadmin.addasset.service;

import java.util.List;

import com.mindtree.meetex.entity.LocationMaster;

public interface LocationService {

	public List<LocationMaster> getLocation();


}

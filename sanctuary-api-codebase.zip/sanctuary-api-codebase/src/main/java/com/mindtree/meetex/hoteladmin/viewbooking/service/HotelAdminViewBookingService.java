package com.mindtree.meetex.hoteladmin.viewbooking.service;

public interface HotelAdminViewBookingService {

}

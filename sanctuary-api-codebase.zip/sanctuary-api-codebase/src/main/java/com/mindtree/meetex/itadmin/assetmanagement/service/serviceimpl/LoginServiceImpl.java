package com.mindtree.meetex.itadmin.assetmanagement.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.meetex.entity.Customer;
import com.mindtree.meetex.entity.LogIn;
import com.mindtree.meetex.itadmin.assetmanagement.dao.LoginDaoInterface;
import com.mindtree.meetex.itadmin.assetmanagement.service.LoginServiceInterface;
@Service
public class LoginServiceImpl implements LoginServiceInterface {
 
	@Autowired
	 private LoginDaoInterface loginDaoInterface;
	 

	public Customer authenticateCustomer(LogIn login) {
		
		return this.authenticateCustomer(login);
	}

	public LoginDaoInterface getLoginDaoInterface() {
		return loginDaoInterface;
	}

	public void setLoginDaoInterface(LoginDaoInterface loginDaoInterface) {
		this.loginDaoInterface = loginDaoInterface;
	}

	
}

package com.mindtree.meetex.customer.search.dao.daoimpl;

import com.mindtree.meetex.customer.search.dao.CustomerSearchDao;

public class CustomerSearchDaoImpl implements CustomerSearchDao {

}

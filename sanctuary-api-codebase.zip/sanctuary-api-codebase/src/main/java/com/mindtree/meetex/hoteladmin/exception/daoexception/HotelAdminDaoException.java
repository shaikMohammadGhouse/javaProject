package com.mindtree.meetex.hoteladmin.exception.daoexception;

public class HotelAdminDaoException {

}

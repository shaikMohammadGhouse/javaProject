package com.mindtree.meetex.itadmin.addasset.dao.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.meetex.entity.AssetType;
import com.mindtree.meetex.entity.LocationMaster;
import com.mindtree.meetex.itadmin.addasset.dao.LocationDao;

public class LocationDaoImpl implements LocationDao{
	
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings ("unchecked")
	
	public List<LocationMaster> getLocation() {
		List<LocationMaster> location = getSession().createQuery("from LocationMaster").list();
		return location;
	}
}

package com.mindtree.meetex.itadmin.addasset.dao;

import com.mindtree.meetex.entity.HotelAmenities;
import com.mindtree.meetex.itadmin.addasset.dto.HotelAmenitiesDto;

public interface HotelAmenitiesDao {

	void addHotelAmenities(HotelAmenitiesDto hotelAmenitiesDto);

}

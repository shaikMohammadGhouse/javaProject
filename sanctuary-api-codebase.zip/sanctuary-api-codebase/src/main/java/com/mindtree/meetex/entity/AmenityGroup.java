package com.mindtree.meetex.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="amenitygroup")
public class AmenityGroup {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="amenitygroup_id")
	private int amenityGroupId;
	
	@Column(name="amenitygroup_name")
	private String amenityGroupName;
	

	public AmenityGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AmenityGroup(int amenityGroupId, String amenityGroupName, Set<AmenityMasterData> amenityMasterData) {
		super();
		this.amenityGroupId = amenityGroupId;
		this.amenityGroupName = amenityGroupName;
	}

	public int getAmenityGroupId() {
		return amenityGroupId;
	}

	public void setAmenityGroupId(int amenityGroupId) {
		this.amenityGroupId = amenityGroupId;
	}

	public String getAmenityGroupName() {
		return amenityGroupName;
	}

	public void setAmenityGroupName(String amenityGroupName) {
		this.amenityGroupName = amenityGroupName;
	}
	
}

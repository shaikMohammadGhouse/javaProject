package com.mindtree.meetex.itadmin.addasset.dao;

import java.util.List;

import com.mindtree.meetex.entity.AssetMaster;
import com.mindtree.meetex.entity.AssetType;

public interface AddAssetDao {

	public List<AssetType> getALLAssetTypes();

	public int getAssetTypeId(String assetType);

	public int getHotelId(String hotelMaster);

	public int getUnitOfMeasure(String unitOfMeasure);

	public void addAssetAmenity(AssetMaster assetMasterData);

}

package com.mindtree.meetex.itadmin.addasset.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.meetex.entity.LocationMaster;
import com.mindtree.meetex.itadmin.addasset.dao.LocationDao;
import com.mindtree.meetex.itadmin.addasset.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService{

	@Autowired
	private LocationDao locationDao;
	
	public LocationDao getLocationDao() {
		return locationDao;
	}

	public void setLocationDao(LocationDao locationDao) {
		this.locationDao = locationDao;
	}

	@Transactional
	public List<LocationMaster> getLocation() {
		
		return locationDao.getLocation();
	}

}

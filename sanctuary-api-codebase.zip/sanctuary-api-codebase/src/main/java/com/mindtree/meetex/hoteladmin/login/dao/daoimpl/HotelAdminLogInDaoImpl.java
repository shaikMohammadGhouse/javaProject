package com.mindtree.meetex.hoteladmin.login.dao.daoimpl;

import com.mindtree.meetex.hoteladmin.login.dao.HotelAdminLogInDao;

public class HotelAdminLogInDaoImpl implements HotelAdminLogInDao{

}

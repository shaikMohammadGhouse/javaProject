package com.mindtree.meetex.customer.login.dao;

import java.util.List;

import com.mindtree.meetex.entity.Customer;

public interface CustomerLogInDao {
	
	public List<Customer> getAllCustomers();
 
}

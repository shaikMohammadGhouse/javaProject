package com.mindtree.meetex.itadmin.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/assetmanagement")
public class AssetManagementController {
	
	@RequestMapping(value="/addassets",method=RequestMethod.POST)
	public String addAssets()
	{
		
		return "Added successfully";
	}

}

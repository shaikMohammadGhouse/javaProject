package com.mindtree.meetex.customer.signup.service;

public interface CustomerSignUpService {

}

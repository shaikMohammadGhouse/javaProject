package com.mindtree.meetex.itadmin.addasset.dto;

public class AssetMasterDto {

	private int assetId;
	
	private String hotelMaster;
	
	private String assetName;
	
	private String assetType;
	
	private String locationInHotel;
	
	private int dimensionsLength ;
		
	private int dimensionsWidth ;
	
	private int dimensionsHeight ;
	
	private int maxGuests ;
	
	private String unitOfMeasure ;
	
	private int basePrice;

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public String getHotelMaster() {
		return hotelMaster;
	}

	public void setHotelMaster(String hotelMaster) {
		this.hotelMaster = hotelMaster;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getLocationInHotel() {
		return locationInHotel;
	}

	public void setLocationInHotel(String locationInHotel) {
		this.locationInHotel = locationInHotel;
	}

	public int getDimensionsLength() {
		return dimensionsLength;
	}

	public void setDimensionsLength(int dimensionsLength) {
		this.dimensionsLength = dimensionsLength;
	}

	public int getDimensionsWidth() {
		return dimensionsWidth;
	}

	public void setDimensionsWidth(int dimensionsWidth) {
		this.dimensionsWidth = dimensionsWidth;
	}

	public int getDimensionsHeight() {
		return dimensionsHeight;
	}

	public void setDimensionsHeight(int dimensionsHeight) {
		this.dimensionsHeight = dimensionsHeight;
	}

	public int getMaxGuests() {
		return maxGuests;
	}

	public void setMaxGuests(int maxGuests) {
		this.maxGuests = maxGuests;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public int getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(int basePrice) {
		this.basePrice = basePrice;
	}
	
	
}

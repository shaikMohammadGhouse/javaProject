package com.mindtree.meetex.itadmin.addasset.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.meetex.entity.HotelAmenities;
import com.mindtree.meetex.itadmin.addasset.dao.HotelAmenitiesDao;
import com.mindtree.meetex.itadmin.addasset.dto.HotelAmenitiesDto;
import com.mindtree.meetex.itadmin.addasset.service.HotelAmenitiesService;

@Service
public class HotelAmenitiesServiceImpl implements HotelAmenitiesService{
	
	@Autowired
	private HotelAmenitiesDao hotelAmenitiesDao;
	
	public HotelAmenitiesDao getHotelAmenitiesDao() {
		return hotelAmenitiesDao;
	}

	public void setHotelAmenitiesDao(HotelAmenitiesDao hotelAmenitiesDao) {
		this.hotelAmenitiesDao = hotelAmenitiesDao;
	}

	@Transactional
	public void addAssetAmenity(HotelAmenitiesDto hotelAmenitiesDto) {
		this.hotelAmenitiesDao.addHotelAmenities(hotelAmenitiesDto);
	}

}

package com.mindtree.meetex.itadmin.addasset.dao.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.meetex.entity.AssetMaster;
import com.mindtree.meetex.entity.AssetType;
import com.mindtree.meetex.entity.HotelMaster;
import com.mindtree.meetex.entity.UnitOfMeasure;
import com.mindtree.meetex.itadmin.addasset.dao.AddAssetDao;

public class AddAssetDaoImpl implements AddAssetDao{

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings ("unchecked")

	public List<AssetType> getALLAssetTypes() {
		List<AssetType> assetType = getSession().createQuery("from AssetType").list();	
		return assetType;
	}
	
	@SuppressWarnings ("unchecked")

	public int getAssetTypeId(String assetType){
		System.out.println(assetType);
		List<AssetType> assetTypeSearched = getSession().createQuery("from AssetType where assetTypeName='"+assetType+"'").list();
		System.out.println((assetTypeSearched.get(0)).getAsseTypeId());
		return (assetTypeSearched.get(0)).getAsseTypeId();	
	}
	
	@SuppressWarnings ("unchecked")

	public int getHotelId(String hotelMaster){
		List<HotelMaster> hotelMasterSearched = getSession().createQuery("from HotelMaster where hotelName='"+hotelMaster+"'").list();
		return (hotelMasterSearched.get(0)).getHotelId();	
	}
	
	@SuppressWarnings ("unchecked")
	
	public int getUnitOfMeasure(String unitOfMeasure){
		List<UnitOfMeasure> unitOfMeasureSearched = getSession().createQuery("from UnitOfMeasure where unitOfMeasureName='"+unitOfMeasure+"'").list();
		return (unitOfMeasureSearched.get(0)).getUnitOfMeasureId();	
	
	}	
	
//	@Override
//	public void addAssetAmenity(AssetMaster assetMasterData){
//		System.out.println("Got"+assetMasterData.getAssetType());
//		getSession().persist(assetMasterData);
//	}
	

	public void addAssetAmenity(AssetMaster assetMasterData) {
		System.out.println(assetMasterData);
		getSession().save(assetMasterData);
		
		//logger.info("Product is added successfully");
	}


	
}

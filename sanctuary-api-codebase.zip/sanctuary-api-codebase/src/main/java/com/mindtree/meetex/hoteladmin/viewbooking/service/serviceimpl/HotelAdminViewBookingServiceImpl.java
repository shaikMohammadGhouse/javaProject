package com.mindtree.meetex.hoteladmin.viewbooking.service.serviceimpl;

import com.mindtree.meetex.hoteladmin.viewbooking.service.HotelAdminViewBookingService;

public class HotelAdminViewBookingServiceImpl implements HotelAdminViewBookingService {

}

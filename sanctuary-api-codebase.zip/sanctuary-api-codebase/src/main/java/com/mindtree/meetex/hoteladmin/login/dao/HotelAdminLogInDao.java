package com.mindtree.meetex.hoteladmin.login.dao;

public interface HotelAdminLogInDao {

}

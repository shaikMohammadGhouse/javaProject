package com.mindtree.meetex.itadmin.assetmanagement.service;

import com.mindtree.meetex.entity.Customer;
import com.mindtree.meetex.entity.LogIn;

public interface LoginServiceInterface {
	Customer authenticateCustomer(LogIn login);
}

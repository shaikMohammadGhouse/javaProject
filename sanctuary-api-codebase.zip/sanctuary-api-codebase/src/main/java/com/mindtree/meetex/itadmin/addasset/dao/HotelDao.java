package com.mindtree.meetex.itadmin.addasset.dao;

import java.util.List;

import com.mindtree.meetex.entity.HotelMaster;

public interface HotelDao {

	public List<HotelMaster> getHotel();

}

package com.mindtree.meetex.itadmin.controller;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.meetex.itadmin.assetmanagement.service.AmenityMasterService;

@Repository
@CrossOrigin
@RequestMapping(value="amenity")
public class AmenityMasterController {
	
	private AmenityMasterService amenityMasterService;

	public AmenityMasterService getAmenityMasterService() {
		return amenityMasterService;
	}

	public void setAmenityMasterService(AmenityMasterService amenityMasterService) {
		this.amenityMasterService = amenityMasterService;
	}
	

}

package com.mindtree.meetex.customer.login.service.serviceimpl;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.meetex.customer.login.dao.CustomerLogInDao;
import com.mindtree.meetex.customer.login.service.CustomerLoginService;
import com.mindtree.meetex.entity.Customer;

@Service
public class CustomerLoginServiceImpl implements CustomerLoginService {
	
	@Autowired
	private CustomerLogInDao customerLogInDao;
	
	@Transactional
	 public List<Customer> getAllCustomers() {
	  return this.customerLogInDao.getAllCustomers();
	 }

	public CustomerLogInDao getCustomerLogInDao() {
		return customerLogInDao;
	}

	public void setCustomerLogInDao(CustomerLogInDao customerLogInDao) {
		this.customerLogInDao = customerLogInDao;
	}


}

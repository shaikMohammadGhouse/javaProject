package com.mindtree.meetex.itadmin.assetmanagement.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.meetex.entity.AmenityMasterData;
import com.mindtree.meetex.itadmin.assetmanagement.dao.AmenityMasterDao;
@Service
public class AmenityMasterServiceImpl implements AmenityMasterDao{

	@Autowired
	 private AmenityMasterDao amenityMasterDao;

	public void addAmenities(AmenityMasterData amenity) {
		
		
	}


	public List<AmenityMasterData> getALLAmenity() {
		
		return this.getALLAmenity();
	}


	public AmenityMasterData getAmenity(int amenityId) {
		
		return this.getAmenity(amenityId);
	}

	public AmenityMasterDao getAmenityMasterDao() {
		return amenityMasterDao;
	}

	public void setAmenityMasterDao(AmenityMasterDao amenityMasterDao) {
		this.amenityMasterDao = amenityMasterDao;
	}

}

package com.mindtree.meetex.itadmin.addasset.dao.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.meetex.entity.HotelMaster;
import com.mindtree.meetex.entity.LocationMaster;
import com.mindtree.meetex.itadmin.addasset.dao.HotelDao;

public class HotelDaoImpl implements HotelDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings ("unchecked")
	public List<HotelMaster> getHotel(){
		List<HotelMaster> hotel = getSession().createQuery("from HotelMaster").list();
		return hotel;
	}
}

package com.mindtree.meetex.entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="locationmaster")
public class LocationMaster {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="location_id")
	private int LocationId;
	
	@Column(name="location_name")
	private String LocationName;
	
	public LocationMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocationMaster(int locationId, String locationName, Set<HotelMaster> hotelMaster) {
		super();
		LocationId = locationId;
		LocationName = locationName;
		
	}

	public int getLocationId() {
		return LocationId;
	}

	public void setLocationId(int locationId) {
		LocationId = locationId;
	}

	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}

	
	}

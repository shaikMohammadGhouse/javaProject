package com.mindtree.meetex.itadmin.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.meetex.entity.AssetMaster;
import com.mindtree.meetex.entity.AssetType;
import com.mindtree.meetex.entity.HotelAmenities;
import com.mindtree.meetex.entity.HotelMaster;
import com.mindtree.meetex.entity.LocationMaster;
import com.mindtree.meetex.itadmin.addasset.dto.AssetMasterDto;
import com.mindtree.meetex.itadmin.addasset.dto.HotelAmenitiesDto;
import com.mindtree.meetex.itadmin.addasset.service.AddAssetService;
import com.mindtree.meetex.itadmin.addasset.service.HotelAmenitiesService;
import com.mindtree.meetex.itadmin.addasset.service.HotelService;
import com.mindtree.meetex.itadmin.addasset.service.LocationService;

@RestController
@RequestMapping(value="/itadmin")
public class ItAdminController {

	@Autowired(required = true)
	private AddAssetService addAssetService;
	
	@Autowired(required=true)
	private LocationService locationService;
	
	@Autowired(required=true)
	private HotelService hotelService;
	
	@Autowired(required=true)
	private HotelAmenitiesService hotelAmenitiesService;
	
	@GET
	@RequestMapping(value="/assettype")
	public List<AssetType> getAssetType(){
		return addAssetService.getALLAssetTypes();
	}
		
	@POST
	@RequestMapping(value="/addassetmaster")
	public void addProducts(@RequestBody AssetMasterDto assetMasterDto) {
		AssetMaster assetMasterData = new AssetMaster();
		
		int assetTypeId = addAssetService.getAssetTypeId(assetMasterDto.getAssetType());
		System.out.println(assetTypeId);
		assetMasterData.setAssetType(assetTypeId);
		System.out.println(assetMasterData.getAssetType());
		assetMasterData.setAssetName(assetMasterDto.getAssetName());
		int hotelId = addAssetService.getHotelId(assetMasterDto.getHotelMaster());
		assetMasterData.setHotelMaster(hotelId);
		assetMasterData.setLocationInHotel(assetMasterDto.getLocationInHotel());
		assetMasterData.setDimensionsLength(assetMasterDto.getDimensionsLength());
		assetMasterData.setDimensionsWidth(assetMasterDto.getDimensionsWidth());
		assetMasterData.setDimensionsHeight(assetMasterDto.getDimensionsHeight());
		assetMasterData.setMaxGuests(assetMasterDto.getMaxGuests());
		int uom = addAssetService.getUnitOfMeasure(assetMasterDto.getUnitOfMeasure());
		assetMasterData.setUnitOfMeasure(uom);
		assetMasterData.setBasePrice(assetMasterDto.getBasePrice());
		
		this.addAssetService.addAssetAmenity(assetMasterData);
	}
	
	@GET
	@RequestMapping(value="/location")
	public List<LocationMaster> getLocation()
	{
		return locationService.getLocation();
	}
	
	@GET
	@RequestMapping(value="/hotel")
	public List<HotelMaster> getHotel()
	{
		return hotelService.getHotel();
	}
	
	@POST
	@RequestMapping(value="/addhotelamenities")
	public void addHotelAmenities(@RequestBody HotelAmenitiesDto hotelAmenitiesDto) {
		
		this.hotelAmenitiesService.addAssetAmenity(hotelAmenitiesDto);
	}
	
	
}

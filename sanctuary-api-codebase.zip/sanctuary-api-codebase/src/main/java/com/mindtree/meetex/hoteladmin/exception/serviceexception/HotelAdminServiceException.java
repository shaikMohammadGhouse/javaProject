package com.mindtree.meetex.hoteladmin.exception.serviceexception;

public class HotelAdminServiceException {

}

package com.mindtree.meetex.itadmin.assetmanagement.service;

import java.util.List;

import com.mindtree.meetex.entity.AmenityMasterData;

public interface AmenityMasterService {

	void addAmenities(AmenityMasterData amenity);
	List<AmenityMasterData> getALLAmenity();
	AmenityMasterData getAmenity(int amenityId);
}

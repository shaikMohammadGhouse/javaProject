package com.mindtree.meetex.entity;

import java.util.Set;

import javax.persistence.*;



@Entity
@Table (name="assettype")
public class AssetType 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column (name="asset_type_id")
	private int asseTypeId;
	
	@Column(name="asset_type_name")
	private String assetTypeName;
	
//	@OneToMany(mappedBy="assetType")
//	private Set<AssetMaster> assetMaster;

	public AssetType() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetType(int asseTypeId, String assetTypeName, Set<AssetMaster> assetMaster) {
		super();
		this.asseTypeId = asseTypeId;
		this.assetTypeName = assetTypeName;
//		this.assetMaster = assetMaster;
	}

	public int getAsseTypeId() {
		return asseTypeId;
	}

	public void setAsseTypeId(int asseTypeId) {
		this.asseTypeId = asseTypeId;
	}

	public String getAssetTypeName() {
		return assetTypeName;
	}

	public void setAssetTypeName(String assetTypeName) {
		this.assetTypeName = assetTypeName;
	}

//	public Set<AssetMaster> getAssetMaster() {
//		return assetMaster;
//	}
//
//	public void setAssetMaster(Set<AssetMaster> assetMaster) {
//		this.assetMaster = assetMaster;
//	}
	
	
	
}

package com.mindtree.meetex.entity;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="booking")
public class Booking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="booking_id")
	private int bookingId;
	
	@Column(name="from_date")
	private Date fromDate;
	
	@Column(name="asset_id")
	private int assetMaster;

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Booking(int bookingId, Date fromDate, Set<BookingDetail> bookingDetails, int assetMaster) {
		super();
		this.bookingId = bookingId;
		this.fromDate = fromDate;
		this.assetMaster = assetMaster;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public int getAssetMaster() {
		return assetMaster;
	}

	public void setAssetMaster(int assetMaster) {
		this.assetMaster = assetMaster;
	}

	

	
}

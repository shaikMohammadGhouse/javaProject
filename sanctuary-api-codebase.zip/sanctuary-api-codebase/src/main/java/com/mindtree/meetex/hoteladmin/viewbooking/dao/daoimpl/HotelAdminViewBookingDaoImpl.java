package com.mindtree.meetex.hoteladmin.viewbooking.dao.daoimpl;

import com.mindtree.meetex.hoteladmin.viewbooking.dao.HotelAdminViewBookingDao;

public class HotelAdminViewBookingDaoImpl implements HotelAdminViewBookingDao {

}

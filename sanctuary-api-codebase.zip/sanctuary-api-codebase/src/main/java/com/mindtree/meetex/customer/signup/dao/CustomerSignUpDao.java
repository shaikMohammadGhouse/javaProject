package com.mindtree.meetex.customer.signup.dao;

public interface CustomerSignUpDao {

}

package com.mindtree.meetex.entity;

import javax.persistence.*;

@Entity
@Table(name="assetamenity")
public class AssetAmenity 
{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column (name="asset_amenity_id")
	private int assetAmenityId;
	
	@Column (name="is_available")
	private String isAvailable;
	
	@Column (name="unit_price")
	private int unitPrice;
	
	@Column (name="permit_quantity_entry")
	private String permitQuantityEntry;
	
	@Column (name="permit_selection")
	private String permitSelection;
	
	@Column(name="amenity_id")
	private int amenityMasterData;
	
	@Column(name="unit_of_measure_id")
	private int unitOfMeasure;

	@Column(name="asset_id")
	private int assetMaster;

	public AssetAmenity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetAmenity(int assetAmenityId, String isAvailable, int unitPrice, String permitQuantityEntry,
			String permitSelection, int amenityMasterData, int unitOfMeasure,
			int assetMaster) {
		super();
		this.assetAmenityId = assetAmenityId;
		this.isAvailable = isAvailable;
		this.unitPrice = unitPrice;
		this.permitQuantityEntry = permitQuantityEntry;
		this.permitSelection = permitSelection;
		this.amenityMasterData = amenityMasterData;
		this.unitOfMeasure = unitOfMeasure;
		this.assetMaster = assetMaster;
	}

	public int getAssetAmenityId() {
		return assetAmenityId;
	}

	public void setAssetAmenityId(int assetAmenityId) {
		this.assetAmenityId = assetAmenityId;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public int getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getPermitQuantityEntry() {
		return permitQuantityEntry;
	}

	public void setPermitQuantityEntry(String permitQuantityEntry) {
		this.permitQuantityEntry = permitQuantityEntry;
	}

	public String getPermitSelection() {
		return permitSelection;
	}

	public void setPermitSelection(String permitSelection) {
		this.permitSelection = permitSelection;
	}

	public int getAmenityMasterData() {
		return amenityMasterData;
	}

	public void setAmenityMasterData(int amenityMasterData) {
		this.amenityMasterData = amenityMasterData;
	}

	public int getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(int unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public int getAssetMaster() {
		return assetMaster;
	}

	public void setAssetMaster(int assetMaster) {
		this.assetMaster = assetMaster;
	}


}

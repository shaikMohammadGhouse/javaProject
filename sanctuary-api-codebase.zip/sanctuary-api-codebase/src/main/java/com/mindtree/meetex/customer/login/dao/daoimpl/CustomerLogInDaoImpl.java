package com.mindtree.meetex.customer.login.dao.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.mindtree.meetex.customer.login.dao.CustomerLogInDao;
import com.mindtree.meetex.entity.Customer;

@Repository
public class CustomerLogInDaoImpl implements CustomerLogInDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory=sf;
	}
	
	public Session getSession(){
		return this.sessionFactory.openSession();
	}
	
	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomers(){
		List<Customer> customerList=getSession().createQuery("from Customer").list();
		return customerList;
	}

	
}

package com.mindtree.meetex.customer.search.service;

public interface CustomerSearchService {

}

package com.mindtree.meetex.customer.signup.service.serviceimpl;

import com.mindtree.meetex.customer.signup.service.CustomerSignUpService;

public class CustomerSignUpServiceImpl implements CustomerSignUpService {

}

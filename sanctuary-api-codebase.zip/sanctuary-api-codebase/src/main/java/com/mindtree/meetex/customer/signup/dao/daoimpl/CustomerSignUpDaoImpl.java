package com.mindtree.meetex.customer.signup.dao.daoimpl;

import com.mindtree.meetex.customer.signup.dao.CustomerSignUpDao;

public class CustomerSignUpDaoImpl implements CustomerSignUpDao {

}

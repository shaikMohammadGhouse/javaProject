package com.mindtree.meetex.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingdetail")
public class BookingDetail {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="bookingdetail_Id")
    private int bookingDetailId;

	@Column(name="booking_id")
	private int booking;
	
	@Column(name="quantity")
	private  int quantity;
	
	@Column(name="is_needed")
	private String isNeeded;
	
	@Column(name="asset_amenity_id")
	private int assetAmenity;

	public BookingDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingDetail(int bookingDetailId, int booking, int quantity, String isNeeded,
			int assetAmenity) {
		super();
		this.bookingDetailId = bookingDetailId;
		this.booking = booking;
		this.quantity = quantity;
		this.isNeeded = isNeeded;
		this.assetAmenity = assetAmenity;
	}

	public int getBookingDetailId() {
		return bookingDetailId;
	}

	public void setBookingDetailId(int bookingDetailId) {
		this.bookingDetailId = bookingDetailId;
	}

	public int getBooking() {
		return booking;
	}

	public void setBooking(int booking) {
		this.booking = booking;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getIsNeeded() {
		return isNeeded;
	}

	public void setIsNeeded(String isNeeded) {
		this.isNeeded = isNeeded;
	}

	public int getAssetAmenity() {
		return assetAmenity;
	}

	public void setAssetAmenity(int assetAmenity) {
		this.assetAmenity = assetAmenity;
	}
	
	

}

package com.mindtree.meetex.itadmin.addasset.service;

import com.mindtree.meetex.entity.HotelAmenities;
import com.mindtree.meetex.itadmin.addasset.dto.HotelAmenitiesDto;

public interface HotelAmenitiesService {

	void addAssetAmenity(HotelAmenitiesDto hotelAmenitiesDto);

}

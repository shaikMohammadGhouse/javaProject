package com.mindtree.meetex.itadmin.assetmanagement.dao.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.meetex.entity.AmenityMasterData;
import com.mindtree.meetex.itadmin.assetmanagement.dao.AmenityMasterDao;

@Repository
public class AmenityMasterDaoImpl implements AmenityMasterDao {
@Autowired
	private SessionFactory sessionFactory;
	

	public void addAmenities(AmenityMasterData amenity) {
		
		sessionFactory.getCurrentSession().save(amenity);
	}


	public List<AmenityMasterData> getALLAmenity() {
		List<AmenityMasterData> amenity=new ArrayList<AmenityMasterData>();
		amenity=sessionFactory.getCurrentSession().createQuery("from amenitymasterdata").list();
		return amenity;
		
	}

	public AmenityMasterData getAmenity(int amenityId) {
		
		return this.sessionFactory.getCurrentSession().get(AmenityMasterData.class, amenityId);
	}

	

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}

package com.mindtree.meetex.itadmin.addasset.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.meetex.entity.HotelMaster;
import com.mindtree.meetex.itadmin.addasset.dao.HotelDao;
import com.mindtree.meetex.itadmin.addasset.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService{

	@Autowired
	private HotelDao hotelDao;
	
	@Transactional
	public List<HotelMaster> getHotel(){
		return hotelDao.getHotel();
	}
}

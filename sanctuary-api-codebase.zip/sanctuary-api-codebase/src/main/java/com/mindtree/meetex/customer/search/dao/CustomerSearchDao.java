package com.mindtree.meetex.customer.search.dao;

public interface CustomerSearchDao {

}

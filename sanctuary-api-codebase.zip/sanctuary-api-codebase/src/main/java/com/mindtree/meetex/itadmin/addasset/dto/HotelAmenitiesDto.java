package com.mindtree.meetex.itadmin.addasset.dto;

public class HotelAmenitiesDto {

private String hotelName;
private String  hasAccomodation;
private String   multiLinguaStaff;
private String   suppLanguages;
private String   siteSecurity;
private String   tennis;
private String   waterSports;
private String   steamRoom;
private String   spa;
private String   snooker;
private String   solarium;
private String   winterSports;
private String   shooting;
private String   sauna;
private String   fishing;
private String   golf;
private String   croquet;
private String   bowls;
private String   badminton;
private String   gym;
private String   healthClub;
private String   outdoorSwimmingPool;
private String   jacuzzi;
private String   indoorSwimmingPool;
private String   horseRiding;
private String   archery;
private String   coachParking;
private String   freeOffSiteParking;
private String   freeOnSiteParking;
private String   offSiteParkingWithFee;
private String   unitOfMeasureOffSiteParking;
private String   unitOfMeasureOffSiteParkingPrice;
private String   onSiteParkingWithFee;
private String   unitOfMeasureOnSiteParking;
private String   unitOfMeasureOnSiteParkingPrice;
private String   publicTransport;
private String    limuousineService;
private String    shuttleBus;
private String    taxiService;
private String    tailor;
private String     terrace;
private String     restaurant;
private String     medicalFacility;
private String     luggageStorage;
private String     laundryService;
private String   businessCentre;
private String   cloakroomService;
private String   bedRooms;
private String   rampAccess;
private String   bar;
private String   ballRoom;
private String   concierge;
private String   disabledFacilities;
private String   heating;
private String   helipad;
private String   garden;
private String   freeWifi;
private String    elevator;
private String   frontDesk;
private String   shoppingArea;
private String   closeToNature;
private String   countrySide;
private String   inTheAirport;
private String   inTheCentre;
private String   nearAirport;
private String    nearAttractions;
private String   nearHarbor;
private String    nearMotorway;
private String    nearRailwayStation;
private String    nearTheCentre;
private String   nearByWater;
private String      suburbs;
private String   oneTeaBreak;
private String       oneTeaBreakService;
private String       twoTeaBreak;
private String       twoTeaBreakService;
private String       threeTeaBreak;
private String       threeTeaBreakService;
private String       unlimitedTea;
private String       unlimitedTeaService;
private String       alcoholicBeverages;
private String       alcoholicBeveragesService;
private String  coldBeverages;
private String       coldBeveragesService;
private String       hotBeverages;
private String       hotBeveragesService;
private String   stillWater;
private String   stillWaterService;
private String   twoBreakfast;
private String    twoBreakfastService;
private String    fullBreakfast;
private String    lunchBuffet;
private String   lunchBuffetService;
private String    lunchAlaCarte;
private String    lunchAlaCarteService;
private String   twoCourseMenu;
private String   twoCourseMenuService;
private String   buffetLunch;
private String   buffetLunchService;
private String   twoLunchAlaCarte;
private String   twoLunchAlaCarteService;
private String   twoLunchBuffet;
private String   twoLunchBuffetService;
private String   threeCourseLunch;
private String   threeCourseLunchService;
private String   supper;
private String   supperService;
private String   threeCourseDinner;
private String   threeCourseDinnerService;
private String   snacks;
private String   freshFruits;
public String getHasAccomodation() {
	return hasAccomodation;
}
public void setHasAccomodation(String hasAccomodation) {
	this.hasAccomodation = hasAccomodation;
}
public String getMultiLinguaStaff() {
	return multiLinguaStaff;
}
public void setMultiLinguaStaff(String multiLinguaStaff) {
	this.multiLinguaStaff = multiLinguaStaff;
}
public String getSuppLanguages() {
	return suppLanguages;
}
public void setSuppLanguages(String suppLanguages) {
	this.suppLanguages = suppLanguages;
}
public String getSiteSecurity() {
	return siteSecurity;
}
public void setSiteSecurity(String siteSecurity) {
	this.siteSecurity = siteSecurity;
}
public String getTennis() {
	return tennis;
}
public void setTennis(String tennis) {
	this.tennis = tennis;
}
public String getWaterSports() {
	return waterSports;
}
public void setWaterSports(String waterSports) {
	this.waterSports = waterSports;
}
public String getSteamRoom() {
	return steamRoom;
}
public void setSteamRoom(String steamRoom) {
	this.steamRoom = steamRoom;
}
public String getSpa() {
	return spa;
}
public void setSpa(String spa) {
	this.spa = spa;
}
public String getSnooker() {
	return snooker;
}
public void setSnooker(String snooker) {
	this.snooker = snooker;
}
public String getSolarium() {
	return solarium;
}
public void setSolarium(String solarium) {
	this.solarium = solarium;
}
public String getWinterSports() {
	return winterSports;
}
public void setWinterSports(String winterSports) {
	this.winterSports = winterSports;
}
public String getShooting() {
	return shooting;
}
public void setShooting(String shooting) {
	this.shooting = shooting;
}
public String getSauna() {
	return sauna;
}
public void setSauna(String sauna) {
	this.sauna = sauna;
}
public String getFishing() {
	return fishing;
}
public void setFishing(String fishing) {
	this.fishing = fishing;
}
public String getGolf() {
	return golf;
}
public void setGolf(String golf) {
	this.golf = golf;
}
public String getCroquet() {
	return croquet;
}
public void setCroquet(String croquet) {
	this.croquet = croquet;
}
public String getBowls() {
	return bowls;
}
public void setBowls(String bowls) {
	this.bowls = bowls;
}
public String getBadminton() {
	return badminton;
}
public void setBadminton(String badminton) {
	this.badminton = badminton;
}
public String getGym() {
	return gym;
}
public void setGym(String gym) {
	this.gym = gym;
}
public String getHealthClub() {
	return healthClub;
}
public void setHealthClub(String healthClub) {
	this.healthClub = healthClub;
}
public String getOutdoorSwimmingPool() {
	return outdoorSwimmingPool;
}
public void setOutdoorSwimmingPool(String outdoorSwimmingPool) {
	this.outdoorSwimmingPool = outdoorSwimmingPool;
}
public String getJacuzzi() {
	return jacuzzi;
}
public void setJacuzzi(String jacuzzi) {
	this.jacuzzi = jacuzzi;
}
public String getIndoorSwimmingPool() {
	return indoorSwimmingPool;
}
public void setIndoorSwimmingPool(String indoorSwimmingPool) {
	this.indoorSwimmingPool = indoorSwimmingPool;
}
public String getHorseRiding() {
	return horseRiding;
}
public void setHorseRiding(String horseRiding) {
	this.horseRiding = horseRiding;
}
public String getArchery() {
	return archery;
}
public void setArchery(String archery) {
	this.archery = archery;
}
public String getCoachParking() {
	return coachParking;
}
public void setCoachParking(String coachParking) {
	this.coachParking = coachParking;
}
public String getFreeOffSiteParking() {
	return freeOffSiteParking;
}
public void setFreeOffSiteParking(String freeOffSiteParking) {
	this.freeOffSiteParking = freeOffSiteParking;
}
public String getFreeOnSiteParking() {
	return freeOnSiteParking;
}
public void setFreeOnSiteParking(String freeOnSiteParking) {
	this.freeOnSiteParking = freeOnSiteParking;
}
public String getOffSiteParkingWithFee() {
	return offSiteParkingWithFee;
}
public void setOffSiteParkingWithFee(String offSiteParkingWithFee) {
	this.offSiteParkingWithFee = offSiteParkingWithFee;
}
public String getUnitOfMeasureOffSiteParking() {
	return unitOfMeasureOffSiteParking;
}
public void setUnitOfMeasureOffSiteParking(String unitOfMeasureOffSiteParking) {
	this.unitOfMeasureOffSiteParking = unitOfMeasureOffSiteParking;
}
public String getUnitOfMeasureOffSiteParkingPrice() {
	return unitOfMeasureOffSiteParkingPrice;
}
public void setUnitOfMeasureOffSiteParkingPrice(String unitOfMeasureOffSiteParkingPrice) {
	this.unitOfMeasureOffSiteParkingPrice = unitOfMeasureOffSiteParkingPrice;
}
public String getOnSiteParkingWithFee() {
	return onSiteParkingWithFee;
}
public void setOnSiteParkingWithFee(String onSiteParkingWithFee) {
	this.onSiteParkingWithFee = onSiteParkingWithFee;
}
public String getUnitOfMeasureOnSiteParking() {
	return unitOfMeasureOnSiteParking;
}
public void setUnitOfMeasureOnSiteParking(String unitOfMeasureOnSiteParking) {
	this.unitOfMeasureOnSiteParking = unitOfMeasureOnSiteParking;
}
public String getUnitOfMeasureOnSiteParkingPrice() {
	return unitOfMeasureOnSiteParkingPrice;
}
public void setUnitOfMeasureOnSiteParkingPrice(String unitOfMeasureOnSiteParkingPrice) {
	this.unitOfMeasureOnSiteParkingPrice = unitOfMeasureOnSiteParkingPrice;
}
public String getPublicTransport() {
	return publicTransport;
}
public void setPublicTransport(String publicTransport) {
	this.publicTransport = publicTransport;
}
public String getLimuousineService() {
	return limuousineService;
}
public void setLimuousineService(String limuousineService) {
	this.limuousineService = limuousineService;
}
public String getShuttleBus() {
	return shuttleBus;
}
public void setShuttleBus(String shuttleBus) {
	this.shuttleBus = shuttleBus;
}
public String getTaxiService() {
	return taxiService;
}
public void setTaxiService(String taxiService) {
	this.taxiService = taxiService;
}
public String getTailor() {
	return tailor;
}
public void setTailor(String tailor) {
	this.tailor = tailor;
}
public String getTerrace() {
	return terrace;
}
public void setTerrace(String terrace) {
	this.terrace = terrace;
}
public String getRestaurant() {
	return restaurant;
}
public void setRestaurant(String restaurant) {
	this.restaurant = restaurant;
}
public String getMedicalFacility() {
	return medicalFacility;
}
public void setMedicalFacility(String medicalFacility) {
	this.medicalFacility = medicalFacility;
}
public String getLuggageStorage() {
	return luggageStorage;
}
public void setLuggageStorage(String luggageStorage) {
	this.luggageStorage = luggageStorage;
}
public String getLaundryService() {
	return laundryService;
}
public void setLaundryService(String laundryService) {
	this.laundryService = laundryService;
}
public String getBusinessCentre() {
	return businessCentre;
}
public void setBusinessCentre(String businessCentre) {
	this.businessCentre = businessCentre;
}
public String getCloakroomService() {
	return cloakroomService;
}
public void setCloakroomService(String cloakroomService) {
	this.cloakroomService = cloakroomService;
}
public String getBedRooms() {
	return bedRooms;
}
public void setBedRooms(String bedRooms) {
	this.bedRooms = bedRooms;
}
public String getRampAccess() {
	return rampAccess;
}
public void setRampAccess(String rampAccess) {
	this.rampAccess = rampAccess;
}
public String getBar() {
	return bar;
}
public void setBar(String bar) {
	this.bar = bar;
}
public String getBallRoom() {
	return ballRoom;
}
public void setBallRoom(String ballRoom) {
	this.ballRoom = ballRoom;
}
public String getConcierge() {
	return concierge;
}
public void setConcierge(String concierge) {
	this.concierge = concierge;
}
public String getDisabledFacilities() {
	return disabledFacilities;
}
public void setDisabledFacilities(String disabledFacilities) {
	this.disabledFacilities = disabledFacilities;
}
public String getHeating() {
	return heating;
}
public void setHeating(String heating) {
	this.heating = heating;
}
public String getHelipad() {
	return helipad;
}
public void setHelipad(String helipad) {
	this.helipad = helipad;
}
public String getGarden() {
	return garden;
}
public void setGarden(String garden) {
	this.garden = garden;
}
public String getFreeWifi() {
	return freeWifi;
}
public void setFreeWifi(String freeWifi) {
	this.freeWifi = freeWifi;
}
public String getElevator() {
	return elevator;
}
public void setElevator(String elevator) {
	this.elevator = elevator;
}
public String getFrontDesk() {
	return frontDesk;
}
public void setFrontDesk(String frontDesk) {
	this.frontDesk = frontDesk;
}
public String getShoppingArea() {
	return shoppingArea;
}
public void setShoppingArea(String shoppingArea) {
	this.shoppingArea = shoppingArea;
}
public String getCloseToNature() {
	return closeToNature;
}
public void setCloseToNature(String closeToNature) {
	this.closeToNature = closeToNature;
}
public String getCountrySide() {
	return countrySide;
}
public void setCountrySide(String countrySide) {
	this.countrySide = countrySide;
}
public String getInTheAirport() {
	return inTheAirport;
}
public void setInTheAirport(String inTheAirport) {
	this.inTheAirport = inTheAirport;
}
public String getInTheCentre() {
	return inTheCentre;
}
public void setInTheCentre(String inTheCentre) {
	this.inTheCentre = inTheCentre;
}
public String getNearAirport() {
	return nearAirport;
}
public void setNearAirport(String nearAirport) {
	this.nearAirport = nearAirport;
}
public String getNearAttractions() {
	return nearAttractions;
}
public void setNearAttractions(String nearAttractions) {
	this.nearAttractions = nearAttractions;
}
public String getNearHarbor() {
	return nearHarbor;
}
public void setNearHarbor(String nearHarbor) {
	this.nearHarbor = nearHarbor;
}
public String getNearMotorway() {
	return nearMotorway;
}
public void setNearMotorway(String nearMotorway) {
	this.nearMotorway = nearMotorway;
}
public String getNearRailwayStation() {
	return nearRailwayStation;
}
public void setNearRailwayStation(String nearRailwayStation) {
	this.nearRailwayStation = nearRailwayStation;
}
public String getNearTheCentre() {
	return nearTheCentre;
}
public void setNearTheCentre(String nearTheCentre) {
	this.nearTheCentre = nearTheCentre;
}
public String getNearByWater() {
	return nearByWater;
}
public void setNearByWater(String nearByWater) {
	this.nearByWater = nearByWater;
}
public String getSuburbs() {
	return suburbs;
}
public void setSuburbs(String suburbs) {
	this.suburbs = suburbs;
}
public String getOneTeaBreak() {
	return oneTeaBreak;
}
public void setOneTeaBreak(String oneTeaBreak) {
	this.oneTeaBreak = oneTeaBreak;
}
public String getOneTeaBreakService() {
	return oneTeaBreakService;
}
public void setOneTeaBreakService(String oneTeaBreakService) {
	this.oneTeaBreakService = oneTeaBreakService;
}
public String getTwoTeaBreak() {
	return twoTeaBreak;
}
public void setTwoTeaBreak(String twoTeaBreak) {
	this.twoTeaBreak = twoTeaBreak;
}
public String getTwoTeaBreakService() {
	return twoTeaBreakService;
}
public void setTwoTeaBreakService(String twoTeaBreakService) {
	this.twoTeaBreakService = twoTeaBreakService;
}
public String getThreeTeaBreak() {
	return threeTeaBreak;
}
public void setThreeTeaBreak(String threeTeaBreak) {
	this.threeTeaBreak = threeTeaBreak;
}
public String getThreeTeaBreakService() {
	return threeTeaBreakService;
}
public void setThreeTeaBreakService(String threeTeaBreakService) {
	this.threeTeaBreakService = threeTeaBreakService;
}
public String getUnlimitedTea() {
	return unlimitedTea;
}
public void setUnlimitedTea(String unlimitedTea) {
	this.unlimitedTea = unlimitedTea;
}
public String getUnlimitedTeaService() {
	return unlimitedTeaService;
}
public void setUnlimitedTeaService(String unlimitedTeaService) {
	this.unlimitedTeaService = unlimitedTeaService;
}
public String getAlcoholicBeverages() {
	return alcoholicBeverages;
}
public void setAlcoholicBeverages(String alcoholicBeverages) {
	this.alcoholicBeverages = alcoholicBeverages;
}
public String getAlcoholicBeveragesService() {
	return alcoholicBeveragesService;
}
public void setAlcoholicBeveragesService(String alcoholicBeveragesService) {
	this.alcoholicBeveragesService = alcoholicBeveragesService;
}
public String getColdBeverages() {
	return coldBeverages;
}
public void setColdBeverages(String coldBeverages) {
	this.coldBeverages = coldBeverages;
}
public String getColdBeveragesService() {
	return coldBeveragesService;
}
public void setColdBeveragesService(String coldBeveragesService) {
	this.coldBeveragesService = coldBeveragesService;
}
public String getHotBeverages() {
	return hotBeverages;
}
public void setHotBeverages(String hotBeverages) {
	this.hotBeverages = hotBeverages;
}
public String getHotBeveragesService() {
	return hotBeveragesService;
}
public void setHotBeveragesService(String hotBeveragesService) {
	this.hotBeveragesService = hotBeveragesService;
}
public String getStillWater() {
	return stillWater;
}
public void setStillWater(String stillWater) {
	this.stillWater = stillWater;
}
public String getStillWaterService() {
	return stillWaterService;
}
public void setStillWaterService(String stillWaterService) {
	this.stillWaterService = stillWaterService;
}
public String getTwoBreakfast() {
	return twoBreakfast;
}
public void setTwoBreakfast(String twoBreakfast) {
	this.twoBreakfast = twoBreakfast;
}
public String getTwoBreakfastService() {
	return twoBreakfastService;
}
public void setTwoBreakfastService(String twoBreakfastService) {
	this.twoBreakfastService = twoBreakfastService;
}
public String getFullBreakfast() {
	return fullBreakfast;
}
public void setFullBreakfast(String fullBreakfast) {
	this.fullBreakfast = fullBreakfast;
}
public String getLunchBuffet() {
	return lunchBuffet;
}
public void setLunchBuffet(String lunchBuffet) {
	this.lunchBuffet = lunchBuffet;
}
public String getLunchBuffetService() {
	return lunchBuffetService;
}
public void setLunchBuffetService(String lunchBuffetService) {
	this.lunchBuffetService = lunchBuffetService;
}
public String getLunchAlaCarte() {
	return lunchAlaCarte;
}
public void setLunchAlaCarte(String lunchAlaCarte) {
	this.lunchAlaCarte = lunchAlaCarte;
}
public String getLunchAlaCarteService() {
	return lunchAlaCarteService;
}
public void setLunchAlaCarteService(String lunchAlaCarteService) {
	this.lunchAlaCarteService = lunchAlaCarteService;
}
public String getTwoCourseMenu() {
	return twoCourseMenu;
}
public void setTwoCourseMenu(String twoCourseMenu) {
	this.twoCourseMenu = twoCourseMenu;
}
public String getTwoCourseMenuService() {
	return twoCourseMenuService;
}
public void setTwoCourseMenuService(String twoCourseMenuService) {
	this.twoCourseMenuService = twoCourseMenuService;
}
public String getBuffetLunch() {
	return buffetLunch;
}
public void setBuffetLunch(String buffetLunch) {
	this.buffetLunch = buffetLunch;
}
public String getBuffetLunchService() {
	return buffetLunchService;
}
public void setBuffetLunchService(String buffetLunchService) {
	this.buffetLunchService = buffetLunchService;
}
public String getTwoLunchAlaCarte() {
	return twoLunchAlaCarte;
}
public void setTwoLunchAlaCarte(String twoLunchAlaCarte) {
	this.twoLunchAlaCarte = twoLunchAlaCarte;
}
public String getTwoLunchAlaCarteService() {
	return twoLunchAlaCarteService;
}
public void setTwoLunchAlaCarteService(String twoLunchAlaCarteService) {
	this.twoLunchAlaCarteService = twoLunchAlaCarteService;
}
public String getTwoLunchBuffet() {
	return twoLunchBuffet;
}
public void setTwoLunchBuffet(String twoLunchBuffet) {
	this.twoLunchBuffet = twoLunchBuffet;
}
public String getTwoLunchBuffetService() {
	return twoLunchBuffetService;
}
public void setTwoLunchBuffetService(String twoLunchBuffetService) {
	this.twoLunchBuffetService = twoLunchBuffetService;
}
public String getThreeCourseLunch() {
	return threeCourseLunch;
}
public void setThreeCourseLunch(String threeCourseLunch) {
	this.threeCourseLunch = threeCourseLunch;
}
public String getThreeCourseLunchService() {
	return threeCourseLunchService;
}
public void setThreeCourseLunchService(String threeCourseLunchService) {
	this.threeCourseLunchService = threeCourseLunchService;
}
public String getSupper() {
	return supper;
}
public void setSupper(String supper) {
	this.supper = supper;
}
public String getSupperService() {
	return supperService;
}
public void setSupperService(String supperService) {
	this.supperService = supperService;
}
public String getThreeCourseDinner() {
	return threeCourseDinner;
}
public void setThreeCourseDinner(String threeCourseDinner) {
	this.threeCourseDinner = threeCourseDinner;
}
public String getThreeCourseDinnerService() {
	return threeCourseDinnerService;
}
public void setThreeCourseDinnerService(String threeCourseDinnerService) {
	this.threeCourseDinnerService = threeCourseDinnerService;
}
public String getSnacks() {
	return snacks;
}
public void setSnacks(String snacks) {
	this.snacks = snacks;
}
public String getFreshFruits() {
	return freshFruits;
}
public void setFreshFruits(String freshFruits) {
	this.freshFruits = freshFruits;
}

@Override
public String toString() {
	return "HotelAmenitiesDto [hotelName=" + hotelName + ", hasAccomodation=" + hasAccomodation + ", multiLinguaStaff="
			+ multiLinguaStaff + ", suppLanguages=" + suppLanguages + ", siteSecurity=" + siteSecurity + ", tennis="
			+ tennis + ", waterSports=" + waterSports + ", steamRoom=" + steamRoom + ", spa=" + spa + ", snooker="
			+ snooker + ", solarium=" + solarium + ", winterSports=" + winterSports + ", shooting=" + shooting
			+ ", sauna=" + sauna + ", fishing=" + fishing + ", golf=" + golf + ", croquet=" + croquet + ", bowls="
			+ bowls + ", badminton=" + badminton + ", gym=" + gym + ", healthClub=" + healthClub
			+ ", outdoorSwimmingPool=" + outdoorSwimmingPool + ", jacuzzi=" + jacuzzi + ", indoorSwimmingPool="
			+ indoorSwimmingPool + ", horseRiding=" + horseRiding + ", archery=" + archery + ", coachParking="
			+ coachParking + ", freeOffSiteParking=" + freeOffSiteParking + ", freeOnSiteParking=" + freeOnSiteParking
			+ ", offSiteParkingWithFee=" + offSiteParkingWithFee + ", unitOfMeasureOffSiteParking="
			+ unitOfMeasureOffSiteParking + ", unitOfMeasureOffSiteParkingPrice=" + unitOfMeasureOffSiteParkingPrice
			+ ", onSiteParkingWithFee=" + onSiteParkingWithFee + ", unitOfMeasureOnSiteParking="
			+ unitOfMeasureOnSiteParking + ", unitOfMeasureOnSiteParkingPrice=" + unitOfMeasureOnSiteParkingPrice
			+ ", publicTransport=" + publicTransport + ", limuousineService=" + limuousineService + ", shuttleBus="
			+ shuttleBus + ", taxiService=" + taxiService + ", tailor=" + tailor + ", terrace=" + terrace
			+ ", restaurant=" + restaurant + ", medicalFacility=" + medicalFacility + ", luggageStorage="
			+ luggageStorage + ", laundryService=" + laundryService + ", businessCentre=" + businessCentre
			+ ", cloakroomService=" + cloakroomService + ", bedRooms=" + bedRooms + ", rampAccess=" + rampAccess
			+ ", bar=" + bar + ", ballRoom=" + ballRoom + ", concierge=" + concierge + ", disabledFacilities="
			+ disabledFacilities + ", heating=" + heating + ", helipad=" + helipad + ", garden=" + garden
			+ ", freeWifi=" + freeWifi + ", elevator=" + elevator + ", frontDesk=" + frontDesk + ", shoppingArea="
			+ shoppingArea + ", closeToNature=" + closeToNature + ", countrySide=" + countrySide + ", inTheAirport="
			+ inTheAirport + ", inTheCentre=" + inTheCentre + ", nearAirport=" + nearAirport + ", nearAttractions="
			+ nearAttractions + ", nearHarbor=" + nearHarbor + ", nearMotorway=" + nearMotorway
			+ ", nearRailwayStation=" + nearRailwayStation + ", nearTheCentre=" + nearTheCentre + ", nearByWater="
			+ nearByWater + ", suburbs=" + suburbs + ", oneTeaBreak=" + oneTeaBreak + ", oneTeaBreakService="
			+ oneTeaBreakService + ", twoTeaBreak=" + twoTeaBreak + ", twoTeaBreakService=" + twoTeaBreakService
			+ ", threeTeaBreak=" + threeTeaBreak + ", threeTeaBreakService=" + threeTeaBreakService + ", unlimitedTea="
			+ unlimitedTea + ", unlimitedTeaService=" + unlimitedTeaService + ", alcoholicBeverages="
			+ alcoholicBeverages + ", alcoholicBeveragesService=" + alcoholicBeveragesService + ", coldBeverages="
			+ coldBeverages + ", coldBeveragesService=" + coldBeveragesService + ", hotBeverages=" + hotBeverages
			+ ", hotBeveragesService=" + hotBeveragesService + ", stillWater=" + stillWater + ", stillWaterService="
			+ stillWaterService + ", twoBreakfast=" + twoBreakfast + ", twoBreakfastService=" + twoBreakfastService
			+ ", fullBreakfast=" + fullBreakfast + ", lunchBuffet=" + lunchBuffet + ", lunchBuffetService="
			+ lunchBuffetService + ", lunchAlaCarte=" + lunchAlaCarte + ", lunchAlaCarteService=" + lunchAlaCarteService
			+ ", twoCourseMenu=" + twoCourseMenu + ", twoCourseMenuService=" + twoCourseMenuService + ", buffetLunch="
			+ buffetLunch + ", buffetLunchService=" + buffetLunchService + ", twoLunchAlaCarte=" + twoLunchAlaCarte
			+ ", twoLunchAlaCarteService=" + twoLunchAlaCarteService + ", twoLunchBuffet=" + twoLunchBuffet
			+ ", twoLunchBuffetService=" + twoLunchBuffetService + ", threeCourseLunch=" + threeCourseLunch
			+ ", threeCourseLunchService=" + threeCourseLunchService + ", supper=" + supper + ", supperService="
			+ supperService + ", threeCourseDinner=" + threeCourseDinner + ", threeCourseDinnerService="
			+ threeCourseDinnerService + ", snacks=" + snacks + ", freshFruits=" + freshFruits + "]";
}
public HotelAmenitiesDto(String hotelName, String hasAccomodation, String multiLinguaStaff, String suppLanguages,
		String siteSecurity, String tennis, String waterSports, String steamRoom, String spa, String snooker,
		String solarium, String winterSports, String shooting, String sauna, String fishing, String golf,
		String croquet, String bowls, String badminton, String gym, String healthClub, String outdoorSwimmingPool,
		String jacuzzi, String indoorSwimmingPool, String horseRiding, String archery, String coachParking,
		String freeOffSiteParking, String freeOnSiteParking, String offSiteParkingWithFee,
		String unitOfMeasureOffSiteParking, String unitOfMeasureOffSiteParkingPrice, String onSiteParkingWithFee,
		String unitOfMeasureOnSiteParking, String unitOfMeasureOnSiteParkingPrice, String publicTransport,
		String limuousineService, String shuttleBus, String taxiService, String tailor, String terrace,
		String restaurant, String medicalFacility, String luggageStorage, String laundryService, String businessCentre,
		String cloakroomService, String bedRooms, String rampAccess, String bar, String ballRoom, String concierge,
		String disabledFacilities, String heating, String helipad, String garden, String freeWifi, String elevator,
		String frontDesk, String shoppingArea, String closeToNature, String countrySide, String inTheAirport,
		String inTheCentre, String nearAirport, String nearAttractions, String nearHarbor, String nearMotorway,
		String nearRailwayStation, String nearTheCentre, String nearByWater, String suburbs, String oneTeaBreak,
		String oneTeaBreakService, String twoTeaBreak, String twoTeaBreakService, String threeTeaBreak,
		String threeTeaBreakService, String unlimitedTea, String unlimitedTeaService, String alcoholicBeverages,
		String alcoholicBeveragesService, String coldBeverages, String coldBeveragesService, String hotBeverages,
		String hotBeveragesService, String stillWater, String stillWaterService, String twoBreakfast,
		String twoBreakfastService, String fullBreakfast, String lunchBuffet, String lunchBuffetService,
		String lunchAlaCarte, String lunchAlaCarteService, String twoCourseMenu, String twoCourseMenuService,
		String buffetLunch, String buffetLunchService, String twoLunchAlaCarte, String twoLunchAlaCarteService,
		String twoLunchBuffet, String twoLunchBuffetService, String threeCourseLunch, String threeCourseLunchService,
		String supper, String supperService, String threeCourseDinner, String threeCourseDinnerService, String snacks,
		String freshFruits) {
	super();
	this.hotelName = hotelName;
	this.hasAccomodation = hasAccomodation;
	this.multiLinguaStaff = multiLinguaStaff;
	this.suppLanguages = suppLanguages;
	this.siteSecurity = siteSecurity;
	this.tennis = tennis;
	this.waterSports = waterSports;
	this.steamRoom = steamRoom;
	this.spa = spa;
	this.snooker = snooker;
	this.solarium = solarium;
	this.winterSports = winterSports;
	this.shooting = shooting;
	this.sauna = sauna;
	this.fishing = fishing;
	this.golf = golf;
	this.croquet = croquet;
	this.bowls = bowls;
	this.badminton = badminton;
	this.gym = gym;
	this.healthClub = healthClub;
	this.outdoorSwimmingPool = outdoorSwimmingPool;
	this.jacuzzi = jacuzzi;
	this.indoorSwimmingPool = indoorSwimmingPool;
	this.horseRiding = horseRiding;
	this.archery = archery;
	this.coachParking = coachParking;
	this.freeOffSiteParking = freeOffSiteParking;
	this.freeOnSiteParking = freeOnSiteParking;
	this.offSiteParkingWithFee = offSiteParkingWithFee;
	this.unitOfMeasureOffSiteParking = unitOfMeasureOffSiteParking;
	this.unitOfMeasureOffSiteParkingPrice = unitOfMeasureOffSiteParkingPrice;
	this.onSiteParkingWithFee = onSiteParkingWithFee;
	this.unitOfMeasureOnSiteParking = unitOfMeasureOnSiteParking;
	this.unitOfMeasureOnSiteParkingPrice = unitOfMeasureOnSiteParkingPrice;
	this.publicTransport = publicTransport;
	this.limuousineService = limuousineService;
	this.shuttleBus = shuttleBus;
	this.taxiService = taxiService;
	this.tailor = tailor;
	this.terrace = terrace;
	this.restaurant = restaurant;
	this.medicalFacility = medicalFacility;
	this.luggageStorage = luggageStorage;
	this.laundryService = laundryService;
	this.businessCentre = businessCentre;
	this.cloakroomService = cloakroomService;
	this.bedRooms = bedRooms;
	this.rampAccess = rampAccess;
	this.bar = bar;
	this.ballRoom = ballRoom;
	this.concierge = concierge;
	this.disabledFacilities = disabledFacilities;
	this.heating = heating;
	this.helipad = helipad;
	this.garden = garden;
	this.freeWifi = freeWifi;
	this.elevator = elevator;
	this.frontDesk = frontDesk;
	this.shoppingArea = shoppingArea;
	this.closeToNature = closeToNature;
	this.countrySide = countrySide;
	this.inTheAirport = inTheAirport;
	this.inTheCentre = inTheCentre;
	this.nearAirport = nearAirport;
	this.nearAttractions = nearAttractions;
	this.nearHarbor = nearHarbor;
	this.nearMotorway = nearMotorway;
	this.nearRailwayStation = nearRailwayStation;
	this.nearTheCentre = nearTheCentre;
	this.nearByWater = nearByWater;
	this.suburbs = suburbs;
	this.oneTeaBreak = oneTeaBreak;
	this.oneTeaBreakService = oneTeaBreakService;
	this.twoTeaBreak = twoTeaBreak;
	this.twoTeaBreakService = twoTeaBreakService;
	this.threeTeaBreak = threeTeaBreak;
	this.threeTeaBreakService = threeTeaBreakService;
	this.unlimitedTea = unlimitedTea;
	this.unlimitedTeaService = unlimitedTeaService;
	this.alcoholicBeverages = alcoholicBeverages;
	this.alcoholicBeveragesService = alcoholicBeveragesService;
	this.coldBeverages = coldBeverages;
	this.coldBeveragesService = coldBeveragesService;
	this.hotBeverages = hotBeverages;
	this.hotBeveragesService = hotBeveragesService;
	this.stillWater = stillWater;
	this.stillWaterService = stillWaterService;
	this.twoBreakfast = twoBreakfast;
	this.twoBreakfastService = twoBreakfastService;
	this.fullBreakfast = fullBreakfast;
	this.lunchBuffet = lunchBuffet;
	this.lunchBuffetService = lunchBuffetService;
	this.lunchAlaCarte = lunchAlaCarte;
	this.lunchAlaCarteService = lunchAlaCarteService;
	this.twoCourseMenu = twoCourseMenu;
	this.twoCourseMenuService = twoCourseMenuService;
	this.buffetLunch = buffetLunch;
	this.buffetLunchService = buffetLunchService;
	this.twoLunchAlaCarte = twoLunchAlaCarte;
	this.twoLunchAlaCarteService = twoLunchAlaCarteService;
	this.twoLunchBuffet = twoLunchBuffet;
	this.twoLunchBuffetService = twoLunchBuffetService;
	this.threeCourseLunch = threeCourseLunch;
	this.threeCourseLunchService = threeCourseLunchService;
	this.supper = supper;
	this.supperService = supperService;
	this.threeCourseDinner = threeCourseDinner;
	this.threeCourseDinnerService = threeCourseDinnerService;
	this.snacks = snacks;
	this.freshFruits = freshFruits;
}
public String getHotelName() {
	return hotelName;
}
public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}
public HotelAmenitiesDto() {
	super();
	// TODO Auto-generated constructor stub
}
public HotelAmenitiesDto(String hasAccomodation, String multiLinguaStaff, String suppLanguages, String siteSecurity,
		String tennis, String waterSports, String steamRoom, String spa, String snooker, String solarium,
		String winterSports, String shooting, String sauna, String fishing, String golf, String croquet, String bowls,
		String badminton, String gym, String healthClub, String outdoorSwimmingPool, String jacuzzi,
		String indoorSwimmingPool, String horseRiding, String archery, String coachParking, String freeOffSiteParking,
		String freeOnSiteParking, String offSiteParkingWithFee, String unitOfMeasureOffSiteParking,
		String unitOfMeasureOffSiteParkingPrice, String onSiteParkingWithFee, String unitOfMeasureOnSiteParking,
		String unitOfMeasureOnSiteParkingPrice, String publicTransport, String limuousineService, String shuttleBus,
		String taxiService, String tailor, String terrace, String restaurant, String medicalFacility,
		String luggageStorage, String laundryService, String businessCentre, String cloakroomService, String bedRooms,
		String rampAccess, String bar, String ballRoom, String concierge, String disabledFacilities, String heating,
		String helipad, String garden, String freeWifi, String elevator, String frontDesk, String shoppingArea,
		String closeToNature, String countrySide, String inTheAirport, String inTheCentre, String nearAirport,
		String nearAttractions, String nearHarbor, String nearMotorway, String nearRailwayStation, String nearTheCentre,
		String nearByWater, String suburbs, String oneTeaBreak, String oneTeaBreakService, String twoTeaBreak,
		String twoTeaBreakService, String threeTeaBreak, String threeTeaBreakService, String unlimitedTea,
		String unlimitedTeaService, String alcoholicBeverages, String alcoholicBeveragesService, String coldBeverages,
		String coldBeveragesService, String hotBeverages, String hotBeveragesService, String stillWater,
		String stillWaterService, String twoBreakfast, String twoBreakfastService, String fullBreakfast,
		String lunchBuffet, String lunchBuffetService, String lunchAlaCarte, String lunchAlaCarteService,
		String twoCourseMenu, String twoCourseMenuService, String buffetLunch, String buffetLunchService,
		String twoLunchAlaCarte, String twoLunchAlaCarteService, String twoLunchBuffet, String twoLunchBuffetService,
		String threeCourseLunch, String threeCourseLunchService, String supper, String supperService,
		String threeCourseDinner, String threeCourseDinnerService, String snacks, String freshFruits) {
	super();
	this.hasAccomodation = hasAccomodation;
	this.multiLinguaStaff = multiLinguaStaff;
	this.suppLanguages = suppLanguages;
	this.siteSecurity = siteSecurity;
	this.tennis = tennis;
	this.waterSports = waterSports;
	this.steamRoom = steamRoom;
	this.spa = spa;
	this.snooker = snooker;
	this.solarium = solarium;
	this.winterSports = winterSports;
	this.shooting = shooting;
	this.sauna = sauna;
	this.fishing = fishing;
	this.golf = golf;
	this.croquet = croquet;
	this.bowls = bowls;
	this.badminton = badminton;
	this.gym = gym;
	this.healthClub = healthClub;
	this.outdoorSwimmingPool = outdoorSwimmingPool;
	this.jacuzzi = jacuzzi;
	this.indoorSwimmingPool = indoorSwimmingPool;
	this.horseRiding = horseRiding;
	this.archery = archery;
	this.coachParking = coachParking;
	this.freeOffSiteParking = freeOffSiteParking;
	this.freeOnSiteParking = freeOnSiteParking;
	this.offSiteParkingWithFee = offSiteParkingWithFee;
	this.unitOfMeasureOffSiteParking = unitOfMeasureOffSiteParking;
	this.unitOfMeasureOffSiteParkingPrice = unitOfMeasureOffSiteParkingPrice;
	this.onSiteParkingWithFee = onSiteParkingWithFee;
	this.unitOfMeasureOnSiteParking = unitOfMeasureOnSiteParking;
	this.unitOfMeasureOnSiteParkingPrice = unitOfMeasureOnSiteParkingPrice;
	this.publicTransport = publicTransport;
	this.limuousineService = limuousineService;
	this.shuttleBus = shuttleBus;
	this.taxiService = taxiService;
	this.tailor = tailor;
	this.terrace = terrace;
	this.restaurant = restaurant;
	this.medicalFacility = medicalFacility;
	this.luggageStorage = luggageStorage;
	this.laundryService = laundryService;
	this.businessCentre = businessCentre;
	this.cloakroomService = cloakroomService;
	this.bedRooms = bedRooms;
	this.rampAccess = rampAccess;
	this.bar = bar;
	this.ballRoom = ballRoom;
	this.concierge = concierge;
	this.disabledFacilities = disabledFacilities;
	this.heating = heating;
	this.helipad = helipad;
	this.garden = garden;
	this.freeWifi = freeWifi;
	this.elevator = elevator;
	this.frontDesk = frontDesk;
	this.shoppingArea = shoppingArea;
	this.closeToNature = closeToNature;
	this.countrySide = countrySide;
	this.inTheAirport = inTheAirport;
	this.inTheCentre = inTheCentre;
	this.nearAirport = nearAirport;
	this.nearAttractions = nearAttractions;
	this.nearHarbor = nearHarbor;
	this.nearMotorway = nearMotorway;
	this.nearRailwayStation = nearRailwayStation;
	this.nearTheCentre = nearTheCentre;
	this.nearByWater = nearByWater;
	this.suburbs = suburbs;
	this.oneTeaBreak = oneTeaBreak;
	this.oneTeaBreakService = oneTeaBreakService;
	this.twoTeaBreak = twoTeaBreak;
	this.twoTeaBreakService = twoTeaBreakService;
	this.threeTeaBreak = threeTeaBreak;
	this.threeTeaBreakService = threeTeaBreakService;
	this.unlimitedTea = unlimitedTea;
	this.unlimitedTeaService = unlimitedTeaService;
	this.alcoholicBeverages = alcoholicBeverages;
	this.alcoholicBeveragesService = alcoholicBeveragesService;
	this.coldBeverages = coldBeverages;
	this.coldBeveragesService = coldBeveragesService;
	this.hotBeverages = hotBeverages;
	this.hotBeveragesService = hotBeveragesService;
	this.stillWater = stillWater;
	this.stillWaterService = stillWaterService;
	this.twoBreakfast = twoBreakfast;
	this.twoBreakfastService = twoBreakfastService;
	this.fullBreakfast = fullBreakfast;
	this.lunchBuffet = lunchBuffet;
	this.lunchBuffetService = lunchBuffetService;
	this.lunchAlaCarte = lunchAlaCarte;
	this.lunchAlaCarteService = lunchAlaCarteService;
	this.twoCourseMenu = twoCourseMenu;
	this.twoCourseMenuService = twoCourseMenuService;
	this.buffetLunch = buffetLunch;
	this.buffetLunchService = buffetLunchService;
	this.twoLunchAlaCarte = twoLunchAlaCarte;
	this.twoLunchAlaCarteService = twoLunchAlaCarteService;
	this.twoLunchBuffet = twoLunchBuffet;
	this.twoLunchBuffetService = twoLunchBuffetService;
	this.threeCourseLunch = threeCourseLunch;
	this.threeCourseLunchService = threeCourseLunchService;
	this.supper = supper;
	this.supperService = supperService;
	this.threeCourseDinner = threeCourseDinner;
	this.threeCourseDinnerService = threeCourseDinnerService;
	this.snacks = snacks;
	this.freshFruits = freshFruits;
}



 
}

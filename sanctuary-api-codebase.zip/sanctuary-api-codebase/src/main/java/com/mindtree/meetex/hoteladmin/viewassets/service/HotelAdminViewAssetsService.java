package com.mindtree.meetex.hoteladmin.viewassets.service;

public interface HotelAdminViewAssetsService {

}

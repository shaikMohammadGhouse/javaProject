package com.mindtree.meetex.itadmin.addasset.service;

import java.util.List;

import com.mindtree.meetex.entity.HotelMaster;

public interface HotelService {

	public List<HotelMaster> getHotel();

}

package com.mindtree.meetex.customer.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.meetex.customer.login.service.CustomerLoginService;
import com.mindtree.meetex.customer.login.service.serviceimpl.CustomerLoginServiceImpl;
import com.mindtree.meetex.entity.Customer;

@RestController
//@RequestMapping(value="/customer")
public class CustomerController {
	
	@Autowired
	CustomerLoginService customerLoginService;

	@RequestMapping(value="/getallcustomers", method=RequestMethod.GET)
	public List<Customer> getAllCustomers(){
		return this.customerLoginService.getAllCustomers();
	}

}

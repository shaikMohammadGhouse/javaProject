package com.mindtree.meetex.itadmin.addasset.dao;

import java.util.List;

import com.mindtree.meetex.entity.LocationMaster;

public interface LocationDao {

	public List<LocationMaster> getLocation();

}

package com.mindtree.meetex.itadmin.addasset.dao.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.meetex.entity.AssetMaster;
import com.mindtree.meetex.entity.HotelAmenities;
import com.mindtree.meetex.itadmin.addasset.dao.HotelAmenitiesDao;
import com.mindtree.meetex.itadmin.addasset.dto.HotelAmenitiesDto;

public class HotelAmenitiesDaoImpl implements HotelAmenitiesDao{
	
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}
	
	
	public void addHotelAmenities(HotelAmenitiesDto hotelAmenitiesDto) {
		//getSession().persist(hotelAmenities);
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Accomodation','"+hotelAmenitiesDto.getHasAccomodation()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Multilingual Staff','"+hotelAmenitiesDto.getMultiLinguaStaff()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'On Site Security','"+hotelAmenitiesDto.getSiteSecurity()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Tennis','"+hotelAmenitiesDto.getTennis()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Water Sports','"+hotelAmenitiesDto.getWaterSports()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Steam Room','"+hotelAmenitiesDto.getSteamRoom()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Spa','"+hotelAmenitiesDto.getSpa()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Snooker','"+hotelAmenitiesDto.getSnooker()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Solarium','"+hotelAmenitiesDto.getSolarium()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Winter Sports','"+hotelAmenitiesDto.getWinterSports()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Shooting','"+hotelAmenitiesDto.getShooting()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Sauna','"+hotelAmenitiesDto.getSauna()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Fishing','"+hotelAmenitiesDto.getFishing()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Golf','"+hotelAmenitiesDto.getGolf()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Croquet','"+hotelAmenitiesDto.getCroquet()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Bowls','"+hotelAmenitiesDto.getBowls()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Badminton','"+hotelAmenitiesDto.getBadminton()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Gym','"+hotelAmenitiesDto.getGym()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Health Club','"+hotelAmenitiesDto.getHealthClub()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Outdoor Swimming Pool','"+hotelAmenitiesDto.getOutdoorSwimmingPool()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Jacuzzi','"+hotelAmenitiesDto.getJacuzzi()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Indoor Swimming Pool','"+hotelAmenitiesDto.getIndoorSwimmingPool()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Horse Riding','"+hotelAmenitiesDto.getHorseRiding()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Archery','"+hotelAmenitiesDto.getArchery()+"')").executeUpdate();
		
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Coach Parking','"+hotelAmenitiesDto.getCoachParking()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Free Off-Site Parking','"+hotelAmenitiesDto.getFreeOffSiteParking()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Free On-Site Parking','"+hotelAmenitiesDto.getFreeOnSiteParking()+"')").executeUpdate();
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,unit_of_measure,price) values (1,'Off Site Parking With Fee','"+hotelAmenitiesDto.getOffSiteParkingWithFee()+"','"+hotelAmenitiesDto.getUnitOfMeasureOffSiteParking()+"','"+hotelAmenitiesDto.getUnitOfMeasureOffSiteParkingPrice()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,unit_of_measure,price) values (1,'On Site Parking With Fee','"+hotelAmenitiesDto.getOnSiteParkingWithFee()+"','"+hotelAmenitiesDto.getUnitOfMeasureOnSiteParking()+"','"+hotelAmenitiesDto.getUnitOfMeasureOnSiteParkingPrice()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Public Transport','"+hotelAmenitiesDto.getPublicTransport()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Limousine Service','"+hotelAmenitiesDto.getLimuousineService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Shuttle Bus','"+hotelAmenitiesDto.getShuttleBus()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Taxi Service','"+hotelAmenitiesDto.getTaxiService()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Tailor','"+hotelAmenitiesDto.getTailor()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Terrace','"+hotelAmenitiesDto.getTerrace()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Restaurant','"+hotelAmenitiesDto.getRestaurant()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Medical Facility','"+hotelAmenitiesDto.getMedicalFacility()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Luggage Storage','"+hotelAmenitiesDto.getLuggageStorage()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Laundry Service','"+hotelAmenitiesDto.getLaundryService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Business Center','"+hotelAmenitiesDto.getBusinessCentre()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Cloak Room Srvice','"+hotelAmenitiesDto.getCloakroomService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Bed Room','"+hotelAmenitiesDto.getBedRooms()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Ramp Access','"+hotelAmenitiesDto.getRampAccess()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Bar / Pub','"+hotelAmenitiesDto.getBar()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Ball Room','"+hotelAmenitiesDto.getBallRoom()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Concierge','"+hotelAmenitiesDto.getConcierge()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Disabled Facilities','"+hotelAmenitiesDto.getDisabledFacilities()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Heating','"+hotelAmenitiesDto.getHeating()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Helipad','"+hotelAmenitiesDto.getHelipad()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Garden','"+hotelAmenitiesDto.getGarden()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Free WiFi','"+hotelAmenitiesDto.getFreeWifi()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Elevator','"+hotelAmenitiesDto.getElevator()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Front Desk','"+hotelAmenitiesDto.getFrontDesk()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Close to Shopping Area','"+hotelAmenitiesDto.getShoppingArea()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Close to Nature','"+hotelAmenitiesDto.getCloseToNature()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Country Side','"+hotelAmenitiesDto.getCountrySide()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'In the Airport','"+hotelAmenitiesDto.getInTheAirport()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'In the Center','"+hotelAmenitiesDto.getInTheCentre()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near Airport','"+hotelAmenitiesDto.getNearAirport()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near Attraction','"+hotelAmenitiesDto.getNearAttractions()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near Harbor','"+hotelAmenitiesDto.getNearHarbor()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near Motorway','"+hotelAmenitiesDto.getNearMotorway()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near Railway Station','"+hotelAmenitiesDto.getNearRailwayStation()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Near the Center','"+hotelAmenitiesDto.getNearTheCentre()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'NearBy Water','"+hotelAmenitiesDto.getNearByWater()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Suburbs','"+hotelAmenitiesDto.getSuburbs()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'One Tea Break','"+hotelAmenitiesDto.getOneTeaBreak()+"','"+hotelAmenitiesDto.getOneTeaBreakService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Two Tea Break','"+hotelAmenitiesDto.getTwoTeaBreak()+"','"+hotelAmenitiesDto.getTwoTeaBreakService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Three Tea Break','"+hotelAmenitiesDto.getThreeTeaBreak()+"','"+hotelAmenitiesDto.getThreeTeaBreakService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Unlimited Tea','"+hotelAmenitiesDto.getUnlimitedTea()+"','"+hotelAmenitiesDto.getUnlimitedTeaService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Alcoholic Beverages','"+hotelAmenitiesDto.getAlcoholicBeverages()+"','"+hotelAmenitiesDto.getAlcoholicBeveragesService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Cold Beverages','"+hotelAmenitiesDto.getColdBeverages()+"','"+hotelAmenitiesDto.getColdBeveragesService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Hot Beverages','"+hotelAmenitiesDto.getHotBeverages()+"','"+hotelAmenitiesDto.getHotBeveragesService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Still Water','"+hotelAmenitiesDto.getStillWater()+"','"+hotelAmenitiesDto.getStillWaterService()+"')").executeUpdate();
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Two BreakFast','"+hotelAmenitiesDto.getTwoBreakfast()+"','"+hotelAmenitiesDto.getTwoBreakfastService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Full BreakFast','"+hotelAmenitiesDto.getFullBreakfast()+"')").executeUpdate();
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Lunch Buffet','"+hotelAmenitiesDto.getLunchBuffet()+"','"+hotelAmenitiesDto.getLunchBuffetService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Lunch Ala Carte','"+hotelAmenitiesDto.getLunchAlaCarte()+"','"+hotelAmenitiesDto.getLunchAlaCarteService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Two Course Menu','"+hotelAmenitiesDto.getTwoCourseMenu()+"','"+hotelAmenitiesDto.getTwoCourseMenuService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Buffet Lunch','"+hotelAmenitiesDto.getBuffetLunch()+"','"+hotelAmenitiesDto.getBuffetLunchService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Two Lunch Ala Carte','"+hotelAmenitiesDto.getTwoLunchAlaCarte()+"','"+hotelAmenitiesDto.getTwoLunchAlaCarteService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Two Lunch Buffet','"+hotelAmenitiesDto.getTwoLunchBuffet()+"','"+hotelAmenitiesDto.getTwoLunchBuffetService()+"')").executeUpdate();
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Supper','"+hotelAmenitiesDto.getSupper()+"','"+hotelAmenitiesDto.getSupperService()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,selection_permitted) values (1,'Three Course Dinner','"+hotelAmenitiesDto.getThreeCourseDinner()+"','"+hotelAmenitiesDto.getThreeCourseDinnerService()+"')").executeUpdate();
		
		
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Snacks','"+hotelAmenitiesDto.getSnacks()+"')").executeUpdate();
		getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available) values (1,'Fresh Fruits','"+hotelAmenitiesDto.getFreshFruits()+"')").executeUpdate();
		
		
		//getSession().createSQLQuery("insert into hotelamenities (hotel_id,hotel_amenity_name,is_available,unit_of_measure,price,selection_permitted) values (1,'Multilingual Staff','"+hotelAmenitiesDto.getMultiLinguaStaff()+"')").executeUpdate();
		
	}

}

package com.mindtree.meetex.itadmin.assetmanagement.dao.daoimpl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.meetex.entity.Customer;
import com.mindtree.meetex.entity.LogIn;
import com.mindtree.meetex.itadmin.assetmanagement.dao.LoginDaoInterface;
@Repository
public class LoginDaoInterfaceImpl implements LoginDaoInterface {

	@Autowired
	private SessionFactory sessionFactory;
	


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	public Customer authenticateCustomer(LogIn login) {
	
		return null;
		
	//	return this.sessionFactory.getCurrentSession().get(LogIn.class, login);
	}

}

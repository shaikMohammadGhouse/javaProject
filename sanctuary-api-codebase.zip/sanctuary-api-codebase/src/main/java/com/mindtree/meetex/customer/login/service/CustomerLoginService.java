package com.mindtree.meetex.customer.login.service;

import java.util.List;

import com.mindtree.meetex.entity.Customer;

public interface CustomerLoginService {
	
	public List<Customer> getAllCustomers();

}

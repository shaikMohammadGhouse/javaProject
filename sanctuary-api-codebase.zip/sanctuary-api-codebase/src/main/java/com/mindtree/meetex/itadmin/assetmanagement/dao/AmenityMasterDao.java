package com.mindtree.meetex.itadmin.assetmanagement.dao;

import java.util.List;

import com.mindtree.meetex.entity.AmenityMasterData;

public interface AmenityMasterDao {

    void addAmenities(AmenityMasterData amenity);
	List<AmenityMasterData> getALLAmenity();
	AmenityMasterData getAmenity(int amenityId);

	
}

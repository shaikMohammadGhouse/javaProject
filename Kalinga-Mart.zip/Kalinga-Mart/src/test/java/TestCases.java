import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;

public class TestCases 
{
	public Product p=new Product();
	public Product p2=new Product();
	public Product testp=new Product();
	
	@Test
	public void validation()
	{
		p.setCategory("Mobile");
		p.setPrice(56800);
		p.setProductName("Motorola ");
		p.setProductId(5);
		assertEquals(p.getProductId(),5);
		assertNotEquals(p.getProductName(),"Motorola");
	}
	
	
	public Cart c=new Cart();
	@Test
	public void validating()
	{
				
		testp.setCategory("Mobile");
		testp.setPrice(56800);
		testp.setProductId(5);
		testp.setProductName("Motorola ");
		c.setCartId(1);
		c.setProduct(testp);
	
		assertEquals(c.getCartId(),1);
		assertEquals(c.getProduct(), testp);
	}
	
	@Test
	public void validatePrice()
	{
		p2.setPrice(8757.45);
		double x=p2.getPrice();
		assertNotNull(x);
		
	}
	
	@Test
	public void validateCategory()
	{
		p2.setCategory("Mobile");
		String cat=p2.getCategory();
		assertNotNull(cat);
	}
	
	
	
}

package com.mindtree.Kmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Kmart.dao.daoimpl.DaoImplException;
import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;
import com.mindtree.Kmart.service.CartService;
import com.mindtree.Kmart.service.ServiceException;
import com.mindtree.Kmart.service.serviceimpl.ProductServiceImpl;



@RestController
@CrossOrigin
public class ProductController
{

	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Product> getProducts(Model model)
	{
		try
		{
		List<Product> listOfProducts = productServiceImpl.getAllProducts();
		return listOfProducts;
		}
		catch(ServiceException e)
		{
			e.getMessage();
			return null;
		}
		
//		model.addAttribute("product", new Product());
//		model.addAttribute("listOfProducts", listOfProducts);
//		return "productDetails";
	}

	@RequestMapping(value = "/getProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public Product getProductById(@PathVariable int productId)
	{
		try {
			return productServiceImpl.getProduct(productId);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}


	
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addProduct(@ModelAttribute("product") Product product) 
	{	
		if(product.getProductId()==0)
		{
			try {
				productServiceImpl.addProduct(product);
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{	
			try {
				productServiceImpl.updateProduct(product);
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/updateProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String updateProduct(@PathVariable("productId") int productId,Model model)
	{
		 try {
			model.addAttribute("product", this.productServiceImpl.getProduct(productId));
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        try {
				model.addAttribute("listOfProducts", this.productServiceImpl.getAllProducts());
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        return "productDetails";
	        //return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/deleteProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteProduct(@PathVariable("productId") int productId)
	{
		try {
			productServiceImpl.deleteProduct(productId);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return "redirect:/getAllProducts";

	}	
	
	
	@RequestMapping(value="/addtocart", method=RequestMethod.POST)
	public void addToCart(@RequestBody Product product)
	{
		this.cartService.addToCart(product);
	}
	
	
	@RequestMapping(value="/cart", method=RequestMethod.GET)
	public List<Cart> getCart()
	{
		return this.cartService.getCart();
	}
	
	@RequestMapping(value="/deletecart/{cartId}",method=RequestMethod.GET)
	public void deleteCart(@PathVariable("cartId") int cartId)
	{
		this.cartService.deleteCart(cartId);
	}
	
	
	
	
}








/*
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.mindtree.Kmart.entity.Product;
import com.mindtree.Kmart.service.ServiceException;
//import com.mindtree.Kmart.service.serviceimpl.CartServiceImpl;
import com.mindtree.Kmart.service.serviceimpl.ProductServiceImpl;



@Controller
public class ProductController
{

	@Autowired
	ProductServiceImpl productServiceImpl;
	
//	@Autowired
//	CartServiceImpl cartServiceImpl;
	
	
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getProducts(Model model) {
		
		 List<Product> listOfProducts;
		try {
			listOfProducts = productServiceImpl.getAllProducts();
			model.addAttribute("product", new Product());
			model.addAttribute("listOfProducts", listOfProducts);
			return "productDetails";
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}

	@RequestMapping(value = "/getProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public Product getProductById(@PathVariable int productId) {
		try {
			return productServiceImpl.getProduct(productId);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}


	
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addProduct(@ModelAttribute("product") Product product) {	
		if(product.getProductId()==0)
		{
			try {
				productServiceImpl.addProduct(product);
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}
		else
		{	
			try {
				productServiceImpl.updateProduct(product);
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}
		
		return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/updateProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String updateProduct(@PathVariable("productId") int productId,Model model) {
		 try {
			model.addAttribute("product", this.productServiceImpl.getProduct(productId));
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        try {
				model.addAttribute("listOfProducts", this.productServiceImpl.getAllProducts());
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        return "productDetails";
	        //return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/deleteProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteProduct(@PathVariable("productId") int productId) {
		try {
			productServiceImpl.deleteProduct(productId);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return "redirect:/getAllProducts";

	}	
	
	
}

*/
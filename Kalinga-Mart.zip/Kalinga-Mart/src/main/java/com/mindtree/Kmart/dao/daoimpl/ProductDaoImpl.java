package com.mindtree.Kmart.dao.daoimpl;

import com.mindtree.Kmart.entity.Product;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ProductDaoImpl
{
	@Autowired	
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf)
	{
		this.sessionFactory = sf;
	}
	
	public List<Product> getAllProducts()throws DaoImplException{
		Session session = this.sessionFactory.getCurrentSession();
		List<Product> productList = session.createQuery("from Product").list();
		return productList;
	}
	
	public Product getProduct(int productId)throws DaoImplException{
		Session session = this.sessionFactory.getCurrentSession();
		Product product = (Product) session.get(Product.class, new Integer(productId));
		return product;
	}
	public void updateProduct(Product product)throws DaoImplException
	{
		Session session = this.sessionFactory.getCurrentSession();
		session.update(product);
	}
	public Product addProduct(Product product)throws DaoImplException{
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(product);
		return product;
		
	}
	public void deleteProduct(int productId)throws DaoImplException {
		Session session = this.sessionFactory.getCurrentSession();
		Product p = (Product) session.load(Product.class, new Integer(productId));
		if (null != p) {
			session.delete(p);
		}
	}
	public SessionFactory getSessionFactory() throws DaoImplException{
		return sessionFactory;
	}
	

	
}

/*package com.mindtree.Kmart.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Kmart.entity.Product;
import com.mindtree.Kmart.service.serviceimpl.ProductServiceImpl;



@RestController
public class MyCart
{

	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Product> getProducts(Model model) {
		
		List<Product> listOfProducts = productServiceImpl.getAllProducts();
		return listOfProducts;
//		model.addAttribute("product", new Product());
//		model.addAttribute("listOfProducts", listOfProducts);
//		return "productDetails";
	}

	@RequestMapping(value = "/getProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public Product getProductById(@PathVariable int productId) {
		return productServiceImpl.getProduct(productId);
	}


	
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addProduct(@ModelAttribute("product") Product product) {	
		if(product.getProductId()==0)
		{
			productServiceImpl.addProduct(product);
		}
		else
		{	
			productServiceImpl.updateProduct(product);
		}
		
		return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/updateProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String updateProduct(@PathVariable("productId") int productId,Model model) {
		 model.addAttribute("product", this.productServiceImpl.getProduct(productId));
	        model.addAttribute("listOfProducts", this.productServiceImpl.getAllProducts());
	        return "productDetails";
	        //return "redirect:/getAllProducts";
	}

	@RequestMapping(value = "/deleteProduct/{productId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteProduct(@PathVariable("productId") int productId) {
		productServiceImpl.deleteProduct(productId);
		 return "redirect:/getAllProducts";

	}	
}
*/
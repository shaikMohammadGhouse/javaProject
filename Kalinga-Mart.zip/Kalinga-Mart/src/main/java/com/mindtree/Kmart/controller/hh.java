package com.mindtree.Kmart.controller;

public class hh {
public static void main(String[] args) {
	System.out.println(System.getProperty("user.dir"));
	System.out.println("hhi");
}
}

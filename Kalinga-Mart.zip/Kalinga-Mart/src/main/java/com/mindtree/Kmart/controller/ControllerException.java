package com.mindtree.Kmart.controller;

import com.mindtree.Kmart.ApplicationException;

public class ControllerException extends ApplicationException
{
	String exception="";
	public ControllerException(String excepiton) {
		this.exception=excepiton;
	}
	
	public ControllerException() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return exception;
	}
}

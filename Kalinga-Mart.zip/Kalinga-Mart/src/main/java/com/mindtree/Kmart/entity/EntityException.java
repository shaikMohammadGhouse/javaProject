package com.mindtree.Kmart.entity;

import com.mindtree.Kmart.ApplicationException;

public class EntityException extends ApplicationException
{

String exception="";
	
	public EntityException(String exception) 
	{
		this.exception=exception;
	}
	
	@Override
	public String getMessage() {
		
		return exception;
	}
	
	public EntityException() {
		
	}
}

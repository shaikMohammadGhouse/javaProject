package com.mindtree.Kmart.service;

import com.mindtree.Kmart.entity.Product;

public interface ProductService {

	java.util.List<Product> getAllProducts()throws ServiceException;

	Product getProduct(int id)throws ServiceException;

	void addProduct(Product product)throws ServiceException;

	void updateProduct(Product product)throws ServiceException;

	void deleteProduct(int id)throws ServiceException;

}

package com.mindtree.Kmart;

public class ApplicationException extends Exception 
{
	String exception="";
	public ApplicationException(String exception) 
	{
		this.exception=exception;
		
	}
	
	@Override
	public String getMessage() {
		
		return exception;
	}
	
	public ApplicationException() {
		
	}
}

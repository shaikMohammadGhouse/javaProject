package com.mindtree.Kmart.dao.daoimpl;

import com.mindtree.Kmart.dao.DaoException;

public class DaoImplException extends DaoException{
	String exception="";
	public DaoImplException(String exception)
	{
		this.exception=exception;
	}

	@Override
	public String getMessage() {
		return exception;
	}
}

package com.mindtree.Kmart.service.serviceimpl;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.Kmart.dao.daoimpl.*;
import com.mindtree.Kmart.entity.Product;
import com.mindtree.Kmart.service.ServiceException;

@Service
@Transactional
public class ProductServiceImpl {
	
	@Autowired
	ProductDaoImpl productDaoImpl;
	
	
	public List<Product> getAllProducts()throws ServiceException
	{
		try {
			return productDaoImpl.getAllProducts();
		} catch (DaoImplException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException();
		}
	}

	public Product getProduct(int productId)throws ServiceException
	{
		try {
			return productDaoImpl.getProduct(productId);
		} catch (DaoImplException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException();
		}
		
	}

	public void addProduct(Product product)throws ServiceException
	{
		try {
			productDaoImpl.addProduct(product);
		} catch (DaoImplException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException("Service Exception at addProduct");
		}
	}

	public void updateProduct(Product product)throws ServiceException
	{
		try {
			productDaoImpl.updateProduct(product);
		} catch (DaoImplException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException("Service Exception at updateProduct");
		}
	}

	@Transactional
	public void deleteProduct(int productId)throws ServiceException
	{
		try {
			productDaoImpl.deleteProduct(productId);
		} catch (DaoImplException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException("Service Exception at deleteProduct");
		}
	}

	public ProductDaoImpl getProductDaoImpl() {
		return productDaoImpl;
	}

	public void setProductDaoImpl(ProductDaoImpl productDaoImpl) {
		this.productDaoImpl = productDaoImpl;
	}

	
}

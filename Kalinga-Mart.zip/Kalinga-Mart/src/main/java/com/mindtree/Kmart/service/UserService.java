package com.mindtree.Kmart.service;

public interface UserService {

}

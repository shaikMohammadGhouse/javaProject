package com.mindtree.Kmart.dao;

import java.util.List;

import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;

public interface CartDao {

	void addToCart(Product product);

	List<Cart> getCart();


	void deleteCart(int cartId);

}

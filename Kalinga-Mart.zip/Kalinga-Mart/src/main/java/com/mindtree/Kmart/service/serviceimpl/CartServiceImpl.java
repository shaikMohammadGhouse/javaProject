package com.mindtree.Kmart.service.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Kmart.dao.CartDao;
import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;
import com.mindtree.Kmart.service.CartService;


@Service
@Transactional
public class CartServiceImpl implements CartService
{
	
	
	
	@Autowired
	private CartDao cartDao;
	
	public void setCartDao(CartDao cartDao)
	{
		this.cartDao=cartDao;
	}
	
	
	public CartDao getCartDao()
	{
		return cartDao;
	}
	

	@Override
	public void addToCart(Product product) 
	{
		this.cartDao.addToCart(product);
		
	}

	@Override
	public List<Cart> getCart() {
		
		return this.cartDao.getCart();
	}

	@Override
	public void deleteCart(int cartId) 
	{
		this.cartDao.deleteCart(cartId);
		
	}

}

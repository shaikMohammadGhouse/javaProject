package com.mindtree.Kmart.service;

import com.mindtree.Kmart.ApplicationException;

public class ServiceException extends ApplicationException
{
	String exception="";
	
	public ServiceException(String exception) {
		this.exception=exception;
	}
	
	@Override
	public String getMessage() {
		
		return exception;
	}
	
	public ServiceException() {
		
	}
}

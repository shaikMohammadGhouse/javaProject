package com.mindtree.Kmart.dao;

import java.util.List;

import com.mindtree.Kmart.dao.daoimpl.DaoImplException;
import com.mindtree.Kmart.entity.Product;


public interface ProductDao {


	
	List<Product> getAllProducts()throws DaoImplException;

	Product getProduct(int id)throws DaoImplException;

	public void addProduct(Product product)throws DaoImplException;

	void updateProduct(Product product)throws DaoImplException;

	void deleteProduct(int id)throws DaoImplException;

}

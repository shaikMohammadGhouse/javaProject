package com.mindtree.Kmart.entity;

import javax.persistence.*;

@Entity
@Table (name="cart")
public class Cart 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cart_id")
	private int cartId;
	
	
	@OneToOne
	@JoinColumn(name="productId")
	private Product product;
	
	public Cart() {
		super();
	}
	public Cart(int cartId, Product product) {
		super();
		this.cartId = cartId;
		this.product = product;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
}

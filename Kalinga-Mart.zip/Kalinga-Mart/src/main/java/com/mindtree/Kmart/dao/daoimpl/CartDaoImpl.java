package com.mindtree.Kmart.dao.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.Kmart.dao.CartDao;
import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;

@Repository
public class CartDaoImpl implements CartDao
{

	@Autowired
	SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf)
	{
		this.sessionFactory=sf;
	}
	
	public Session getSession()
	{
		return this.sessionFactory.getCurrentSession();
	}
	
	
	@Override
	public void addToCart(Product product) 
	{
		getSession().createSQLQuery("insert into cart (productId) values ("+product.getProductId()+")").executeUpdate();
		
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Cart> getCart() {
		
		List<Cart> cart=getSession().createQuery("from Cart").list();
		return cart;
	}

	@Override
	public void deleteCart(int cartId) 
	{
		Cart cart=getSession().load(Cart.class,new Integer(cartId));
		getSession().delete(cart);
	}

}

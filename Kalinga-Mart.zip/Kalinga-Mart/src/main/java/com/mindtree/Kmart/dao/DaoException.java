package com.mindtree.Kmart.dao;

import com.mindtree.Kmart.ApplicationException;

public class DaoException extends ApplicationException
{
	String exception="";
	public DaoException(String exception) {
		this.exception=exception;
	}
	
	@Override
	public String getMessage() {
		
		return exception;
	}
	public DaoException() {
	
	}
	
	
}

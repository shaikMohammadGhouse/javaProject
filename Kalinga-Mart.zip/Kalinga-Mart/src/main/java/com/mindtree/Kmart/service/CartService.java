package com.mindtree.Kmart.service;

import java.util.List;

import com.mindtree.Kmart.entity.Cart;
import com.mindtree.Kmart.entity.Product;

public interface CartService {

	void addToCart(Product product);

	List<Cart> getCart();

	void deleteCart(int cartId);

}

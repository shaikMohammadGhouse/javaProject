package com.mindtree.fetchDetails.manager;


import com.mindtree.fetchDetails.entity.Details;
import com.mindtree.fetchDetails.entity.EmpSalary;
import com.mindtree.fetchDetails.service.FetchService;
import com.mindtree.fetchDetails.service.serviceimpl.FetchServiceImpl;

public class FetchApp 
{
	public static void main(String[] args) 
	{
			EmpSalary salary=15000;
			
			EmpSalary sal=new EmpSalary();
			sal.setSalary(salary);
			
			FetchService service=new FetchServiceImpl();
			for(Details d:service.getDetails(sal))
			{
				System.out.println(d.getId()+"\t"+d.getName()+"\t"+d.getSalary()+"\t"+d.getCity());
			}
			
	}
}

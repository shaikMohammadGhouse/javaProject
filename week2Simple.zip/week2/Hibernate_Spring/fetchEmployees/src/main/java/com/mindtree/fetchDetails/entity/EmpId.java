package com.mindtree.fetchDetails.entity;

public class EmpId 
{
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EmpId(int id) 
	{
		
		this.id = id;
	}

	public EmpId() 
	{

	}

	@Override
	public String toString() {
		return "EmpId [id=" + id + "]";
	}
	
	
}

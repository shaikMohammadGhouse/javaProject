package com.mindtree.fetchDetails.entity;

public class Details 
{
	private int id;
	private String city;
	private String name;
	private int salary;
	private char grade;
	
	public Details(int id, String city, String name, int salary, char grade) 
	{
		
		this.id = id;
		this.city = city;
		this.name = name;
		this.salary = salary;
		this.grade = grade;
	}
	

	public Details() 
	{
	
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Details [id=" + id + ", city=" + city + ", name=" + name + ", salary=" + salary + ", grade=" + grade
				+ "]";
	}
	
}

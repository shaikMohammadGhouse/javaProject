package com.mindtree.fetchDetails.dao;

import java.util.List;

import com.mindtree.fetchDetails.entity.Details;
import com.mindtree.fetchDetails.entity.EmpSalary;

public interface FetchDao 
{
	
	public List<Details> getDetails(EmpSalary sal);
		
}

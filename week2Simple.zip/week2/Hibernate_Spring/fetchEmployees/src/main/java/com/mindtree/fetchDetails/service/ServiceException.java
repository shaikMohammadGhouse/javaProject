package com.mindtree.fetchDetails.service;

import com.mindtree.fetchDetails.ApplicationException;

public class ServiceException extends ApplicationException{

}

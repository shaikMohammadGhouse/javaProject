package com.mindtree.fetchDetails.service;

import java.util.List;

import com.mindtree.fetchDetails.entity.Details;
import com.mindtree.fetchDetails.entity.EmpSalary;

public interface FetchService 
{
	public List<Details> getDetails(EmpSalary sal);
}

package com.mindtree.fetchDetails.manager;

import com.mindtree.fetchDetails.ApplicationException;

public class ManagerException extends ApplicationException{

}

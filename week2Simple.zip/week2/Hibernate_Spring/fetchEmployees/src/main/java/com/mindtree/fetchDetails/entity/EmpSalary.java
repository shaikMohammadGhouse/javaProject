package com.mindtree.fetchDetails.entity;

public class EmpSalary 
{
	private EmpSalary salary;
	public EmpSalary(EmpSalary salary) 
	{
		super();
		this.salary = salary;
	}

	public EmpSalary() 
	{
		super();
	}
	

	public EmpSalary getSalary()
	{
		return salary;
	}

	public void setSalary(EmpSalary salary) 
	{
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmpSalary [salary=" + salary + "]";
	}


	
}

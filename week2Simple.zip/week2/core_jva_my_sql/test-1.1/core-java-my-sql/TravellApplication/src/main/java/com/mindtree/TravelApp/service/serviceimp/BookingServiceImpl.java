package com.mindtree.TravelApp.service.serviceimp;

import java.util.List;

import com.mindtree.TravelApp.dao.BookingDao;
import com.mindtree.TravelApp.dao.daoimpl.BookingDaoImpl;
import com.mindtree.TravelApp.entity.BookingDetails;
import com.mindtree.TravelApp.entity.City;
import com.mindtree.TravelApp.service.BookingService;

public class BookingServiceImpl implements BookingService
{
	private BookingDao bookingDao=new  BookingDaoImpl();
	public List<BookingDetails> getBookingDetails(City Destination)
	{
		return bookingDao.getBookingDetails(Destination);
		
	}
	public boolean validate(String s)
	{
		if(s.equals("bengalore"))
				{
			return true;
				}
		else
			return false;
	}
}

package com.mindtree.TravelApp.dao.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import com.mindtree.TravelApp.dao.BookingDao;
import com.mindtree.TravelApp.entity.BookingDetails;
import com.mindtree.TravelApp.entity.City;
import com.mindtree.TravelApp.utilities.*;
public class BookingDaoImpl implements BookingDao
{
	Statement stat=null; 
	 String query;
	Connection conn=null;
	
	
	public List<BookingDetails> getBookingDetails(City destination) 
	{
		// TODO Auto-generated method stub
		List<BookingDetails> bookingDetails=new ArrayList<BookingDetails>();
		
		 
		try {
			conn = DBUtil.getConnection();
			stat=conn.createStatement();
			query="select bookingId,source from travelbooking where destination="+"'"+destination.getName()+"'";
			ResultSet res1=stat.executeQuery(query);
			while(res1.next())
			{
				BookingDetails bookingDetail=new BookingDetails();
				City sourceCity=new City();
				int bookingId=res1.getInt("bookingId");
				String source=res1.getString("source");
				sourceCity.setName(source);
				bookingDetail.setBookid(bookingId);
				bookingDetail.setSource(sourceCity);
				bookingDetails.add(bookingDetail);			
				
			}
			res1.close();	
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBUtil.closeConnection();
		}
		finally
		{

		
			DBUtil.closeConnection();
		}
		
		
		
		return bookingDetails;
	}
	
}

package com.mindtree.TravelApp.utilities;
import java.sql.*;
public class DBUtil
{
	private static String driver="com.mysql.jdbc.Driver";
	private static String url="jdbc:mysql://localhost:3306/travel";
	private static String username="root";
	private static String password="Welcome123";
	static Connection conn=null;
	
	public static Connection getConnection()
	{
		try 
		{
			Class.forName(driver);
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			conn=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public static void closeConnection()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package com.mindtree.TravelApp.dao;
import com.mindtree.TravelApp.entity.*;

import java.util.*;

public interface BookingDao 
{
	public List<BookingDetails> getBookingDetails(City destination);
	
}


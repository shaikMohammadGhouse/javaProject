package simple;

public class SimpleThread
{
	public static void main(String[] args)
	{
		Thread t1=new Thread();
		t1.getPriority();
		t1.setName("shaik");
		
		t1.start();
		
		System.out.println("started");
		System.out.println(t1.getName());
		System.out.println(t1.getPriority());
		System.out.println(t1.getId());
		
	}
}

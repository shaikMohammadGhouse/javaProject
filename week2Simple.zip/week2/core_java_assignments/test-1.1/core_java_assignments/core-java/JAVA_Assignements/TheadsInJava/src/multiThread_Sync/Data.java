package multiThread_Sync;
public class Data 
{
	private int x=4;
	public int getX()
	{
		return x;
	}
	synchronized public void ConsumerX(int arg)
	{
		String th_name=Thread.currentThread().getName();
		System.out.println(th_name+" is running");		
		if(x<5)
		{
			System.out.println(" insufficient data, waitng for notification");
		
			try {
				wait();
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(th_name+" running back");
			x=x-arg;
			System.out.println(x);
		}
		else
		{
			System.out.println(" data sufficient");
			x=x-arg;
		}
	}
	synchronized public void ProducerX(int arg)
	{
		String th_name=Thread.currentThread().getName();
		System.out.println(th_name+" is producing "+arg+" values");
		x=x+arg;
		System.out.println(th_name+" notifying the threads...");
		notifyAll();	
	}
}

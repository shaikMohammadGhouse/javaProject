package java_core_assig;

public class OutstandingPerson {

}

package outstanding_person;

public class Student extends Person
{
	double percentage;
	
	public Student()
	{
		// TODO Auto-generated constructor stub
	}
	public Student(String name,double percentage)
	{
		
		this.percentage=percentage;
		this.name=name;
	}
	void display()
	{
		Student s=new Student();
		System.out.println(name+"  "+percentage);
	}
	
	public boolean isOutstanding()
	{
		if(percentage>=85)
		{
			return true;
		}
		else return false;
	}
}

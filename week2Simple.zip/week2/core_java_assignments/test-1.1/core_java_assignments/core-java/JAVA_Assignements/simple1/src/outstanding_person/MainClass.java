package outstanding_person;

public class MainClass 
{

	public static void main(String[] args)
	{
		
		Person p[]=new Person[5];
		
		p[0]=new Professor("shaik",5);
		p[1]=new Professor("shaik1", 3);
		p[2]=new Student("shaik2",90.56);
		p[3]=new Student("shaik3",80);
		p[4]=new Student("shaik4",80.56);
		for(int i=0;i<5;i++)
		{
			if(p[i]instanceof Professor)
			{
				Professor p1=(Professor)p[i];
				if(p1.isOutstanding()==true)
				{
					p1.print();
				}
			}
			else if(p[i] instanceof Student)
			{
				Student s1=(Student)p[i];
				if(s1.isOutstanding()==true)
				{
				
					s1.display();
				}
			}
		}
		
		
	}

}

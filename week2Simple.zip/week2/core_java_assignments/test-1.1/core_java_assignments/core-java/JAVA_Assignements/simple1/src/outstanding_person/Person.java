package outstanding_person;

public class Person 
{
		String name;
		
		Person()
		{
				
		}
		Person(String name)
		{
			
		}
		String getName()
		{
			return name;
		}
		void setName(String name)
		{
			this.name=name;
		}
		public boolean isOutstanding()
		{
			return false;
		}
		@Override
		public String toString() {
			return "Person [name=" + name + "]";
		}
		
		
}

package fibonacci_series;

import java.util.Scanner;
public class Fibonacci
{
	 public static void main(String args[]) 
	 {
		 System.out.println("Enter nth number : ");
		 int number = new Scanner(System.in).nextInt();
		
		 System.out.println("Fibonacci series upto " + number +" numbers : ");
		 int x=fibonacci(number);
		System.out.println("\n\n\n\n"+x);
	 }
	 
	 public static int fibonacci(int number)
	 { 
		 int arr[]=new int[number+1];
		 for(int i=0; i<=number; i++)
		 {
			 arr[i]=findfibonacci(i);
			 
		 }
		
		 for(int i=0; i<=number; i++)
		 {
			 System.out.println(arr[i]);
		 }
		 return arr[number];
		 
	 }
	 public static int findfibonacci(int number)
		 {
		 if(number == 0)
		 {
			 return 0;
		 }
		 if(number == 1 || number == 2)
		 { return 1; } 
		 return findfibonacci(number-1) + findfibonacci(number -2); //tail recursion }
	 }
	 
}

package com.mindtree.player_auction.manager;

import java.util.ArrayList;
import java.util.Scanner;

import com.mindtree.player_auction.entity.Player;
import com.mindtree.player_auction.service.Player_Service_Impl;
import com.mindtree.player_auction.service.Player_service;

public class PlayerApplication 
{

		public static void main(String[] args) 
		{
			StringBuilder sb=new StringBuilder();
			int ch=0;
			Player_Service_Impl se=new Player_Service_Impl();
			Scanner sc=new Scanner(System.in);
		 do
		  {
			System.out.println("Choose Your Option");
			System.out.println("1.ADD Player Details");
			System.out.println("2.Display Players");
			System.out.println("3.Exit");
			System.out.println("Enter your choice:");
			ch=Integer.parseInt(sc.next());
			int enter=0;
			switch(ch)
			{
			case 1:
					System.out.println("enter player name");
					String name=sc.next();
					enter=se.validateName(name);
					if(enter==3)
					{
						break;
					}
					System.out.println("enter player category");
					String Category=sc.next();
					enter=se.validateCategory(Category);
					if(enter==3)
					{
							break;
					}
					System.out.println("enter player highscore");
					int highscore=Integer.parseInt(sc.next());
					enter=se.validateHighScore(highscore);
					if(enter==3)
					{
						break;
					}
					System.out.println("enter player bestFigure");
					String bestFigure=sc.next();
					enter=se.validateBestFigure(bestFigure);
					if(enter==3)
					{
						break;
					}
					System.out.println("enter team name");
					String teamname=sc.next();
					enter=se.validateTeamName(teamname);
					if(enter==3)
					{
						break;
					}
					se.insertInto();
					break;
			
			case 2:
			 
					System.out.println("Enter team name");
					String name1=sc.next();
					enter=se.validateTeamName(name1);
					if(enter==3)
					{
						break;
					}
					Player_service ps=new Player_Service_Impl();
					ArrayList<Player> list=new ArrayList<Player>();
					list=ps.display(name1);
					Player p[]=new Player[list.size()];
					for(int i=0;i<list.size();i++)
					{
						p[i]=list.get(i);
					}
					String s="playerName"+"             "+"Category";
					sb.append(s);
					sb.append("\n");
					sb.append("------------------------------------------");
					sb.append("\n");
			  
					for(int i=0;i<list.size();i++)
					{
						if(p[i] instanceof Player)
						{
								String pname=p[i].getPlayer_name();
								String cat=p[i].getCategory();
								sb.append(pname);
								sb.append("\t");
								sb.append("\t");
								sb.append("\t");
								sb.append(cat);
								sb.append("\n");
						}
					}
					System.out.println(sb);
					break;	
			}
			if(enter==3)
			{
				break;
			}
		 }
		 while(ch!=3);
		}
}

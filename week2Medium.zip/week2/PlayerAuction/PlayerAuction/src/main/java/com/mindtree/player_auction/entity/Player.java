package com.mindtree.player_auction.entity;

public class Player 
{
	private String player_name;
	private String category;
	private int highest_score;
	private String best_figures;
	public Player(String player_name, String category, int highest_score, String best_figures)
	{
		super();
		this.player_name = player_name;
		this.category = category;
		this.highest_score = highest_score;
		this.best_figures = best_figures;
	}
	public String getPlayer_name() 
	{
		return player_name;
	}
	public void setPlayer_name(String player_name) 
	{
		this.player_name = player_name;
	}
	public String getCategory() 
	{
		return category;
	}
	public void setCategory(String category)
	{
		this.category = category;
	}
	public int getHighest_score() 
	{
		return highest_score;
	}
	public void setHighest_score(int highest_score) 
	{
		this.highest_score = highest_score;
	}
	public String getBest_figures() {
		return best_figures;
	}
	public void setBest_figures(String best_figures) 
	{
		this.best_figures = best_figures;
	}
	public Player() 
	{
		super();
	}
	
}

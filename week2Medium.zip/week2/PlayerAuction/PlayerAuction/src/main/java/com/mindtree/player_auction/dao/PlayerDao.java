package com.mindtree.player_auction.dao;

import java.util.ArrayList;

import com.mindtree.player_auction.entity.Player;
import com.mindtree.player_auction.entity.Team;

public interface PlayerDao 
{
	void insertData(Player p,Team t);
	ArrayList<Player> diplayDetails(String tname);
}

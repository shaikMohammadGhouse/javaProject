package com.mindtree.player_auction.exception;

public class DuplicateNameEntryException extends Exception
{
	public DuplicateNameEntryException (String string)
	  {
		  super(string);
	  }
}

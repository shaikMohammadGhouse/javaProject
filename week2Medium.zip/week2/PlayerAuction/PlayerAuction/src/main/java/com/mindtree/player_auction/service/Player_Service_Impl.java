package com.mindtree.player_auction.service;

import java.util.ArrayList;

import com.mindtree.player_auction.dao.PlayerDao;
import com.mindtree.player_auction.dao.PlayerDaoImpl;
import com.mindtree.player_auction.entity.Player;
import com.mindtree.player_auction.entity.Team;
import com.mindtree.player_auction.exception.DuplicateNameEntryException;
import com.mindtree.player_auction.exception.InvalidCategoryException;
import com.mindtree.player_auction.exception.InvalidTeamNameException;
import com.mindtree.player_auction.exception.NotABatsmenException;
import com.mindtree.player_auction.exception.NotABowlerException;
import com.mindtree.player_auction.manager.PlayerApplication;

public class Player_Service_Impl implements Player_service
{
	PlayerDaoImpl pd=new PlayerDaoImpl();
	Player p=new Player();
	Team t=new Team();
	
	public ArrayList<Player> display(String name) 
	{
		ArrayList<Player> list=new ArrayList<Player>();
		  PlayerDao pd=new PlayerDaoImpl();
		  list=pd.diplayDetails(name);
		  return list; 
		  // TODO Auto-generated method stub
	}
	
	
	public int validateName(String name)
	{
		   if(pd.playerName(name))
		   {
			 p.setPlayer_name(name);  
			 return 0;
		   }
		   else
		   {
			   try
				 {
				   throw new DuplicateNameEntryException("player name already exist in database.");
				 }
				 catch(DuplicateNameEntryException e)
				 {
					 System.out.println(e.getMessage());
					 PlayerApplication.main(null);
					 return 3;
				 }
			   
		    }
			
	}
	
	public int validateCategory(String category)
	{
		 if(category.equals("batsmen")||category.equals("bowler")||category.equals("allrounder"))
		 {
			 p.setCategory(category);
			 return 0;
		 }
		 else
		 {
				 try
				 {
					 throw new InvalidCategoryException("Invalid Category please check your input");
				 } 
				 catch (InvalidCategoryException e)
				 {
					 System.out.println(e.getMessage());
					 PlayerApplication.main(null);
					 return 3;
				 }
				 
		 }
			 
	}
	
	public int validateHighScore(int highscore)
	{
			 if((highscore<50||highscore>200)&&p.getCategory().equals("batsmen")==true)
			 {
				 try 
				 {
					 throw new NotABatsmenException("Invalid Batsment please check your input");
				 } 
				 catch (NotABatsmenException e) 
				 {
					 System.out.println(e.getMessage());
					 PlayerApplication.main(null);
					 return 3;
				 }
				 
			 }
			 else
			 {
				p.setHighest_score(highscore); 
				return 0;
			 }
			 
	}
	
	public int validateBestFigure(String bestFigure)
	{
			char ch[]=new char[bestFigure.length()];
			int count=0;
			for(int i=0;i<bestFigure.length();i++)
			{
				ch[i]=bestFigure.charAt(i); 
				if(ch[i]=='/')
				{
					count++;
				}
			 }
			 if((p.getCategory().equals("bowler"))&& count==0)
			 {
				try 
				{
					throw new NotABowlerException("Invalid bowler please enter your input");
				} 
				catch (NotABowlerException e)
				{
				 System.out.println(e.getMessage());
				}
				PlayerApplication.main(null);
				return 3;
			 }
			 else
			 {
				 p.setBest_figures(bestFigure);
			 }
			return 0; 
	}
	public int validateTeamName(String team_name)
	{
		 if(pd.teamName(team_name))
		 {
			t.setTeam_name(team_name);
			return 0;
		 }
		 else
		 {
			 try 
			 {
				 throw new InvalidTeamNameException("Invalid team name,please check your input");
		     }
			 catch (InvalidTeamNameException e)
			 {
				  System.out.println(e.getMessage());
			 }
		 }
			PlayerApplication.main(null);
			 return 3;
	}
	
	
	
	public void insertInto()
	{
			PlayerDao d1=new PlayerDaoImpl();
			 d1.insertData(p,t);
	}
}

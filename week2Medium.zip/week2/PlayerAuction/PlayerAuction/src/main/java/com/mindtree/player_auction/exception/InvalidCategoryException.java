package com.mindtree.player_auction.exception;

public class InvalidCategoryException extends Exception
{

		public InvalidCategoryException (String string)
		  {
			  super(string);
		  }


}

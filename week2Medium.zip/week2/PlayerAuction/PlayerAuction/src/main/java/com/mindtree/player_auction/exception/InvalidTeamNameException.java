package com.mindtree.player_auction.exception;

public class InvalidTeamNameException extends Exception
{
	public InvalidTeamNameException(String string)
	  {
		  super(string);
	  }

}

package com.mindtree.player_auction;

public class ApplicationException extends Exception
{

}

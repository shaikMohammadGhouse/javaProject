package com.mindtree.player_auction.service;

public class ServiceException {

}

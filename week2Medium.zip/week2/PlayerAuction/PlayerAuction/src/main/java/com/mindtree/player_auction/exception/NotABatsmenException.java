package com.mindtree.player_auction.exception;

public class NotABatsmenException extends Exception
{
	public NotABatsmenException (String string)
	  {
		  super(string);
	  }

}

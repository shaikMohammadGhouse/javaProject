package com.mindtree.TravelApp.manager;

import java.util.List;

import com.mindtree.TravelApp.entity.BookingDetails;
import com.mindtree.TravelApp.entity.City;
import com.mindtree.TravelApp.service.BookingService;
import com.mindtree.TravelApp.service.serviceimp.BookingServiceImpl;

public class App
{
	public static void main(String[] args) 
	{
			String name="Banglore";
			City destination=new City();
			
			
			destination.setName(name);
			
			//System.out.println(destination);
			
			BookingService bookingService=new BookingServiceImpl();
			List<BookingDetails> L = bookingService.getBookingDetails(destination);
			
			for(BookingDetails b:bookingService.getBookingDetails(destination))
			{
				System.out.println(b.getBookid()+"\t"+b.getSource().getName());
			}
			
	}
}

package com.mindtree.TravelApp.service;
import java.util.*;

import com.mindtree.TravelApp.entity.BookingDetails;
import com.mindtree.TravelApp.entity.City;
public interface BookingService
{
	public List <BookingDetails> getBookingDetails(City Destination);
	
}

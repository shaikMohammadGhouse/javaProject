

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SeleniumTest 
{
	public WebDriver webDriver;
	
	Logger logger=Logger.getLogger("SeleniumTest");
	
	
	@BeforeTest
	public void beforeTest()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1043001\\Downloads\\chromedriver_win32\\chromedriver.exe");
		webDriver=new ChromeDriver();
		webDriver.get("https://www.amazon.in/");
		webDriver.manage().window().maximize();
	}
	
	@Test
	public void test()
	{
		PropertyConfigurator.configure("log4j.properties");
		logger.info("openning amazon");
		webDriver.findElement(By.xpath("//*[@id='nav-link-yourAccount']/span[1]")).click();
		webDriver.findElement(By.xpath("//*[@id='ap_email']")).sendKeys("shaikmohammadonce@gmail.com");
		webDriver.findElement(By.xpath("//*[@id='continue']")).click();
		logger.info("entered gmail");
		webDriver.findElement(By.xpath("//*[@id='ap_password']")).sendKeys("919707714167shaik");
		logger.info("entered password");
		webDriver.findElement(By.xpath("//*[@id='signInSubmit']")).click();
		logger.info("clicked on submit button");
		webDriver.findElement(By.xpath("//*[@id='twotabsearchtextbox']")).sendKeys("boatSpeakers");
		logger.info("searching for boat speakers");
		webDriver.findElement(By.xpath("//*[@id='nav-search']/form/div[2]/div/input")).click();
		logger.info("clicking on boat speakerss");
		webDriver.findElement(By.xpath("//*[@id='result_1']/div/div/div/div[2]/div[1]/div[1]/a/h2")).click();
//		//ArrayList<E> list=  new List()webDriver.getWindowHandles()
//		webDriver.findElement(By.xpath("//*[@id='add-to-cart-button']")).click();

		
	}
}

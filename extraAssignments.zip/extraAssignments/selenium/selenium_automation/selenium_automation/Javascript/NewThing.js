var balance = [0, 32, 45, 50, 75,80, 80, 80, 99, 120];

 var newbalance = balance.map(function(elem) {
 console.log(elem + 89);
}); 






var uniqueArray = balance.filter(function(elem, index, array) {
    // console.log(elem);
    console.log(array.indexOf(elem)+"=="+index);
    console.log(array.indexOf(elem) === index);
        return array.indexOf(elem) === index;
    }
);
console.log(uniqueArray);







var medals = [
    { country:'india', medals:32 },
    { country:'US', medals:23 },
    { country:'China', medals:16 },
    { country:'Europe(ESA)', medals:7 }
];

var sum = medals.reduce(function(prevVal, elem) {
    console.log(prevVal+"---------"+elem.medals);
     console.log(prevVal + elem.medals);
        return prevVal + elem.medals;
}, 0);
var x="shaik";
console.log(x);

function f (x, y, ...a) {
    console.log(x+y);
    return (x + y) * a.length
}
f(1, 2, "hello", true, 7) === 9


var c=true;
console.log(!c);

var a=450,b=340;

f1=()=>{ console.log("helloWorld");
var res=a+b
return res;
}
var result=f1();

console.log(result)

let m=10;
var y=10;

console.log(m===y)
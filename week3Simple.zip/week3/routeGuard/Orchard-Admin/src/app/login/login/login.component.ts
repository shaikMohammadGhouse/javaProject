import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as data from '../../../assets/user.json';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  dataFromJson;


  loginForm = new FormGroup(
    {
      mid: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    }
  );

  get mid() {
    return this.loginForm.get('mid');
  }

  get password() {
    return this.loginForm.get('password');
  }

  constructor() { }

  ngOnInit() {

    window.sessionStorage.setItem('mid', '1043001');
    window.sessionStorage.setItem('password', '104');


  }

  submit() {
    window.sessionStorage.setItem('gmid', this.mid.value);
    window.sessionStorage.setItem('gpass', this.password.value);
    console.log(this.password.value);

    this.dataFromJson = data;

    for (let i = 0; i < this.dataFromJson.length; i++) {
      console.log(data[i]['MID']);
      if (this.mid.value === data[i]['MID'] && this.password.value === data[i]['password']) {
        window.sessionStorage.setItem('role', data[i]['role']);
        console.log(window.sessionStorage.getItem('role'));
      }

    }







    // if (window.sessionStorage.getItem('mid') === window.sessionStorage.getItem('gmid')) {
    //   console.log('correct mid');
    // }

    // if (window.sessionStorage.getItem('password') === window.sessionStorage.getItem('gpass')) {
    //   console.log('correct pass');
    // }

  }
}

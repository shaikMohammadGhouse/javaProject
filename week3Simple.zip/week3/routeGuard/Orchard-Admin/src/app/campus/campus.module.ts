import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CampusComponent } from './campus/campus.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CampusComponent]
})
export class CampusModule { }

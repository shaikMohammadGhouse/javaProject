import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { LoginComponent } from './login/login/login.component';
import { CampusComponent } from './campus/campus/campus.component';
import { CapabilityComponent } from './capability/capability/capability.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
 

    { path: 'login', loadChildren: './login/login.module#LoginModule' },
    { path: 'campus', loadChildren: './campus/campus.module#CampusModule' },
    {
        path: 'capability', loadChildren: './capability/capability.module#CapabilityModule',
        canActivate: [AuthGuard]
    }

]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: []

})
export class AppRoutingModule {

}

import { Component, OnInit } from '@angular/core';
import * as data from '../../../assets/capability.json';

@Component({
  selector: 'app-capability',
  templateUrl: './capability.component.html',
  styleUrls: ['./capability.component.css']
})
export class CapabilityComponent implements OnInit {

capability= data;
constructor() {

  }

  ngOnInit() {
    console.log(data);
    // console.log(data.KO);


  }

}

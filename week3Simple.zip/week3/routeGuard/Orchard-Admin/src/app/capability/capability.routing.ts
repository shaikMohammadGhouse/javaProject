import { RouterModule, Routes } from '@angular/router';
import { CapabilityComponent } from "./capability/capability.component";


const routes: Routes = [
    {
        path: '',
        component: CapabilityComponent
    }
];


export const router = RouterModule.forChild(routes);
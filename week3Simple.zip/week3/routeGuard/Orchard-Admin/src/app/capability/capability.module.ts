import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CapabilityComponent } from './capability/capability.component';
import { router } from './capability.routing';
@NgModule({
  imports: [
    CommonModule,
    router
  ],
  declarations: [CapabilityComponent]
})
export class CapabilityModule { }

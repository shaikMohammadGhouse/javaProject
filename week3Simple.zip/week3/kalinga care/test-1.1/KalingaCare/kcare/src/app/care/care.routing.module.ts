import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

import { CareComponent } from './care.component';
import { IcuComponent } from './icu/icu.component';
import { HeartComponent } from './heart/heart.component';
import { OrthopedicsComponent } from './orthopedics/orthopedics.component';
import { EmergencyComponent } from './emergency/emergency.component';


const routes: Routes = [
    { path: '', redirectTo: 'care', pathMatch: 'full' },
    { path: 'care', component: CareComponent },
    { path: 'icu', component: IcuComponent },
    { path: 'heart', component: HeartComponent },
    { path: 'orthopedics', component: OrthopedicsComponent},
    { path: 'emergency', component: EmergencyComponent}

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CareRoutingModule { }

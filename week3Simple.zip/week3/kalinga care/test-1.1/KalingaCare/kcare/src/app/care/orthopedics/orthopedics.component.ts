import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icu',
  templateUrl: './orthopedics.component.html',
  styleUrls: ['./orthopedics.component.css']
})
export class OrthopedicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

package main.drawProject;

public interface Shape 
{
	void draw();
	
}

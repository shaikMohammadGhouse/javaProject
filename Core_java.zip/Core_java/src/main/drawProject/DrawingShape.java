package main.drawProject;

public class DrawingShape 
{
	Shape shape;
	public void setShape(Shape shape) {
		this.shape = shape;
	}
	public void drawshape(Shape shape) {
		this.shape.draw();
	}

	
}

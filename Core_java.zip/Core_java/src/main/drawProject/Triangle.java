package main.drawProject;

public class Triangle implements Shape 
{

	@Override
	public void draw() {
		System.out.println("drawing triangle");
		// TODO Auto-generated method stub
		
	}
	
}

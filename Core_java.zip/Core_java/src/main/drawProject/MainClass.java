package main.drawProject;

public class MainClass {
	public static void main(String[] args) {
		
		Triangle triangle= new Triangle();
		DrawingShape ds;
		ds.setShape(triangle);
		ds.drawshape(triangle);
		
	}

}

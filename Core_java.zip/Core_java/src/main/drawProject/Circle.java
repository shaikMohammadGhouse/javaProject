package main.drawProject;

public class Circle implements Shape
{

	@Override
	public void draw() {
		
		System.out.println("drawing circle....");
		// TODO Auto-generated method stub
		
	}
	
}

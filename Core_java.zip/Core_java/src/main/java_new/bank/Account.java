package main.java_new.bank;

public interface Account 
{
	void deposit(double amount);
	void withdrawl(double amount);
	void balanceEnq();
	
	
}

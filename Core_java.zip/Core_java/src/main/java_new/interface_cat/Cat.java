package main.java_new.interface_cat;

public class Cat implements Animal
{
	public void noise()
	{
		System.out.println("its a cat dose meow meow");
	}
}

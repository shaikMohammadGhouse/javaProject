package main.java_new.interface_cat;

public interface Animal 
{
	public void noise();
}

package main.java_new.interface_cat;

public class Dog implements Animal
{
	public void noise() 
	{
		System.out.println("its a dog does bow bow..");
	}
}

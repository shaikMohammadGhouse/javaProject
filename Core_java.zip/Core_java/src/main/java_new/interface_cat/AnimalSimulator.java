package main.java_new.interface_cat;

public class AnimalSimulator 
{
	public void makeNoise(Animal a)
	{
		a.noise();
	}
}

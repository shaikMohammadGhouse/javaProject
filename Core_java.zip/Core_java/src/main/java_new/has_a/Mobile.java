package main.java_new.has_a;

public class Mobile 
{
	Battery battery=new Battery();
	
	Screen screen=new Screen();
	
	
}

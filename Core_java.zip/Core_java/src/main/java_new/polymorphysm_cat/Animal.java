package main.java_new.polymorphysm_cat;

public class Animal 
{
	public void noise() {
		
		System.out.println("all animals do noises");
	}
}

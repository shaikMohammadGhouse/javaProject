package main.java_new.polymorphysm_cat;

public class AnimalSimulator 
{
	public void makeNoise(Animal a)
	{
		a.noise();
	}
}

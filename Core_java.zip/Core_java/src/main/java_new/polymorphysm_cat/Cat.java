package main.java_new.polymorphysm_cat;

public class Cat extends Animal
{
	public void noise()
	{
		System.out.println("its a cat dose meow meow");
	}
}

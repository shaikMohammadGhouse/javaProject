package main.java_new.objectsPassing;

public class Government 
{
	public void Scholarship(Student s,double marks)
	{
			if(s.stdMarks >70)
			{
				System.out.println("elgible for scholorship....");
			}
			
			else
				System.out.println("not elgible for scholorship....");
	}
}

package main.java.operators;

public class Operators
{
		public static void main(String[] args) {
			
			boolean x=(2!=3);
			System.out.println(x);
			boolean y=!(true);
			System.out.println(y);

		
		
		//bitwise
			int m = 4 & 5;

			System.out.println(m);
		
				
			int j=0;
			do
			{
				System.out.println(j++);
			}
			while
				(j < 10);
		}

		
		
		
}

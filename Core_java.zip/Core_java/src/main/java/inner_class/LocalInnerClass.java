package main.java.inner_class;

public class LocalInnerClass 
{
	void Test()
	{
		class Sample
		{
			int a=10;
			
		}
	}
}

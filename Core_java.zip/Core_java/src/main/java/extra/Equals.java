package main.java.extra;

public class Equals
{
	public static void main(String [] args)
	{ 

	} 
}

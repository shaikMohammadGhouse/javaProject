package main.java.extra;

public class While 
{
	
	 public static void loop()
	 { 
		 int x= 0;
		 while ( true ) /* Line 6 */ 
		 {
			 System.out.print("x plus one is " + (x + 1)); /* Line 8 */ 
			 
		 } 
	 }
	public static void main(String[] args) 
	{
		loop();
	}
}



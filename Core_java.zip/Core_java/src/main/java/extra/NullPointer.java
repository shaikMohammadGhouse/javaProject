package main.java.extra;

public class NullPointer 
{
	public static void main (String args[]) 
	{
		String str = null; System.out.println(str);
		
		 float f1 = -343;
	
		 float f6 = 2.81F;
	}
}

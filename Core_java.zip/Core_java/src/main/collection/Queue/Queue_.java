package main.collection.Queue;

public class Queue_ 
{

}

package com.mindtree.Project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//
//
 @SuppressWarnings("serial")
 public class XmlServlet extends HttpServlet 
{
	
	 /*
	//Simple Request and response...
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Working doGet methode....");
		response.getWriter().print("hi iam shaik here");
		PrintWriter writer=response.getWriter();
		
		writer.println("<h1> hello this is running by GET methode <h1>");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String userName=request.getParameter("userName");
		
		out.println("hello      "+userName+"<br>");
		
		
		String phno=request.getParameter("phno");
		
		out.println(userName+"  this is ur phone number-->"+phno);
		
		
		
	}
	
	
	
	//simple request and response using session object of Apache
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter writer=response.getWriter();
		
		writer.println("Do get is running..........");
		String userName=request.getParameter("userName");
		
		writer.println("hello      "+userName+"<br>");
		
		HttpSession session=request.getSession();
		
		if(userName !="" && userName != null)
		{

		session.setAttribute("savedUserName",userName);
		}
		
		session.setAttribute("savedUserName",(String)session.getAttribute("savedUserName"));

		writer.println("Request parameter has username as --"+userName);	
		writer.println("session parameter has username as --"+(String)session.getAttribute("savedUserName"));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	*/
	
	
	

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	//using post simple request and response  
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Working doPost methode....");
		
		response.getWriter().print("hi iam shaik here");
		PrintWriter writer=response.getWriter();
		writer.println("<br>");
		writer.println(" let me run something here");
		writer.println("<h1> hello this is running by POST methode <h1>");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String userName=request.getParameter("userName");
		
		out.println("hello      "+userName+"<br>");
		
		
		String phno=request.getParameter("phno");
		
		out.println(userName+"  this is ur phone number-->"+phno);
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		String fullName=request.getParameter("fullName");
		
		System.out.println("entered full name--"+fullName);
		
		writer.println(fullName);
		
		PrintWriter write=response.getWriter();
		
		 userName=request.getParameter("userName");
		 phno=request.getParameter("phno");
		 fullName=request.getParameter("fullName");
		String profession=request.getParameter("profession");
		String location=request.getParameter("location");
		String city=request.getParameter("city");
		String vehicles[]=request.getParameterValues("vehicle");
		
		
		
		
		write.println("hello  - -- -- "+userName+"<br>");
		write.println("your full name is: - -- -- "+fullName+"<br>");
		write.println("your phone number is: - -- -- "+phno+"<br>");
		write.println("you are a  - -- -- "+profession+"<br>");
		write.println("your location is  - -- -- "+location+"<br>");
		write.println("your city is  - -- -- "+city+"<br>");
		
		
		if(vehicles.length<=1)
		write.println("your vehicle is:--");
		else
			write.println("your vehicles are:--");	
		for(int i=0;i<vehicles.length;i++)
		{
			write.println(vehicles[i]+",");
		}
	}
	
}

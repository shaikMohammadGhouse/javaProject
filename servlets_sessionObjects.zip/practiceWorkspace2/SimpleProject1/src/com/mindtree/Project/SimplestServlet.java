package com.mindtree.Project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





//using init 






 

@SuppressWarnings("serial")		

//webservlet initParameters initilaization using Anotations  
//@WebServlet(urlPatterns= {"/simpleServletProgram"} , initParams={@WebInitParam(name="defaultUser", value= "shaik mohammad")})

public class SimplestServlet extends HttpServlet 
{

	private static final long serialVersionUID=1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		PrintWriter writer=response.getWriter();
		String userName=request.getParameter("userName");
		
		HttpSession session=request.getSession();
		
		ServletContext context=request.getServletContext();
		if(userName != "" && userName != null)
		{
			session.setAttribute("savedUsername",userName);
			context.setAttribute("savedUsername",userName);
			
		}
		
		writer.println("request parameter has username.."+userName);
		writer.println("session object has username...."+(session.getAttribute("savedUsername")));
		writer.println("context object has username...."+(session.getAttribute("savedUsername")));
		response.getWriter().append("Served at: ").append(request.getContextPath());
		writer.println("Init object default username...."+this.getServletConfig().getInitParameter("defaultUser"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	
	
}

package com.mindtree;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ContextObjectProject1")
public class ContextObjectProject1 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	//simple request and response using context object of apache 
 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
 	{
		response.getWriter().append("Served at: ").append(request.getContextPath());

		PrintWriter writer=response.getWriter();
		
		writer.println("Do get is running..........");
		String userName=request.getParameter("userName");
		
		writer.println("hello      "+userName+"<br>");
		
		HttpSession session=request.getSession();					//using session object
		
		ServletContext context=request.getServletContext();			//using context object
		
		if(userName !="" && userName != null)
		{
			session.setAttribute("savedUserName",userName);			//using session object
			context.setAttribute("savedUserName",userName);			//using context object
			
		}
		
		session.setAttribute("savedUserName",(String)session.getAttribute("savedUserName"));

		writer.println("Request parameter has username as --"+userName);	
		writer.println("session parameter has username as --"+(String)session.getAttribute("savedUserName"));
		writer.println("context parameter has username as --"+(String)context.getAttribute("savedUserName"));
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter writer=response.getWriter();
		
		writer.println("Do Post is running..........");
		
	}

}

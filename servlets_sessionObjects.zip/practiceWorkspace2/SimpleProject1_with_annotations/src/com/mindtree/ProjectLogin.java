package com.mindtree;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(description = "ProjectLogin with annotations", urlPatterns = { "/projectLoginPath" })
public class ProjectLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public ProjectLogin() {
        super();

    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
		System.out.println("Working doPost methode....");
		
		response.getWriter().print("hi iam shaik here");
		PrintWriter writer=response.getWriter();
		writer.println("<br>");
		writer.println(" let me run something here");
		writer.println("<h1> hello this is running by POST methode <h1>");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String userName=request.getParameter("userName");
		
		out.println("hello      "+userName+"<br>");
		
		
		String phno=request.getParameter("phno");
		
		out.println(userName+"  this is ur phone number-->"+phno);
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		String fullName=request.getParameter("fullName");
		
		System.out.println("entered full name--"+fullName);
		
		writer.println(fullName);
		
		PrintWriter write=response.getWriter();
		
		 userName=request.getParameter("userName");
		 phno=request.getParameter("phno");
		 fullName=request.getParameter("fullName");
		String profession=request.getParameter("profession");
		String location=request.getParameter("location");
		String city=request.getParameter("city");
		String vehicles[]=request.getParameterValues("vehicle");
		
		
		
		
		write.println("hello  - -- -- "+userName+"<br>");
		write.println("your full name is: - -- -- "+fullName+"<br>");
		write.println("your phone number is: - -- -- "+phno+"<br>");
		write.println("you are a  - -- -- "+profession+"<br>");
		write.println("your location is  - -- -- "+location+"<br>");
		write.println("your city is  - -- -- "+city+"<br>");
		
		
		if(vehicles.length<=1)
		write.println("your vehicle is:--");
		else
			write.println("your vehicles are:--");	
		for(int i=0;i<vehicles.length;i++)
		{
			write.println(vehicles[i]+",");
		}
	}

}

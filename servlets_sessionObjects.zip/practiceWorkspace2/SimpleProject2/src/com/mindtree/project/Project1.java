package com.mindtree.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/Project1")

public class Project1 extends HttpServlet 
{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.getWriter().print("hi all this is servlet via get methode");
		
		String firstName=req.getParameter("firstName");
		
		System.out.println("name entered::-"+firstName);
	
		resp.getWriter().println("<br>");
		resp.getWriter().println("name entered::-"+firstName);
		
		
		String phno=req.getParameter("phno");
		System.out.println("phone no. entered is::-"+phno);
		resp.getWriter().println("phone number entered is:-"+phno);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.getWriter().print("hi all this is servlet with post methode");
		
		String firstName=req.getParameter("firstName");
		
		System.out.println("name entered::-"+firstName);
	
		resp.getWriter().println("<br>");
		resp.getWriter().println("name entered::-"+firstName);
		
		

		String phno=req.getParameter("phno");
		System.out.println("phone no. entered is::-"+phno);
		resp.getWriter().println("phone number entered is:-"+phno);
	}
}

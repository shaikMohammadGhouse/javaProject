package com.mindtree.Project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class XmlServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Working doGet methode....");
		response.getWriter().print("hi iam shaik here");
		PrintWriter writer=response.getWriter();
		
		writer.println("<h1> hello this is running by GET methode <h1>");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String userName=request.getParameter("userName");
		
		out.println("hello      "+userName+"<br>");
		
		
		String phno=request.getParameter("phno");
		
		out.println(userName+"  this is ur phone number-->"+phno);
		
		
		
	}
	
	
	
	//using post
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Working doPost methode....");
		
		response.getWriter().print("hi iam shaik here");
		PrintWriter writer=response.getWriter();
		writer.println("<br>");
		writer.println(" let me run something here");
		writer.println("<h1> hello this is running by GET methode <h1>");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String userName=request.getParameter("userName");
		
		out.println("hello      "+userName+"<br>");
		
		
		String phno=request.getParameter("phno");
		
		out.println(userName+"  this is ur phone number-->"+phno);
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
}

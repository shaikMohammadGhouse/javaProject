package com.mindtree.Login.service;

import java.util.HashMap;

import com.mindtree.Login.dto.User;

public class LoginService
{
	
	HashMap<String, String> names=new HashMap<String, String>();
	
	public LoginService() 
	{
	
		names.put("johndao","john Dao");
		names.put("shaikmohammad","shaik mohamad");
		names.put("shaik12345","shaiik 12345");
		// TODO Auto-generated constructor stub
	}
	public boolean authenticate(String userId,String password)
	{
		System.out.println("......."+userId);
		System.out.println("........"+password);
		if(password == null || password.trim() == " ")
		{
			return false;
		}
		
		else return true;
	}
	

	/*public String getuserName(String userId)
	{
		return userId;
	}*/
	
	public User getuserDetails(String userId)
	{
		
		
		//System.out.println(authenticate("shaik","s h h"));
		User user=new User();
		
		
		user.setUserName(names.get(userId));
		user.setUserId(userId);
		return user;
	}
	
}

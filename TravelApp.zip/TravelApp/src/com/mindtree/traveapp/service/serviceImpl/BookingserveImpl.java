package com.mindtree.traveapp.service.serviceImpl;

import java.util.List;

import com.mindtree.traveapp.dao.BookingInterface;
import com.mindtree.traveapp.dao.daoImpl.BookingImpl;
import com.mindtree.traveapp.entity.BookingDetails;
import com.mindtree.traveapp.entity.City;
import com.mindtree.traveapp.service.BookingInterserve;

public class BookingserveImpl implements BookingInterserve {

	@Override
	public void getSource() {
		// TODO Auto-generated method stub

	}

	@Override
	public List<BookingDetails> bookingDetail(City Destination) {
		BookingInterface booking = new BookingImpl();
		return (booking.bookingDetail(Destination));
	}

}

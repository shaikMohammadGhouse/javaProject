package com.mindtree.traveapp.service;

import java.util.List;

import com.mindtree.traveapp.entity.BookingDetails;
import com.mindtree.traveapp.entity.City;

public interface BookingInterserve {
	public void getSource();

	public List<BookingDetails> bookingDetail(City Destination);

}

package com.mindtree.traveapp.manager;

import com.mindtree.traveapp.entity.BookingDetails;
import com.mindtree.traveapp.entity.City;
import com.mindtree.traveapp.service.BookingInterserve;
import com.mindtree.traveapp.service.serviceImpl.BookingserveImpl;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String destination = "Bangalore";
		City dest = new City();
		dest.setDestination(destination);
		BookingInterserve s = new BookingserveImpl();
		for (BookingDetails book : s.bookingDetail(dest)) {
			System.out.println(book.getBookingId() + "\t" + book.getSource().getSource()) ;
		}
	}

}

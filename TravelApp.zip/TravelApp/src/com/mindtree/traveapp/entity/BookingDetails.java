package com.mindtree.traveapp.entity;

public class BookingDetails {
	private int bookingId;
	private long phoneNo;
	private City source;
	private  City destination;
	private Vehicle vehicleType;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookingId;
		return result;
	}
	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingDetails other = (BookingDetails) obj;
		if (bookingId != other.bookingId)
			return false;
		return true;
	}
	public BookingDetails(int bookingId, long phoneNo, City source, City destination, Vehicle vehicleType) {
		super();
		this.bookingId = bookingId;
		this.phoneNo = phoneNo;
		this.source = source;
		this.destination = destination;
		this.vehicleType = vehicleType;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public City getSource() {
		return source;
	}
	public void setSource(City source) {
		this.source = source;
	}
	public City getDestination() {
		return destination;
	}
	public void setDestination(City destination) {
		this.destination = destination;
	}
	public Vehicle getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(Vehicle vehicleType) {
		this.vehicleType = vehicleType;
	}

}

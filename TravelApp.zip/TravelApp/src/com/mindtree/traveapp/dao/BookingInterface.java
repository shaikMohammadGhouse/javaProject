package com.mindtree.traveapp.dao;

import java.util.List;

import com.mindtree.traveapp.entity.BookingDetails;
import com.mindtree.traveapp.entity.City;

public interface BookingInterface {
	 public  void getSource();
	 public  List<BookingDetails> bookingDetail(City Destination);

}

package com.mindtree.playeraction.utility;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.traveapp.dao.BookingInterface;
import com.mindtree.traveapp.entity.BookingDetails;
import com.mindtree.traveapp.entity.City;
import com.mindtree.traveapp.utility.DBUtility;

public class BookingImpl implements BookingInterface {

	private  Statement stat=null;
	String query=null;
	private Connection con=DBUtility.getConnect();
	@Override
	public void getSource() {
		
	}

	@Override
	public List<BookingDetails>  bookingDetail( City Destination) {
		// TODO Auto-generated method stub
		List <BookingDetails> book=new ArrayList<BookingDetails>();
		try {
			stat=con.createStatement();
			String dest = Destination.getDestination() ;
			query= "select bookingId,source from travelbooking where destination='"+dest+"'";
			ResultSet res;
			res = stat.executeQuery(query);
			while(res.next())
			 {
		BookingDetails booking = new BookingDetails();
		City source=new City();
		int booking_Id=res.getInt("bookingId");
		String source1=res.getString("Source");
		source.setSource(source1);
		booking.setSource(source);
		booking.setBookingId(booking_Id);
		book.add(booking);
				 
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return book;
		 
		
	}
}



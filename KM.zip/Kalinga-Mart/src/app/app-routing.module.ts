import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CoreModule } from "./core/core.module";
import { ViewModule } from "./view/view.module";
import { HomeComponent } from "./view/home/home.component";
import { ProductComponent } from "./view/product/product.component";
import { CartComponent } from "./view/cart/cart.component";
import { LoginComponent } from "./view/login/login.component";
import { CanActivate } from '@angular/router';

const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'home', component: HomeComponent },
     { path: 'product', component: ProductComponent },
    //{ path: 'product', canActivate: [ProductComponent] },
    { path: 'cart', component: CartComponent },
    { path: 'login', component: LoginComponent}
 
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {}

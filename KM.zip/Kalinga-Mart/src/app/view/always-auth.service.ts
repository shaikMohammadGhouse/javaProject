import { Injectable } from '@angular/core';
import { CanActivate,
         ActivatedRouteSnapshot,
         RouterStateSnapshot } from '@angular/router';
@Injectable()


export class AlwaysAuthService implements CanActivate
{
    canActivate() {
     console.log('AlwaysAuthGuard');
    return true;
    }


  constructor() { }

}

import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { ViewServiceService } from "../view-service.service";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {


   cartProducts: any =[]
    // prices:any;
    // sum:any;
     prices:any;
     sum:any;
     newPrice:any;
  constructor(private viewService : ViewServiceService) 
  {

   }

  
     
  ngOnInit() 
  {
       this.viewService.getCart().subscribe(res=>{
      this.cartProducts=res;
      // console.log(this.cartProducts);
      this.prices=this.getPrices(this.cartProducts);
      this.sum=this.prices.reduce((sum,prices)=>sum+prices);
      
      this.newPrice=this.prices.map((this.prices + 89));
       //console.log(this.newPrice);
     // this.unique=prices.filter(function(var, index,cartProducts){array.indexOf(var) === index)};
     
    });
    
  }

   getPrices(cartProducts)
   {
     //console.log(cartProducts);
     let prices=cartProducts.map(cartProducts =>cartProducts.product.price);
     //console.log(prices);
     return prices;
   }


   deleteCart(cartId)
   {
     this.viewService.deleteCart(cartId).subscribe(res=>
     {
       console.log(cartId);
     });
     window.location.reload();
   }


}

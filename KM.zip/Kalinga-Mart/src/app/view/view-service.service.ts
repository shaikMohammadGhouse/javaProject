import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class ViewServiceService {

  private headers = new Headers({ 'Content-Type': 'application/json'});
  private options= new RequestOptions({headers:this.headers});

  constructor(private http:HttpClient)
  {

   }

  //  getProducts(): Observable<any>
  //  {
  //    ret
  //  }

  addToCart(product): Observable<any>
  {
    return this.http.post('http://localhost:8081/Kmart/addtocart',product);
  }

  getCart(): Observable<any>
  {
    return this.http.get('http://localhost:8081/Kmart/cart');
  }

  deleteCart(cartId): Observable<any>
  {
    return this.http.delete('http://localhost:8081/Kmart/deletecart'+cartId);
  }

}

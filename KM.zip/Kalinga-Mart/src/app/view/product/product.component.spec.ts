import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { ProductComponent } from './product.component';
import {RouterTestingModule} from '@angular/router/testing';

fdescribe('ProductComponent', () => {
  let component: ProductComponent;

  let fixture: ComponentFixture<ProductComponent>;

  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule,RouterTestingModule],
      declarations: [ ProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });

  // it('product should empty',()=>
  // {
  //   fixture=TestBed.createComponent(ProductComponent);
  //   let product=fixture.debugElement.componentInstance;
  //   expect(product.selectedProduct).toEqual('');
  // });

  // it('products should empty',()=>
  // {
  //   fixture=TestBed.createComponent(ProductComponent);
  //   var products =fixture.debugElement.componentInstance;
  //   expect(products.products).toEqual([]);
  // });


});

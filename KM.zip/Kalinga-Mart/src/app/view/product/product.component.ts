import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ViewServiceService } from "../view-service.service";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

 products: any = [];
  selectedProduct: any= '';

  constructor(private http: HttpClient ,private router: Router,private viewService: ViewServiceService) 
  {

      this.http.get('http://localhost:8081/Kmart/getAllProducts')
      .subscribe(res => {
        this.products = res;
        console.log(this.products);
       });

  }

       addToCart(product)
       {
         this.viewService.addToCart(product).subscribe(res => {
           console.log(product);
           console.log(res);
         })
       }


      onDivert=()=>
      {
        this.router.navigate(['/cart']);
      };

        addOn=(i)=>
      {
        this.selectedProduct=this.products[i];
        console.log(this.selectedProduct);
        this.router.navigate(['/cart']);
      };
         
  ngOnInit() 
  {
      console.log(this.products);
  }


}
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CartComponent } from './cart/cart.component';
import { AppRoutingModule } from '../app-routing.module';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { ViewServiceService} from './view-service.service';
import { LoginComponent } from './login/login.component';
import { AlwaysAuthService } from './always-auth.service';


@NgModule({
  imports:[ CommonModule, AppRoutingModule],
   declarations: [ HomeComponent, CartComponent, ProductComponent, LoginComponent],
   exports: [HomeComponent, CartComponent, ProductComponent],
    providers: [ViewServiceService, AlwaysAuthService],

})
export class ViewModule { }


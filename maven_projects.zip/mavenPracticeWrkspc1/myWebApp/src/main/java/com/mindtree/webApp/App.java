package com.mindtree.webApp;

import java.util.logging.Logger;



public class App {

	public static void main(String[] args) {

		System.out.println("printing");
//		Logger logger=(Logger) LoggerFactory.getLogger(App.class);
//		
//		logger.info("hello this is shaik");

	}

}

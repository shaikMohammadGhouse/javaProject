package com.mindtree.SecondProject;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;

public class App {

	public static void main(String[] args) {

		System.out.println("printing");
		Logger logger=(Logger) LoggerFactory.getLogger(App.class);
		
		logger.info("hello this is shaik");

	}

}

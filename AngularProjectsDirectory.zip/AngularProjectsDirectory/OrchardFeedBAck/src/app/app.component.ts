import { Component } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
   
names=["AbhishekPatnaik","shaik1","shaik3"]
newName="";

mids=["M1027284","2","3"]
newMid="";

feedbacks=["good to go","good to start","hifi"]
newFeedback="";


 


onPost=()=>
  {
    if(this.newName != "")
    {
      this.names.push(this.newName);
      this.newName="";
      console.log(this.names);
    }
    if(this.newMid != "")
    {
      this.mids.push(this.newMid);
      this.newMid="";
      console.log(this.mids);
    }
    if(this.newFeedback != "")
    {
      this.feedbacks.push(this.newFeedback);
      this.newFeedback="";
      console.log(this.feedbacks)
    }
  }
  onClean()
  {
    window.location.reload();
  }

}



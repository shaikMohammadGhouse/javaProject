import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CareComponent } from './care.component';
import { CareRoutingModule } from './care.routing.module';
import { RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar/sidebar.component';
import { IcuComponent } from './icu/icu.component';  
@NgModule({
  imports: [
    CommonModule,
    CareRoutingModule,
    RouterModule
  ],
  declarations: [CareComponent,SidebarComponent,IcuComponent],
  bootstrap: [CareComponent]
})
export class CareModule { }

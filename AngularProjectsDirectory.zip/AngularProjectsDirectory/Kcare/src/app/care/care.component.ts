import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-care',
  templateUrl: './care.component.html',
  styleUrls: ['./care.component.css']
})
export class CareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

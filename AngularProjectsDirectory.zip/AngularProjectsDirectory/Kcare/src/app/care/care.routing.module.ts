import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

import { CareComponent } from './care.component';
import { IcuComponent } from './icu/icu.component';


const routes: Routes = [
    { path: '', redirectTo: 'icu', pathMatch: 'full' },
    {path:'care', component:CareComponent}
    // {path: 'icu', component: IcuComponent}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CareRoutingModule { }

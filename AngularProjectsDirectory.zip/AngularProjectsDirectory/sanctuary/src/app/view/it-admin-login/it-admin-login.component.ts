import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators,ReactiveFormsModule ,FormControl} from "@angular/forms";
import { MatButton,MatCheckbox } from "@angular/material";
import { NgModule } from '@angular/core';
@Component({
  selector: 'app-it-admin-login',
  templateUrl: './it-admin-login.component.html',
  styleUrls: ['./it-admin-login.component.css']
})
export class ItAdminLoginComponent implements OnInit {
 hide = true;
 password = new FormControl('', [Validators.required]);
 
 email = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }
 
   getErrorMessagePassword() {
    return this.password.hasError('required') ? 'You must enter a value' :
            '';
  }
 

 testForm: FormGroup;
  post:any;
 
  
  emailAlert:string = 'Valid email address needs to be entered';
  passAlert:string = 'Password should be strong';

  constructor(private fb: FormBuilder) {

   this.testForm = fb.group({
      'email': [null,Validators.compose([Validators.required, Validators.email])],
      'password': [null, Validators.compose([Validators.required,])],
      'validate' : ''
    });

  }

   ngOnInit() {

  }

  addPost(post) {
    this.password = post.password;
    this.email = post.email;
  }

  
  }


import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBookingViewComponent } from './view-booking-view.component';

describe('ViewBookingViewComponent', () => {
  let component: ViewBookingViewComponent;
  let fixture: ComponentFixture<ViewBookingViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBookingViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBookingViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

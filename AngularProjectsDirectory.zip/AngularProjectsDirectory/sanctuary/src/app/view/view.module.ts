import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeviewComponent } from './homeview/homeview.component';
import { AboutviewComponent } from './aboutview/aboutview.component';
import { AppRoutingModule } from "../app-routing.module";

import { BsDatepickerModule,TypeaheadModule } from "ngx-bootstrap";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SearchviewComponent } from './searchview/searchview.component';


import { CoreModule } from "../core/core.module";
import { AddAssetViewComponent } from './add-asset-view/add-asset-view.component';
import { ViewAssetViewComponent } from './view-asset-view/view-asset-view.component';
import { MasterDataViewComponent } from './master-data-view/master-data-view.component';
import { HotelAdminViewComponent } from './hotel-admin-view/hotel-admin-view.component';
import { ViewBookingViewComponent } from './view-booking-view/view-booking-view.component';
import { ViewAssetHotelAdminComponent } from './view-asset-hotel-admin/view-asset-hotel-admin.component';
import { ViewBookingsHotelAdminComponent } from './view-bookings-hotel-admin/view-bookings-hotel-admin.component';


import { MybookingComponent } from './mybooking/mybooking.component';
import { DeleteAssetViewComponent } from './delete-asset-view/delete-asset-view.component';


import { ItAdminLoginComponent } from './it-admin-login/it-admin-login.component';
import { HotelAdminLoginComponent } from './hotel-admin-login/hotel-admin-login.component';
import { AdminViewComponent } from "./admin-view/admin-view.component";


import {MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
} from '@angular/material';


import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ChooseAmenitiesViewComponent } from './choose-amenities-view/choose-amenities-view.component';
import { HotelAmenitiesFormComponent } from './hotel-amenities-form/hotel-amenities-form.component';
import { AssetAmenitiesFormComponent } from './asset-amenities-form/asset-amenities-form.component';

@NgModule({
  imports: [
    MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
  
    CommonModule,
    AppRoutingModule,
    BsDatepickerModule.forRoot(),
    TypeaheadModule.forRoot(),
    FormsModule,
    CoreModule,
    ReactiveFormsModule,

    

    MatButtonModule,
    MatMenuModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,

   
  ],
  declarations: [ 
    HomeviewComponent, 
    AboutviewComponent, 
    SearchviewComponent,
    AdminViewComponent,
    
    AddAssetViewComponent, 
    ViewAssetViewComponent, 
    MasterDataViewComponent,
    HotelAdminViewComponent,
    ViewBookingViewComponent,
    ViewAssetHotelAdminComponent,
    ViewBookingsHotelAdminComponent,


    AboutviewComponent, SearchviewComponent, MybookingComponent, ItAdminLoginComponent, HotelAdminLoginComponent
    ,SearchviewComponent, MybookingComponent, DeleteAssetViewComponent, ChooseAmenitiesViewComponent, HotelAmenitiesFormComponent, AssetAmenitiesFormComponent, 
    ],
  exports: [
    MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
    
        HomeviewComponent,
        AboutviewComponent,
        AppRoutingModule,
        AddAssetViewComponent, 
        ViewAssetViewComponent, 
        DeleteAssetViewComponent,
        MasterDataViewComponent,
        ViewAssetHotelAdminComponent,
        ViewBookingsHotelAdminComponent,
        FormsModule,
        CoreModule,
        HotelAmenitiesFormComponent, 
        AssetAmenitiesFormComponent,
  
    ],
    providers: [
        
    ],

})
export class ViewModule { }

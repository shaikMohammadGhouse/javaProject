import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChooseAmenitiesViewComponent } from './choose-amenities-view.component';

describe('ChooseAmenitiesViewComponent', () => {
  let component: ChooseAmenitiesViewComponent;
  let fixture: ComponentFixture<ChooseAmenitiesViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChooseAmenitiesViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChooseAmenitiesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelAdminLoginComponent } from './hotel-admin-login.component';

describe('HotelAdminLoginComponent', () => {
  let component: HotelAdminLoginComponent;
  let fixture: ComponentFixture<HotelAdminLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HotelAdminLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelAdminLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

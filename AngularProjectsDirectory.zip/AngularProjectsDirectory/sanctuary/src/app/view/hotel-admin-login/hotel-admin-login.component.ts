import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators ,ReactiveFormsModule } from "@angular/forms";
@Component({
  selector: 'app-hotel-admin-login',
  templateUrl: './hotel-admin-login.component.html',
  styleUrls: ['./hotel-admin-login.component.css']
})
export class HotelAdminLoginComponent implements OnInit {

  testForm: FormGroup;
  post:any;                     
  password:string = '';
  email:string = '';
  emailAlert:string = 'Valid email address needs to be entered';
  passAlert:string = 'Valid password should  be entered';

  constructor(private fb: FormBuilder) {

   this.testForm = fb.group({
      'email': [null,Validators.compose([Validators.required, Validators.email])],
      'password': [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(15),Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/ )])],
      'validate' : ''
    });

  }

   ngOnInit() {

  }

  addPost(post) {
    this.password = post.password;
    this.email = post.email;
  }

  
  }



import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBookingsHotelAdminComponent } from './view-bookings-hotel-admin.component';

describe('ViewBookingsHotelAdminComponent', () => {
  let component: ViewBookingsHotelAdminComponent;
  let fixture: ComponentFixture<ViewBookingsHotelAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBookingsHotelAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBookingsHotelAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

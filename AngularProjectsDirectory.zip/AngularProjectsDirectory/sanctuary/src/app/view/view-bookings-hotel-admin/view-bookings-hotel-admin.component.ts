import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-bookings-hotel-admin',
  templateUrl: './view-bookings-hotel-admin.component.html',
  styleUrls: ['./view-bookings-hotel-admin.component.css']
})
export class ViewBookingsHotelAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

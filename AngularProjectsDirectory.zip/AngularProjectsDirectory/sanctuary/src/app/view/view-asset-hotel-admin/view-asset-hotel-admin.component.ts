import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-asset-hotel-admin',
  templateUrl: './view-asset-hotel-admin.component.html',
  styleUrls: ['./view-asset-hotel-admin.component.css']
})
export class ViewAssetHotelAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

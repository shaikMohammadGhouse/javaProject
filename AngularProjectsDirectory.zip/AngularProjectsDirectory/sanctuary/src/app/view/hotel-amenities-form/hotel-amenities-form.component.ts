import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HotelAmenities } from '../../models/hotel-amenities';
import { Http } from '@angular/http';


@Component({
  selector: 'app-hotel-amenities-form',
  templateUrl: './hotel-amenities-form.component.html',
  styleUrls: ['./hotel-amenities-form.component.css']
})
export class HotelAmenitiesFormComponent implements OnInit {

hotelbasicAmenities = new HotelAmenities() ;



  hotelAmenities = new FormGroup({
    hasAccomodation: new FormControl('', []),
    multiLinguaStaff: new FormControl('', []),
    suppLanguages: new FormControl('', []),
    siteSecurity: new FormControl('', [])
  });

  get hasAccomodation() {
    return this.hotelAmenities.get('hasAccomodation');
  }

  get multiLinguaStaff() {
    return this.hotelAmenities.get('multiLinguaStaff');
  }

  get suppLanguages() {
    return this.hotelAmenities.get('suppLanguages');
  }

  get siteSecurity() {
    return this.hotelAmenities.get('siteSecurity');
  }




  recreationalActivities = new FormGroup({
    tennis: new FormControl('', []),
    waterSports: new FormControl('', []),
    steamRoom: new FormControl('', []),
    spa: new FormControl('', []),
    snooker: new FormControl('', []),
    solarium: new FormControl('', []),
    winterSports: new FormControl('', []),
    shooting: new FormControl('', []),
    sauna: new FormControl('', []),
    fishing: new FormControl('', []),
    golf: new FormControl('', []),
    croquet: new FormControl('', []),
    bowls: new FormControl('', []),
    badminton: new FormControl('', []),
    gym: new FormControl('', []),
    healthClub: new FormControl('', []),
    outdoorSwimmingPool: new FormControl('', []),
    jacuzzi: new FormControl('', []),
    indoorSwimmingPool: new FormControl('', []),
    horseRiding: new FormControl('', []),
    archery: new FormControl('', [])
  });

  get tennis() {
    return this.recreationalActivities.get('tennis');
  }
  get waterSports() {
    return this.recreationalActivities.get('waterSports');
  }
  get steamRoom() {
    return this.recreationalActivities.get('steamRoom');
  }
  get spa() {
    return this.recreationalActivities.get('spa');
  }
  get snooker() {
    return this.recreationalActivities.get('snooker');
  }
  get solarium() {
    return this.recreationalActivities.get('solarium');
  }
  get shooting() {
    return this.recreationalActivities.get('shooting');
  }
  get winterSports() {
    return this.recreationalActivities.get('winterSports');
  }
  get sauna() {
    return this.recreationalActivities.get('sauna');
  }
  get fishing() {
    return this.recreationalActivities.get('fishing');
  }
  get golf() {
    return this.recreationalActivities.get('golf');
  }
  get croquet() {
    return this.recreationalActivities.get('croquet');
  }
  get bowls() {
    return this.recreationalActivities.get('bowls');
  }
  get badminton() {
    return this.recreationalActivities.get('badminton');
  }
  get gym() {
    return this.recreationalActivities.get('gym');
  }
  get healthClub() {
    return this.recreationalActivities.get('healthClub');
  }
  get outdoorSwimmingPool() {
    return this.recreationalActivities.get('outdoorSwimmingPool');
  }
  get jacuzzi() {
    return this.recreationalActivities.get('jacuzzi');
  }
  get indoorSwimmingPool() {
    return this.recreationalActivities.get('indoorSwimmingPool');
  }
  get horseRiding() {
    return this.recreationalActivities.get('horseRiding');
  }
  get archery() {
    return this.recreationalActivities.get('archery');
  }









  parking = new FormGroup({
    coachParking: new FormControl('', []),
    freeOffSiteParking: new FormControl('', []),
    freeOnSiteParking: new FormControl('', []),

    offSiteParkingWithFee: new FormControl('', []),
    unitOfMeasureOffSiteParking: new FormControl('', []),
    unitOfMeasureOffSiteParkingPrice: new FormControl('', []),

    onSiteParkingWithFee: new FormControl('', []),
    unitOfMeasureOnSiteParking: new FormControl('', []),
    unitOfMeasureOnSiteParkingPrice: new FormControl('', [])
  });

  get coachParking() {
    return this.parking.get('coachParking');
  }
  get freeOffSiteParking() {
    return this.parking.get('freeOffSiteParking');
  }
  get freeOnSiteParking() {
    return this.parking.get('freeOnSiteParking');
  }
  get offSiteParkingWithFee() {
    return this.parking.get('offSiteParkingWithFee');
  }
  get unitOfMeasureOffSiteParking() {
    return this.parking.get('unitOfMeasureOffSiteParking');
  }
  get unitOfMeasureOffSiteParkingPrice() {
    return this.parking.get('unitOfMeasureOffSiteParkingPrice');
  }
  get onSiteParkingWithFee() {
    return this.parking.get('onSiteParkingWithFee');
  }
  get unitOfMeasureOnSiteParking() {
    return this.parking.get('unitOfMeasureOnSiteParking');
  }
  get unitOfMeasureOnSiteParkingPrice() {
    return this.parking.get('unitOfMeasureOnSiteParkingPrice');
  }

  transportOption = new FormGroup({
    publicTransport: new FormControl('', []),
    limuousineService: new FormControl('', []),
    shuttleBus: new FormControl('', []),
    taxiService: new FormControl('', [])
  });

  get publicTransport() {
    return this.transportOption.get('publicTransport');
  }
  get limuousineService() {
    return this.transportOption.get('limuousineService');
  }
  get shuttleBus() {
    return this.transportOption.get('shuttleBus');
  }
  get taxiService() {
    return this.transportOption.get('taxiService');
  }

  additionalAmenities = new FormGroup({
    tailor: new FormControl('', []),
    terrace: new FormControl('', []),
    restaurant: new FormControl('', []),
    medicalFacility: new FormControl('', []),
    luggageStorage: new FormControl('', []),
    laundryService: new FormControl('', []),
    businessCentre: new FormControl('', []),
    cloakroomService: new FormControl('', []),
    bedRooms: new FormControl('', []),
    rampAccess: new FormControl('', []),
    bar: new FormControl('', []),
    ballRoom: new FormControl('', []),
    concierge: new FormControl('', []),
    disabledFacilities: new FormControl('', []),
    heating: new FormControl('', []),
    helipad: new FormControl('', []),
    garden: new FormControl('', []),
    freeWifi: new FormControl('', []),
    elevator: new FormControl('', []),
    frontDesk: new FormControl('', [])
  });


  get tailor() {
    return this.additionalAmenities.get('tailor');
  }
  get terrace() {
    return this.additionalAmenities.get('terrace');
  }
  get restaurant() {
    return this.additionalAmenities.get('restaurant');
  }
  get medicalFacility() {
    return this.additionalAmenities.get('medicalFacility');
  }
  get luggageStorage() {
    return this.additionalAmenities.get('luggageStorage');
  }
  get laundryService() {
    return this.additionalAmenities.get('laundryService');
  }
  get businessCentre() {
    return this.additionalAmenities.get('businessCentre');
  }
  get cloakroomService() {
    return this.additionalAmenities.get('cloakroomService');
  }
  get bedRooms() {
    return this.additionalAmenities.get('bedRooms');
  }
  get rampAccess() {
    return this.additionalAmenities.get('rampAccess');
  }
  get bar() {
    return this.additionalAmenities.get('bar');
  }
  get ballRoom() {
    return this.additionalAmenities.get('ballRoom');
  }
  get concierge() {
    return this.additionalAmenities.get('concierge');
  }
  get disabledFacilities() {
    return this.additionalAmenities.get('disabledFacilities');
  }
  get heating() {
    return this.additionalAmenities.get('heating');
  }
  get helipad() {
    return this.additionalAmenities.get('helipad');
  }
  get garden() {
    return this.additionalAmenities.get('garden');
  }
  get freeWifi() {
    return this.additionalAmenities.get('freeWifi');
  }
  get elevator() {
    return this.additionalAmenities.get('elevator');
  }
  get frontDesk() {
    return this.additionalAmenities.get('frontDesk');
  }



  hotelDetails = new FormGroup({
    shoppingArea: new FormControl('', []),
    closeToNature: new FormControl('', []),
    countrySide: new FormControl('', []),
    inTheAirport: new FormControl('', []),
    inTheCentre: new FormControl('', []),
    nearAirport: new FormControl('', []),
    nearAttractions: new FormControl('', []),
    nearHarbor: new FormControl('', []),
    nearMotorway: new FormControl('', []),
    nearRailwayStation: new FormControl('', []),
    nearTheCentre: new FormControl('', []),
    nearByWater: new FormControl('', []),
    suburbs: new FormControl('', [])
  });


  get shoppingArea() {
    return this.hotelDetails.get('shoppingArea');
  }
  get closeToNature() {
    return this.hotelDetails.get('closeToNature');
  }
  get countrySide() {
    return this.hotelDetails.get('countrySide');
  }
  get inTheAirport() {
    return this.hotelDetails.get('inTheAirport');
  }
  get inTheCentre() {
    return this.hotelDetails.get('inTheCentre');
  }
  get nearAirport() {
    return this.hotelDetails.get('nearAirport');
  }
  get nearAttractions() {
    return this.hotelDetails.get('nearAttractions');
  }
  get nearHarbor() {
    return this.hotelDetails.get('nearHarbor');
  }
  get nearMotorway() {
    return this.hotelDetails.get('nearMotorway');
  }
  get nearRailwayStation() {
    return this.hotelDetails.get('nearRailwayStation');
  }
  get nearTheCentre() {
    return this.hotelDetails.get('nearTheCentre');
  }
  get nearByWater() {
    return this.hotelDetails.get('nearByWater');
  }
  get suburbs() {
    return this.hotelDetails.get('suburbs');
  }





  drinks = new FormGroup({
    oneTeaBreak: new FormControl('', []),
    oneTeaBreakService: new FormControl('', []),
    twoTeaBreak: new FormControl('', []),
    twoTeaBreakService: new FormControl('', []),
    threeTeaBreak: new FormControl('', []),
    threeTeaBreakService: new FormControl('', []),
    unlimitedTea: new FormControl('', []),
    unlimitedTeaService: new FormControl('', []),
    alcoholicBeverages: new FormControl('', []),
    alcoholicBeveragesService: new FormControl('', []),
    coldBeverages: new FormControl('', []),
    coldBeveragesService: new FormControl('', []),
    hotBeverages: new FormControl('', []),
    hotBeveragesService: new FormControl('', []),
    stillWater: new FormControl('', []),
    stillWaterService: new FormControl('', [])
  });

  get oneTeaBreak() {
    return this.drinks.get('oneTeaBreak');
  }
  get oneTeaBreakService() {
    return this.drinks.get('oneTeaBreakService');
  }
  get twoTeaBreak() {
    return this.drinks.get('twoTeaBreak');
  }
  get twoTeaBreakService() {
    return this.drinks.get('twoTeaBreakService');
  }
  get threeTeaBreak() {
    return this.drinks.get('threeTeaBreak');
  }
  get threeTeaBreakService() {
    return this.drinks.get('threeTeaBreakService');
  }
  get unlimitedTea() {
    return this.drinks.get('unlimitedTea');
  }
  get unlimitedTeaService() {
    return this.drinks.get('unlimitedTeaService');
  }
  get alcoholicBeverages() {
    return this.drinks.get('alcoholicBeverages');
  }
  get alcoholicBeveragesService() {
    return this.drinks.get('alcoholicBeveragesService');
  }
  get coldBeverages() {
    return this.drinks.get('coldBeverages');
  }
  get coldBeveragesService() {
    return this.drinks.get('coldBeveragesService');
  }
  get hotBeverages() {
    return this.drinks.get('hotBeverages');
  }
  get hotBeveragesService() {
    return this.drinks.get('hotBeveragesService');
  }
  get stillWater() {
    return this.drinks.get('stillWater');
  }
  get stillWaterService() {
    return this.drinks.get('stillWaterService');
  }




  breakfast = new FormGroup({
    twoBreakfast: new FormControl('', []),
    twoBreakfastService: new FormControl('', []),
    fullBreakfast: new FormControl('', []),
    fullBreakfastService: new FormControl('',[])
  });

  get twoBreakfast() {
    return this.breakfast.get('twoBreakfast');
  }
  get twoBreakfastService() {
    return this.breakfast.get('twoBreakfastService');
  }

  get fullBreakfast() {
    return this.breakfast.get('fullBreakfast');
  }
get fullBreakfastService() {
    return this.breakfast.get('fullBreakfastService');
  }



  lunch = new FormGroup({
    lunchBuffet: new FormControl('', []),
    lunchBuffetService: new FormControl('', []),
    lunchAlaCarte: new FormControl('', []),
    lunchAlaCarteService: new FormControl('', []),
    twoCourseMenu: new FormControl('', []),
    twoCourseMenuService: new FormControl('', []),
    buffetLunch: new FormControl('', []),
    buffetLunchService: new FormControl('', []),
    twoLunchAlaCarte: new FormControl('', []),
    twoLunchAlaCarteService: new FormControl('', []),
    twoLunchBuffet: new FormControl('', []),
    twoLunchBuffetService: new FormControl('', []),
    threeCourseLunch: new FormControl('', []),
    threeCourseLunchService: new FormControl('', [])
  });

  get lunchBuffet(){
    return this.lunch.get('lunchBuffet');
  }
    get lunchBuffetService(){
      return this.lunch.get('lunchBuffetService');
    }
    get lunchAlaCarte(){
      return this.lunch.get('lunchAlaCarte');
    }
    get lunchAlaCarteService(){
      return this.lunch.get('lunchAlaCarteService');
    }
    get twoCourseMenu(){
      return this.lunch.get('twoCourseMenu');
    }
    get twoCourseMenuService(){
      return this.lunch.get('twoCourseMenuService');
    }
    get buffetLunch(){
      return this.lunch.get('buffetLunch');
    }
    get buffetLunchService(){
      return this.lunch.get('buffetLunchService');
    }
    get twoLunchAlaCarte(){
      return this.lunch.get('twoLunchAlaCarte');
    }
    get twoLunchAlaCarteService(){
      return this.lunch.get('twoLunchAlaCarteService');
    }
    get twoLunchBuffet(){
      return this.lunch.get('twoLunchBuffet');
    }
    get twoLunchBuffetService(){
      return this.lunch.get('twoLunchBuffetService');
    }
    get threeCourseLunch(){
      return this.lunch.get('threeCourseLunch');
    }
    get threeCourseLunchService(){
      return this.lunch.get('threeCourseLunchService');
    }

  dinner = new FormGroup({
    supper: new FormControl('', []),
    supperService: new FormControl('', []),
    threeCourseDinner: new FormControl('', []),
    threeCourseDinnerService: new FormControl('', [])
  });

  get supper() {
    return this.dinner.get('supper');
  }

  get supperService() {
    return this.dinner.get('supperService');
  }

  get threeCourseDinner() {
    return this.dinner.get('threeCourseDinner');
  }

  get threeCourseDinnerService() {
    return this.dinner.get('threeCourseDinnerService');
  }



  allday = new FormGroup({
    snacks: new FormControl('', []),
    freshFruits: new FormControl('', [])
  });

   get snacks() {
    return this.dinner.get('snacks');
  }

  get freshFruits() {
    return this.dinner.get('freshFruits');
  }



  constructor(private http: Http) { }

  ngOnInit() {
  }


  onSubmit() {
    alert("Data Submitted Successfully");
    window.location.reload();
    this.hotelbasicAmenities.hotelName = '1';
    this.hotelbasicAmenities.hasAccomodation = this.hotelAmenities.get('hasAccomodation').value;
    this.hotelbasicAmenities.multiLinguaStaff = this.hotelAmenities.get('multiLinguaStaff').value;
    this.hotelbasicAmenities.suppLanguages = this.hotelAmenities.get('suppLanguages').value;
    this.hotelbasicAmenities.siteSecurity = this.hotelAmenities.get('siteSecurity').value;


  this.hotelbasicAmenities.multiLinguaStaff = this.recreationalActivities.get('tennis').value;
  this.hotelbasicAmenities.multiLinguaStaff = this.recreationalActivities.get('waterSports').value;
  this.hotelbasicAmenities.steamRoom = this.recreationalActivities.get('steamRoom').value;
  this.hotelbasicAmenities.spa = this.recreationalActivities.get('spa').value;
  this.hotelbasicAmenities.snooker = this.recreationalActivities.get('snooker').value;
  this.hotelbasicAmenities.solarium = this.recreationalActivities.get('solarium').value;
this.hotelbasicAmenities.winterSports = this.recreationalActivities.get('winterSports').value;
  this.hotelbasicAmenities.shooting = this.recreationalActivities.get('shooting').value;
  this.hotelbasicAmenities.sauna = this.recreationalActivities.get('sauna').value;
this.hotelbasicAmenities.fishing = this.recreationalActivities.get('fishing').value;
  this.hotelbasicAmenities.golf = this.recreationalActivities.get('golf').value;
  this.hotelbasicAmenities.croquet = this.recreationalActivities.get('croquet').value;
this.hotelbasicAmenities.bowls = this.recreationalActivities.get('bowls').value;
  this.hotelbasicAmenities.badminton = this.recreationalActivities.get('badminton').value;
  this.hotelbasicAmenities.gym = this.recreationalActivities.get('gym').value;
this.hotelbasicAmenities.healthClub = this.recreationalActivities.get('healthClub').value;
  this.hotelbasicAmenities.outdoorSwimmingPool = this.recreationalActivities.get('outdoorSwimmingPool').value;
  this.hotelbasicAmenities.jacuzzi = this.recreationalActivities.get('jacuzzi').value;
this.hotelbasicAmenities.indoorSwimmingPool = this.recreationalActivities.get('indoorSwimmingPool').value;
  this.hotelbasicAmenities.horseRiding = this.recreationalActivities.get('horseRiding').value;
  this.hotelbasicAmenities.archery = this.recreationalActivities.get('archery').value;

  this.hotelbasicAmenities.coachParking = this.parking.get('coachParking').value;
   this.hotelbasicAmenities.freeOffSiteParking = this.parking.get('freeOffSiteParking').value;
    this.hotelbasicAmenities.freeOnSiteParking = this.parking.get('freeOnSiteParking').value;
     this.hotelbasicAmenities.offSiteParkingWithFee = this.parking.get('offSiteParkingWithFee').value ;
      this.hotelbasicAmenities.unitOfMeasureOffSiteParking = this.parking.get('unitOfMeasureOffSiteParking').value; 
this.hotelbasicAmenities.unitOfMeasureOffSiteParkingPrice = this.parking.get('unitOfMeasureOffSiteParkingPrice').value; 
this.hotelbasicAmenities.onSiteParkingWithFee = this.parking.get('onSiteParkingWithFee').value;
      this.hotelbasicAmenities.unitOfMeasureOnSiteParking = this.parking.get('unitOfMeasureOnSiteParking').value; 
this.hotelbasicAmenities.unitOfMeasureOnSiteParkingPrice = this.parking.get('unitOfMeasureOnSiteParkingPrice').value; 



 this.hotelbasicAmenities.publicTransport = this.transportOption.get('publicTransport').value; 
  this.hotelbasicAmenities.limuousineService = this.transportOption.get('limuousineService').value; 
   this.hotelbasicAmenities.shuttleBus = this.transportOption.get('shuttleBus').value; 
    this.hotelbasicAmenities.taxiService = this.transportOption.get('taxiService').value; 


this.hotelbasicAmenities.tailor = this.additionalAmenities.get('tailor').value; 
this.hotelbasicAmenities.terrace = this.additionalAmenities.get('terrace').value; 
this.hotelbasicAmenities.restaurant = this.additionalAmenities.get('restaurant').value; 
this.hotelbasicAmenities.medicalFacility = this.additionalAmenities.get('medicalFacility').value; 
this.hotelbasicAmenities.luggageStorage = this.additionalAmenities.get('luggageStorage').value; 
this.hotelbasicAmenities.laundryService = this.additionalAmenities.get('laundryService').value; 
this.hotelbasicAmenities.businessCentre = this.additionalAmenities.get('businessCentre').value; 
this.hotelbasicAmenities.cloakroomService = this.additionalAmenities.get('cloakroomService').value; 
this.hotelbasicAmenities.bedRooms = this.additionalAmenities.get('bedRooms').value; 
this.hotelbasicAmenities.rampAccess = this.additionalAmenities.get('rampAccess').value; 
this.hotelbasicAmenities.bar = this.additionalAmenities.get('bar').value; 
this.hotelbasicAmenities.ballRoom = this.additionalAmenities.get('ballRoom').value; 
this.hotelbasicAmenities.concierge = this.additionalAmenities.get('concierge').value; 
this.hotelbasicAmenities.disabledFacilities = this.additionalAmenities.get('disabledFacilities').value; 
this.hotelbasicAmenities.heating = this.additionalAmenities.get('heating').value; 
this.hotelbasicAmenities.helipad = this.additionalAmenities.get('helipad').value; 
this.hotelbasicAmenities.garden = this.additionalAmenities.get('garden').value; 
this.hotelbasicAmenities.freeWifi = this.additionalAmenities.get('freeWifi').value; 
this.hotelbasicAmenities.elevator = this.additionalAmenities.get('elevator').value; 
this.hotelbasicAmenities.frontDesk = this.additionalAmenities.get('frontDesk').value; 



this.hotelbasicAmenities.shoppingArea = this.hotelDetails.get('shoppingArea').value; 
this.hotelbasicAmenities.closeToNature = this.hotelDetails.get('closeToNature').value; 
this.hotelbasicAmenities.countrySide = this.hotelDetails.get('countrySide').value; 
this.hotelbasicAmenities.inTheAirport = this.hotelDetails.get('inTheAirport').value; 
this.hotelbasicAmenities.inTheCentre = this.hotelDetails.get('inTheCentre').value; 
this.hotelbasicAmenities. nearAirport = this.hotelDetails.get('nearAirport').value; 
this.hotelbasicAmenities.nearAttractions = this.hotelDetails.get('nearAttractions').value; 
this.hotelbasicAmenities.nearHarbor = this.hotelDetails.get('nearHarbor').value; 
this.hotelbasicAmenities.nearMotorway = this.hotelDetails.get('nearMotorway').value; 
this.hotelbasicAmenities.nearRailwayStation = this.hotelDetails.get('nearRailwayStation').value; 
this.hotelbasicAmenities.nearTheCentre = this.hotelDetails.get('nearTheCentre').value; 
this.hotelbasicAmenities.nearByWater = this.hotelDetails.get('nearByWater').value; 
this.hotelbasicAmenities.suburbs = this.hotelDetails.get('suburbs').value; 



this.hotelbasicAmenities.oneTeaBreak = this.drinks.get('oneTeaBreak').value; 
this.hotelbasicAmenities.oneTeaBreakService = this.drinks.get('oneTeaBreakService').value; 
this.hotelbasicAmenities.twoTeaBreak = this.drinks.get('twoTeaBreak').value; 
this.hotelbasicAmenities.twoTeaBreakService = this.drinks.get('twoTeaBreakService').value; 
this.hotelbasicAmenities.threeTeaBreak = this.drinks.get('threeTeaBreak').value; 
this.hotelbasicAmenities.threeTeaBreakService = this.drinks.get('threeTeaBreakService').value; 
this.hotelbasicAmenities.unlimitedTea = this.drinks.get('unlimitedTea').value; 
this.hotelbasicAmenities.unlimitedTeaService = this.drinks.get('unlimitedTeaService').value; 
this.hotelbasicAmenities.alcoholicBeverages = this.drinks.get('alcoholicBeverages').value; 
this.hotelbasicAmenities.alcoholicBeveragesService = this.drinks.get('alcoholicBeveragesService').value; 
this.hotelbasicAmenities.coldBeverages = this.drinks.get('coldBeverages').value; 
this.hotelbasicAmenities.coldBeveragesService = this.drinks.get('coldBeveragesService').value; 
this.hotelbasicAmenities.hotBeverages = this.drinks.get('hotBeverages').value; 
this.hotelbasicAmenities.hotBeveragesService = this.drinks.get('hotBeveragesService').value; 
this.hotelbasicAmenities.stillWater = this.drinks.get('stillWater').value; 
this.hotelbasicAmenities.stillWaterService = this.drinks.get('stillWaterService').value; 



this.hotelbasicAmenities.twoBreakfast = this.breakfast.get('twoBreakfast').value; 
this.hotelbasicAmenities.twoBreakfastService = this.breakfast.get('twoBreakfastService').value; 
this.hotelbasicAmenities.fullBreakfast = this.breakfast.get('fullBreakfast').value; 


this.hotelbasicAmenities.lunchBuffet = this.lunch.get('lunchBuffet').value; 
this.hotelbasicAmenities.lunchBuffetService = this.lunch.get('lunchBuffetService').value; 
this.hotelbasicAmenities.lunchAlaCarte = this.lunch.get('lunchAlaCarte').value; 
this.hotelbasicAmenities.lunchAlaCarteService = this.lunch.get('lunchAlaCarteService').value; 
this.hotelbasicAmenities.twoCourseMenu = this.lunch.get('twoCourseMenu').value; 

this.hotelbasicAmenities.twoCourseMenuService = this.lunch.get('twoCourseMenuService').value; 
this.hotelbasicAmenities.buffetLunch = this.lunch.get('buffetLunch').value; 
this.hotelbasicAmenities.buffetLunchService = this.lunch.get('buffetLunchService').value; 
this.hotelbasicAmenities.twoLunchAlaCarteService = this.lunch.get('twoLunchAlaCarteService').value; 
this.hotelbasicAmenities.twoLunchBuffet = this.lunch.get('twoLunchBuffet').value; 
this.hotelbasicAmenities.twoLunchBuffetService = this.lunch.get('twoLunchBuffetService').value; 
this.hotelbasicAmenities.threeCourseLunchService = this.lunch.get('threeCourseLunchService').value; 



this.hotelbasicAmenities.supper = this.dinner.get('supper').value; 
this.hotelbasicAmenities.supperService = this.dinner.get('supperService').value; 
this.hotelbasicAmenities.threeCourseDinner = this.dinner.get('threeCourseDinner').value; 
this.hotelbasicAmenities.threeCourseDinnerService = this.dinner.get('threeCourseDinnerService').value; 


this.hotelbasicAmenities.snacks = this.allday.get('snacks').value; 
this.hotelbasicAmenities.freshFruits = this.allday.get('freshFruits').value; 


this.http.post("https://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/itadmin/addhotelamenities/",this.hotelbasicAmenities)
    .subscribe(
      res => {
      console.log(res);
    })


  }
}

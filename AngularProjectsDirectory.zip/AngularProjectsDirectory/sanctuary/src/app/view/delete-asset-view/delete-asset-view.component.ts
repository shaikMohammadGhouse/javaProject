import { Component, OnInit } from '@angular/core';
import { Attribute } from "../../service/attributes";
import { AttributeService } from "../../service/attribute.service";
import { clone } from 'lodash';

@Component({
  selector: 'app-delete-asset-view',
  templateUrl: './delete-asset-view.component.html',
  styleUrls: ['./delete-asset-view.component.css']
})
export class DeleteAssetViewComponent implements OnInit {

   products: Attribute[];
  productForm: boolean = false;
  editProductForm: boolean = false;
  isNewForm: boolean;
  newProduct: any = {};
  editedProduct: any = {};
  
  constructor(private _attributeService: AttributeService) { }

  ngOnInit() {
    this.getProducts();
  }

  getProducts() {
    this.products = this._attributeService.getProductsFromData();
  }

  showEditProductForm(product: Attribute) {
    if(!product) {
      this.productForm = false;
      return;
    }
    this.editProductForm = true;
    this.editedProduct = clone(product);
  }

  showAddProductForm() {
    // resets form if edited product
    if(this.products.length) {
      this.newProduct = {};
    }
    this.productForm = true;
    this.isNewForm = true;
  }

  saveProduct(product: Attribute) {
    if(this.isNewForm) {
      // add a new product
      this._attributeService.addProduct(product);
    }
    this.productForm = false;
  }

  removeProduct(product: Attribute) {
    this._attributeService.deleteProduct(product);
  }

  updateProduct() {
    this._attributeService.updateProduct(this.editedProduct);
    this.editProductForm = false;
    this.editedProduct = {};
  }

  cancelNewProduct() {
    this.newProduct = {};
    this.productForm = false;
  }

  cancelEdits() {
    this.editedProduct = {};
    this.editProductForm = false;
  }


}


import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { clone } from 'lodash';

@Component({
  selector: 'app-add-asset-view',
  templateUrl: './add-asset-view.component.html',
  styleUrls: ['./add-asset-view.component.css']
})
export class AddAssetViewComponent implements OnInit {

  locations: any =[];

  hotels: any=[];
  
  constructor(private http:Http) { }

  ngOnInit() {
    this.http.get("https://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/itadmin/location")
    .subscribe(
      res => {
      console.log(res);
      this.locations=res.json();

    });
    this.http.get("https://sanctuary-api-qa-jvn.azurewebsites.net/MeetEx/itadmin/hotel")
    .subscribe(
      res1 => {
        console.log(res1);
        this.hotels=res1.json();
      });
  }


 
}

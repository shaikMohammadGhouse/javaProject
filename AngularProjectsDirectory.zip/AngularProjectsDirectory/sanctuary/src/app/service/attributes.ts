export interface Attribute {
  id: number;
  name: string;
  price: number;
  currentActiveBooking: Number;
  hotelName: string;
}
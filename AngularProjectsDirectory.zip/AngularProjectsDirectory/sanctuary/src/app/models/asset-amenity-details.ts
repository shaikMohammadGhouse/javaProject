export class AssetAmenityDetails{
    assetName: any;
    assetType: any;
    locationInHotel: any;
    length: any;
    width: any;
    height: any;
    noOfGuest: any;
    unitOfMeasure: any;
    unitPrice: any;


    acRadio: any;
    airConditionerUnitOfMeasure: any;
    airConditionerUnitPrice:any;

    lecternRadio: any;
    lecternUnitOfMeasure: any;
    lecternUnitPrice: any;
    lecternQuantifcication: any;

    roomControlRadio: any;
    roomControlUnitOfMeasure: any;
    roomControlUnitPrice: any;
    
    stagingRadio: any;
    stagingUnitOfMeasure: any;
    stagingUnitPrice: any;
    
    underFloorHeatingRadio: any;
    underFloorHeatingUnitOfMeasure: any;
    underFloorHeatingUnitPrice: any;


    amplifierRadio: any;
    amplifierUnitOfMeasure: any;
    amplifierUnitPrice: any;
    
    autoCueRadio: any;
    autoCueUnitOfMeasure: any;
    autoCueUnitPrice: any;
    
    karaokeRadio: any;
    karaokeUnitOfMeasure: any;
    karaokeUnitPrice: any;
    
    microPhoneRadio: any;
    microPhoneUnitOfMeasure: any;
    microPhoneUnitPrice: any;
    microPhoneQuantification: any;
    paSystemRadio: any;
    paSystemUnitOfMeasure: any;
    paSystemUnitPrice: any;


    socketsRadio: any;
    socketsUnitOfMeasure: any;
    socketsUnitPrice: any;


    blackOutControlRadio: any;
    blackOutControlUnitOfMeasure: any;
    blackOutControlUnitPrice: any;
    dimmersRadio:  any;
    dimmersUnitOfMeasure: any;
    dimmersUnitPrice: any;
    naturalDayLightRadio: any;
    naturalDayLightUnitOfMeasure: any;
    naturalDayLightUnitPrice: any;
    soundSystemRadio: any;
    soundSystemUnitOfMeasure: any;
    soundSystemUnitPrice: any;
    warmLightRadio: any;
    warmLightUnitOfMeasure: any;
    warmLightUnitPrice: any;
    coolLightRadio: any;
    coolLigtUnitOfMeasure: any;
    coolLightUnitPrice: any;


    computerRadio: any;
    computerUnitOfMeasure: any;
    computerUnitPrice: any;
    dvdRadio: any;
    dvdUnitOfMeasure: any;
    dvdUnitPrice: any;
    gameConsoleRadio: any;
    gameConsoleUnitOfMeasure: any;
    gameConsoleUnitPrice: any;
    lcdScreenRadio: any;
    lcdScreenUnitOfMeasure: any;
    lcdScreenUnitPrice: any;
    lcdQuantification: any;
    printerRadio: any;
    printerUnitOfMeasure: any;
    printerUnitPrice: any;
    printerQuantification: any;
    projectorRadio: any;
    projectorUnitOfMeasure: any;
    projectorUnitPrice: any;
    projectorQuantification: any;
    videoConferencingRadio: any;
    videoConferencingUnitOfMeasure: any;
    videoConferencingUnitPrice: any;
    whiteScreenRadio: any;
    whiteScreenUnitOfMeasure: any;
    whiteScreenUnitPrice: any;
    whiteScreenQuantification: any;
    wifiRadio: any;
    wifiUnitOfMeasure: any;
    wifiUnitPrice: any;
    lanCableRadio: any;
    lanCableUnitOfMeasure: any;
    lanCableUnitPrice: any;
    photoCopierRadio: any;
    photoCopierUnitOfMeasure: any;
    photoCopierUnitPrice: any;
    photoCopierQuantification: any;


    flipChartRadio: any;
    flipChartQuantification: any;
    paperAndPensRadio: any;
    paperAndPensQuantification: any;
    whiteBoardRadio: any;
    whiteBoardQuantification: any;

    
    interpretationRadio: any;
    interpretationUnitOfMeasure: any;
    interpretationUnitPrice: any;
    typingServiceRadio: any;
    typingServiceUnitOfMeasure: any;
    typingServiceUnitPrice: any; 
}
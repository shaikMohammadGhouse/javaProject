export class HotelAmenities
{
  hotelName: any;
 hasAccomodation: any;
 multiLinguaStaff: any;
suppLanguages: any;
siteSecurity: any;


tennis: any;
waterSports: any;
steamRoom: any;
 spa: any;
  snooker: any;
solarium: any;
winterSports: any;
shooting: any;
sauna: any;
fishing: any;
golf: any;
croquet: any;
bowls: any;
badminton: any;
gym: any;
healthClub: any;
outdoorSwimmingPool: any;
jacuzzi: any;
indoorSwimmingPool: any;
horseRiding: any;
archery: any;



coachParking: any;
freeOffSiteParking: any;
freeOnSiteParking: any;

offSiteParkingWithFee: any;
 unitOfMeasureOffSiteParking: any;
 unitOfMeasureOffSiteParkingPrice: any;
 
 onSiteParkingWithFee: any;
 unitOfMeasureOnSiteParking: any;
 unitOfMeasureOnSiteParkingPrice: any;

 publicTransport: any;
  limuousineService: any;
  shuttleBus: any;
  taxiService: any;
 
  tailor: any;
   terrace: any;
   restaurant: any;
   medicalFacility: any;
   luggageStorage: any;
   laundryService: any;
 
 businessCentre: any;
cloakroomService: any;
bedRooms: any;
 rampAccess: any;
 bar: any;
 ballRoom: any;
 concierge: any;
 disabledFacilities: any;
 heating: any;
 helipad: any;
 garden: any;
 freeWifi: any;
  elevator: any;
frontDesk: any;

shoppingArea: any;
closeToNature: any;
 countrySide: any;
inTheAirport: any;
 inTheCentre: any;
 nearAirport: any;
  nearAttractions: any;
 nearHarbor: any;
  nearMotorway: any;
  nearRailwayStation: any;
  nearTheCentre: any;
   nearByWater: any;
    suburbs: any;

     oneTeaBreak: any;
     oneTeaBreakService: any;
     twoTeaBreak: any;
     twoTeaBreakService: any;
     threeTeaBreak: any;
     threeTeaBreakService: any;
     unlimitedTea: any;
     unlimitedTeaService: any;
     alcoholicBeverages: any;
     alcoholicBeveragesService: any;
     coldBeverages: any;
     coldBeveragesService: any;
     hotBeverages: any;
     hotBeveragesService: any;
 stillWater: any;
 stillWaterService: any;

 twoBreakfast: any;
  twoBreakfastService: any;
  fullBreakfast: any;
  //fullBreakfastService:any;
  lunchBuffet: any;
  lunchBuffetService: any;
  lunchAlaCarte: any;
  lunchAlaCarteService: any;
twoCourseMenu: any;
 twoCourseMenuService: any;
 buffetLunch: any;
 buffetLunchService: any;
 twoLunchAlaCarte: any;
twoLunchAlaCarteService: any;
twoLunchBuffet: any;
twoLunchBuffetService: any;
threeCourseLunch: any;
threeCourseLunchService: any;

supper: any;
supperService: any;
threeCourseDinner: any;
threeCourseDinnerService: any;

snacks: any;
freshFruits: any;

}